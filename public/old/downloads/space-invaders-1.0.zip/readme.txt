--------------------------------------------------------------------------------

                          Space Invaders DS 1.0
                        By Jeremy Ruten (Jeremysr)
                          jeremy.ruten@gmail.com

--------------------------------------------------------------------------------

Installation:

  - Copy space-invaders.nds to your storage device and run.

Controls:

  - Left/Right or Y/A to move left/right.
  - L or R shoulder buttons to fire.
  - Press START to pause/unpause and to start a new game when you get Game Over.
