--------------------------------------------------------------------------------

                                   Flatland DS
                                   Version 0.01
                            By Jeremy Ruten (Jeremysr)
                               jeremy.ruten@gmail.com

--------------------------------------------------------------------------------

This is just a demo really, made in one day while reading the book "Flatland".
This program allows you to explore a 2D "flat" world from two perspectives at
once: a first-person 1D view as a Flatland inhabitant, and a top-down view as a
"Spaceland" (3D) inhabitant looking down at Flatland.

At first the world is empty. You must draw on the world to create objects. Then
you will be able to move around and see the objects pass by.

Controls:

  - Up to move forward, Down to move backward
  - Left and right to rotate your direction
  - Stylus to draw lines and shapes in Flatland
