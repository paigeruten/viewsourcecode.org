// Copyright 2008 Jeremy Ruten

/*
	This file is part of DSlife.

	DSlife is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Foobar is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with DSlife.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef _button_h
#define _button_h

class Button {
	public:
		// Constructors
		Button(char *the_text, Screen *the_screen, Font *the_font, u8 the_which_screen, u8 x_pos, u8 y_pos);
		~Button();

		// Check if the button is pressed and highlight/unhighlight it (redraws the button)
		bool check(u8 stylus_x, u8 stylus_y);
		
		// Toggle is_highlighted if button was just pressed
		void toggle_check(u8 stylus_x, u8 stylus_y);

		// Draw button to screen
		void draw();

		// Accessors
		void set_text(char *new_text);
		char *get_text() { return text; }
		void set_xy(u8 new_x, u8 new_y) { x = new_x; y = new_y; }
		u8 get_x() const { return x; }
		u8 get_y() const { return y; }
		void set_dimensions(u8 new_width, u8 new_height) { width = new_width; height = new_height; }
		u8 get_width() const { return width; }
		u8 get_height() const { return height; }
		void set_colors(u16 the_bordercolor, u16 the_fontcolor, u16 the_bgcolor, u16 the_highlight_bordercolor, u16 the_highlight_fontcolor, u16 the_highlight_bgcolor) { bordercolor = the_bordercolor; fontcolor = the_fontcolor; bgcolor = the_bgcolor; highlight_bordercolor = the_highlight_bordercolor; highlight_fontcolor = the_highlight_fontcolor; highlight_bgcolor = the_highlight_bgcolor; }
		bool highlighted() const { return is_highlighted; }
	private:
		Screen *screen;
		Font *font;
		char text[255];
		u8 which_screen;
		u8 x;
		u8 y;
		u8 width;
		u8 height;
		u16 bordercolor;
		u16 fontcolor;
		u16 bgcolor;
		u16 highlight_bordercolor;
		u16 highlight_fontcolor;
		u16 highlight_bgcolor;
		bool is_highlighted;
};

#endif
