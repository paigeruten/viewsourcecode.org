// Copyright 2008 Jeremy Ruten

/*
	This file is part of DSlife.

	DSlife is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Foobar is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with DSlife.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <nds.h>
#include <fat.h>
#include <stdio.h>
#include <string.h>
#include "screen.h"
#include "font.h"
#include "keyboard.h"
#include "button.h"
#include "textbox.h"
#include "life.h"
#include "panner.h"
#include "str.h"
#include "fileselect.h"

void keyboard_input(Keyboard *keyboard, Textbox *textbox, char *input, u8 max_length) {
	char current_char = 0;
	bool shift_pressed = false;
	u8 current_char_index = strlen(input);
	touchPosition stylus;

	keyboard->print_keyboard(shift_pressed);
	
	while (current_char != '\n') {
		scanKeys();
		stylus = touchReadXY();
	
		if ((keysHeld() & KEY_L || keysHeld() & KEY_R) && !shift_pressed) {
			shift_pressed = true;
			keyboard->print_keyboard(shift_pressed);
		}
		
		if (!(keysHeld() & KEY_L || keysHeld() & KEY_R) && shift_pressed) {
			shift_pressed = false;
			keyboard->print_keyboard(shift_pressed);
		}
	
		current_char = keyboard->key_pressed(shift_pressed, stylus.px, stylus.py);
		while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
		
		if (current_char == '\b' && current_char_index > 0) {
			input[--current_char_index] = '\0';
		} else if (current_char && current_char != '\n' && current_char != '\b' && current_char_index <= max_length) {
			input[current_char_index] = current_char;
			input[++current_char_index] = '\0';
		}
		
		textbox->draw(true);
		
		swiWaitForVBlank();
	}
	
	// Get rid of cursor
	textbox->draw(false);
}

// Prints the population/generation numbers
void print_population(Screen *screen, Font *font, u16 population, u8 population_x, u8 panner_x) {
	u8 put_x, put_y;
	
	for (put_x = population_x; put_x < panner_x; put_x++ ){
		for (put_y = 150; put_y < 165; put_y++) {
			screen->plot(put_x, put_y, 0, RGB15(0, 0, 0) | BIT(15));
		}
	}
	
	font->print_number(population, population_x, 150, 0, RGB15(31, 31, 31) | BIT(15));
}
void print_generation(Screen *screen, Font *font, u16 generation, u8 generation_x, u8 panner_x) {
	u8 put_x, put_y;
	
	for (put_x = generation_x; put_x < panner_x; put_x++ ){
		for (put_y = 170; put_y < 185; put_y++) {
			screen->plot(put_x, put_y, 0, RGB15(0, 0, 0) | BIT(15));
		}
	}
	
	font->print_number(generation, generation_x, 170, 0, RGB15(31, 31, 31) | BIT(15));
}

int main(void) {
	touchPosition stylus;
	u8 last_stylus_x = 0, last_stylus_y = 0, generation_x, population_x;
	bool last_stylus = false, life_started = false, just_touched = false;
	u16 button_colours[] = { RGB15(21, 21, 21) | BIT(15), RGB15(0, 0, 0) | BIT(15), RGB15(31, 31, 31) | BIT(15), RGB15(0, 0, 0) | BIT(15), RGB15(0, 0, 0) | BIT(15), RGB15(31, 15, 0) | BIT(15) };
	char *rules;

	irqInit();
	irqEnable(IRQ_VBLANK);

	// Init screen
	Screen screen((u16*)BG_BMP_RAM(0), (u16*)BG_BMP_RAM_SUB(0));
	screen.clear(RGB15(0, 0, 0) | BIT(15));

	// Init FAT (Displays green screens if it fails)
	if (!fatInitDefault()) {
		screen.clear(RGB15(0, 31, 0) | BIT(15));
		while (1);
	}

	// Init font (Displays red screens if it can't find the font file, blue screens if the font file is invalid)
	Font font("/data/life/fonts/sans.font", &screen);
	if (font.get_status() == FONT_OK) {
		font.print_string_xy("Font loaded.", 5, 5, 1, RGB15(31, 31, 31) | BIT(15));
	} else if (font.get_status() == ERR_FILE_NOT_FOUND) {
		screen.clear(RGB15(31, 0, 0) | BIT(15));
		while (1);
	} else if (font.get_status() == ERR_INVALID_FONT_FILE) {
		screen.clear(RGB15(0, 0, 31) | BIT(15));
		while (1);
	}

	// Init keyboard font
	Font keyboard_font("/data/life/fonts/metroid.font", &screen);
	if (keyboard_font.get_status() == FONT_OK) {
		font.print_string_xy("Keyboard font loaded.", 5, 20, 1, RGB15(31, 31, 31) | BIT(15));
	} else if (keyboard_font.get_status() == ERR_FILE_NOT_FOUND) {
		font.print_string_xy("Keyboard font (metroid.font) not found.", 5, 20, 1, RGB15(31, 31, 31) | BIT(15));
		while (1);
	} else if (keyboard_font.get_status() == ERR_INVALID_FONT_FILE) {
		font.print_string_xy("Keyboard font (metroid.font) is invalid.", 5, 20, 1, RGB15(31, 31, 31) | BIT(15));
		while (1);
	}

	// Init keyboards
	Keyboard keyboard("/data/life/keyboards/default.kb", &screen, &keyboard_font, 18, 108);
	Keyboard rules_keyboard("/data/life/keyboards/pattern.kb", &screen, &keyboard_font, 18, 18); // Used for entering the rules
	if (keyboard.get_status() == KEYBOARD_OK) {
		font.print_string_xy("Keyboard loaded.", 5, 35, 1, RGB15(31, 31, 31) | BIT(15));
	} else if (keyboard.get_status() == KEYBOARD_FILE_NOT_FOUND) {
		font.print_string_xy("Keyboard file not found.", 5, 35, 1, RGB15(31, 31, 31) | BIT(15));
		while (1);
	}
	if (rules_keyboard.get_status() == KEYBOARD_OK) {
		font.print_string_xy("Keyboard #2 loaded.", 5, 50, 1, RGB15(31, 31, 31) | BIT(15));
	} else if (rules_keyboard.get_status() == KEYBOARD_FILE_NOT_FOUND) {
		font.print_string_xy("Keyboard #2 file not found.", 5, 50, 1, RGB15(31, 31, 31) | BIT(15));
		while (1);
	}
	
	keyboard.set_xy(2, 40);
	rules_keyboard.set_xy(100, 40);
	
	keyboard.set_colors(RGB15(17, 17, 17) | BIT(15), RGB15(31, 31, 31) | BIT(15), RGB15(0, 0, 0) | BIT(15), RGB15(0, 0, 0) | BIT(15), RGB15(31, 15, 0) | BIT(15), RGB15(0, 0, 0) | BIT(15));
	rules_keyboard.set_colors(RGB15(17, 17, 17) | BIT(15), RGB15(31, 31, 31) | BIT(15), RGB15(0, 0, 0) | BIT(15), RGB15(0, 0, 0) | BIT(15), RGB15(31, 15, 0) | BIT(15), RGB15(0, 0, 0) | BIT(15));

	// Init life
	Life life(&screen, &font);

	// Make GUI
	Button button_zoomin("Zoom in", &screen, &keyboard_font, 0, 10, 10);
	Button button_zoomout("Zoom out", &screen, &keyboard_font, 0, button_zoomin.get_x()+button_zoomin.get_width()+10, button_zoomin.get_y());
	Button button_start("Start", &screen, &keyboard_font, 0, button_zoomout.get_x()+button_zoomout.get_width()+10, button_zoomout.get_y());
	Button button_stop("Stop", &screen, &keyboard_font, 0, button_start.get_x()+button_start.get_width()+10, button_start.get_y());
	Button button_step("Step", &screen, &keyboard_font, 0, button_zoomin.get_x(), button_zoomin.get_y()+button_zoomin.get_height()+10);
	Button button_reset("Reset", &screen, &keyboard_font, 0, button_step.get_x()+button_step.get_width()+10, button_step.get_y());
	Button button_save("Save", &screen, &keyboard_font, 0, button_reset.get_x()+button_reset.get_width()+10, button_reset.get_y());
	Button button_load("Load", &screen, &keyboard_font, 0, button_save.get_x()+button_save.get_width()+10, button_save.get_y());
	Button button_eraser("Eraser", &screen, &keyboard_font, 0, button_load.get_x()+button_load.get_width()+10, button_load.get_y());
	Button button_change("Change", &screen, &keyboard_font, 0, 185, 65);
	Panner panner(&screen, 160, 123, 90, 64);
	Textbox textbox_rules(&screen, &keyboard_font, "23/3", 10, 65, 170, 13, 0);
	rules = textbox_rules.get_value();
	
	button_zoomin.set_colors(button_colours[0], button_colours[1], button_colours[2], button_colours[3], button_colours[4], button_colours[5]);
	button_zoomout.set_colors(button_colours[0], button_colours[1], button_colours[2], button_colours[3], button_colours[4], button_colours[5]);
	button_start.set_colors(button_colours[0], button_colours[1], button_colours[2], button_colours[3], button_colours[4], button_colours[5]);
	button_stop.set_colors(button_colours[0], button_colours[1], button_colours[2], button_colours[3], button_colours[4], button_colours[5]);
	button_step.set_colors(button_colours[0], button_colours[1], button_colours[2], button_colours[3], button_colours[4], button_colours[5]);
	button_reset.set_colors(button_colours[0], button_colours[1], button_colours[2], button_colours[3], button_colours[4], button_colours[5]);
	button_change.set_colors(button_colours[0], button_colours[1], button_colours[2], button_colours[3], button_colours[4], button_colours[5]);
	button_load.set_colors(button_colours[0], button_colours[1], button_colours[2], button_colours[3], button_colours[4], button_colours[5]);
	button_save.set_colors(button_colours[0], button_colours[1], button_colours[2], button_colours[3], button_colours[4], button_colours[5]);
	button_eraser.set_colors(button_colours[0], button_colours[1], button_colours[2], button_colours[3], button_colours[4], button_colours[5]);
	textbox_rules.set_colors(RGB15(21, 21, 21) | BIT(15), RGB15(31, 31, 31) | BIT(15), RGB15(0, 0, 0) | BIT(15));

	screen.clear(RGB15(31, 31, 31) | BIT(15), 1);

	button_zoomin.draw();
	button_zoomout.draw();
	button_start.draw();
	button_stop.draw();
	button_step.draw();
	button_reset.draw();
	button_change.draw();
	button_load.draw();
	button_save.draw();
	button_eraser.draw();
	textbox_rules.draw(false);
	
	keyboard_font.print_string_xy("Rules", 10, 55, 0, RGB15(31, 31, 31) | BIT(15));

	// Draw the panner
	panner.draw(1);
	
	// Draw "Panning" above the panner, centered
	keyboard_font.print_string_xy("Panning", 205 - keyboard_font.string_width("Panning", 7)/2, 113, 0, RGB15(31, 31, 31) | BIT(15));
	
	// Print the population and generation strings and get the x positions to print their values
	font.print_string_xy("Population: 0", 10, 150, 0, RGB15(31, 31, 31) | BIT(15));
	font.print_string_xy("Generation: 0", 10, 170, 0, RGB15(31, 31, 31) | BIT(15));
	population_x = font.string_width("Population: ", 12) + 10;
	generation_x = font.string_width("Generation: ", 12) + 10;

	// Fixes a strange bug...
	button_stop.check(0, 0);

	while (1) {
		scanKeys();
		stylus = touchReadXY();

		if (keysHeld() & KEY_TOUCH && screen.swapped()) {
			if (last_stylus) {
				life.draw_life_line(stylus.px, stylus.py, last_stylus_x, last_stylus_y, button_eraser.highlighted());
			} else {
				life.draw_life(stylus.px, stylus.py, button_eraser.highlighted());
				last_stylus = true;
			}
			
			print_population(&screen, &font, life.get_population(), population_x, 160);
			
			last_stylus_x = stylus.px;
			last_stylus_y = stylus.py;
		} else {
			last_stylus = false;
		}
		
		if (!screen.swapped()) {
			if (keysDown() & KEY_TOUCH || just_touched) {
				if (keysDown() & KEY_TOUCH) {
					just_touched = true;
				} else {
					just_touched = false;
				}
			
				if (button_zoomin.check(stylus.px, stylus.py)) {
					while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
					button_zoomin.check(stylus.px, stylus.py);
					
					if (life.get_zoom() < 32) {
						life.set_zoom(life.get_zoom()*2);
						
						panner.draw(life.get_zoom());
						life.set_pan(panner.get_pan_x(), panner.get_pan_y());
						
						// Clear grid then draw it if at the right zoom level
						screen.clear(RGB15(31, 31, 31) | BIT(15), 1);
						life.update();
						life.draw_grid();
					}
				}
				
				if (button_zoomout.check(stylus.px, stylus.py)) {
					while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
					button_zoomout.check(stylus.px, stylus.py);
					
					if (life.get_zoom() > 1) {
						life.set_zoom(life.get_zoom()/2);
						
						panner.draw(life.get_zoom());
						life.set_pan(panner.get_pan_x(), panner.get_pan_y());
						
						// Clear grid then draw it if at the right zoom level
						screen.clear(RGB15(31, 31, 31) | BIT(15), 1);
						life.update();
						life.draw_grid();
					}
				}
				
				if (button_start.check(stylus.px, stylus.py)) {
					while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
					button_start.check(stylus.px, stylus.py);
					
					life_started = true;
				}
				
				if (button_stop.check(stylus.px, stylus.py)) {
					while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
					button_stop.check(stylus.px, stylus.py);
					
					life_started = false;
				}
				
				if (button_step.check(stylus.px, stylus.py)) {
					while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
					button_step.check(stylus.px, stylus.py);
					
					life.generate();
					life.update();
					
					print_population(&screen, &font, life.get_population(), population_x, 160);
					print_generation(&screen, &font, life.get_generation(), generation_x, 160);
				}
				
				if (button_reset.check(stylus.px, stylus.py)) {
					while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
					button_reset.check(stylus.px, stylus.py);
					
					life.reset();
					life.update();
					panner.draw(life.get_zoom());
					
					print_population(&screen, &font, 0, population_x, 160);
					print_generation(&screen, &font, 0, generation_x, 160);
					
					life_started = false;
				}
				
				if (button_save.check(stylus.px, stylus.py)) {
					while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
					button_save.check(stylus.px, stylus.py);
					
					screen.clear(RGB15(0, 0, 0) | BIT(15), 0);
					keyboard_font.print_string_xy("Filename", 10, 10, 0, RGB15(31, 31, 31) | BIT(15));
					Textbox textbox_save(&screen, &keyboard_font, "", 10, 20, 170, 13, 0);
					textbox_save.set_colors(RGB15(21, 21, 21) | BIT(15), RGB15(31, 31, 31) | BIT(15), RGB15(0, 0, 0) | BIT(15));
					char *filename = textbox_save.get_value();
					
					screen.swap();
					keyboard_input(&keyboard, &textbox_save, filename, 20);
					keyboard_font.print_string_xy("Saving...", 10, 55, 0, RGB15(31, 31, 31) | BIT(15));
					if (life.save(filename)) {
						keyboard_font.print_string_xy("Success! Press A to go back.", 10, 65, 0, RGB15(31, 31, 31) | BIT(15));
					} else {
						keyboard_font.print_string_xy("Failed. Press A to go back.", 10, 65, 0, RGB15(31, 31, 31) | BIT(15));
					}
					
					filename = 0;
					
					while (!(keysHeld() & KEY_A)) { scanKeys(); swiWaitForVBlank(); }
					while (keysHeld() & KEY_A) { scanKeys(); swiWaitForVBlank(); }
					
					screen.swap();
					life.draw_grid();
					life.update();
					
					// Redraw GUI
					screen.clear(RGB15(0, 0, 0) | BIT(15), 0);
					button_zoomin.draw();
					button_zoomout.draw();
					button_start.draw();
					button_stop.draw();
					button_step.draw();
					button_reset.draw();
					button_change.draw();
					button_save.draw();
					button_load.draw();
					button_eraser.draw();
					textbox_rules.draw(false);
					keyboard_font.print_string_xy("Rules", 10, 55, 0, RGB15(31, 31, 31) | BIT(15));
					panner.draw(life.get_zoom());
					keyboard_font.print_string_xy("Panning", 205 - keyboard_font.string_width("Panning", 7)/2, 113, 0, RGB15(31, 31, 31) | BIT(15));
					
					font.print_string_xy("Population: ", 10, 150, 0, RGB15(31, 31, 31) | BIT(15));
					font.print_string_xy("Generation: ", 10, 170, 0, RGB15(31, 31, 31) | BIT(15));
					
					print_population(&screen, &font, life.get_population(), population_x, 160);
					print_generation(&screen, &font, life.get_generation(), generation_x, 160);			
				}
				
				if (button_load.check(stylus.px, stylus.py)) {
					while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
					button_load.check(stylus.px, stylus.py);
					
					screen.clear(RGB15(0, 0, 0) | BIT(15), 2);
					keyboard_font.print_string_xy("Select a file.", 5, 5, 1, RGB15(31, 31, 31) | BIT(15));

					FileSelector fileselector(&screen, &keyboard_font);
					char *filename = fileselector.select_file("/data/life/patterns");
					
					if (filename == NULL) {
						keyboard_font.print_string_xy("Ah, nevermind. Either there are no files", 5, 55, 1, RGB15(31, 31, 31) | BIT(15));
						keyboard_font.print_string_xy("in the patterns directory or the patterns", 5, 65, 1, RGB15(31, 31, 31) | BIT(15));
						keyboard_font.print_string_xy("directory doesn't exist.", 5, 75, 1, RGB15(31, 31, 31) | BIT(15));
						keyboard_font.print_string_xy("Press A to go back.", 5, 95, 1, RGB15(31, 0, 0) | BIT(15));
					} else {
						keyboard_font.print_string_xy("Loading...", 5, 55, 1, RGB15(31, 31, 31) | BIT(15));
						if (life.load(filename)) {
							keyboard_font.print_string_xy("Success! Press A to go back.", 5, 65, 1, RGB15(31, 31, 31) | BIT(15));
						} else {
							keyboard_font.print_string_xy("File doesn't exist. Press A to go back.", 5, 65, 1, RGB15(31, 31, 31) | BIT(15));
						}
					}
					
					filename = 0;
					
					while (!(keysHeld() & KEY_A)) { scanKeys(); swiWaitForVBlank(); }
					while (keysHeld() & KEY_A) { scanKeys(); swiWaitForVBlank(); }
					
					life.draw_grid();
					life.update();
					
					// Redraw GUI
					screen.clear(RGB15(0, 0, 0) | BIT(15), 0);
					button_zoomin.draw();
					button_zoomout.draw();
					button_start.draw();
					button_stop.draw();
					button_step.draw();
					button_reset.draw();
					button_change.draw();
					button_save.draw();
					button_load.draw();
					button_eraser.draw();
					textbox_rules.draw(false);
					keyboard_font.print_string_xy("Rules", 10, 55, 0, RGB15(31, 31, 31) | BIT(15));
					panner.draw(life.get_zoom());
					keyboard_font.print_string_xy("Panning", 205 - keyboard_font.string_width("Panning", 7)/2, 113, 0, RGB15(31, 31, 31) | BIT(15));
					
					life.update_population();
					
					font.print_string_xy("Population: ", 10, 150, 0, RGB15(31, 31, 31) | BIT(15));
					font.print_string_xy("Generation: ", 10, 170, 0, RGB15(31, 31, 31) | BIT(15));
					
					print_population(&screen, &font, life.get_population(), population_x, 160);
					print_generation(&screen, &font, 0, generation_x, 160);
				}
				
				if (button_change.check(stylus.px, stylus.py)) {
					while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
					button_change.check(stylus.px, stylus.py);
					
					screen.swap();
					keyboard_input(&rules_keyboard, &textbox_rules, rules, 20);
					life.set_rules(rules);
					screen.swap();
					life.draw_grid();
					life.update();
				}
				
				button_eraser.toggle_check(stylus.px, stylus.py);
			}
			
			if (panner.update(stylus.px, stylus.py, life.get_zoom())) {
				life.set_pan(panner.get_pan_x(), panner.get_pan_y());
				life.update();
			}
		}

		if (life_started) {
			life.generate();
			life.update();
			
			print_population(&screen, &font, life.get_population(), population_x, 160);
			print_generation(&screen, &font, life.get_generation(), generation_x, 160);
		}

		if (keysHeld() & KEY_L || keysHeld() & KEY_R) {
			screen.swap();
			while (keysHeld() & KEY_L || keysHeld() & KEY_R) { scanKeys(); swiWaitForVBlank(); }
		}
		
		if (keysHeld() & KEY_UP) {
			panner.set_pan(0, -1, life.get_zoom());
			life.set_pan(panner.get_pan_x(), panner.get_pan_y());
			life.update();
		}
		
		if (keysHeld() & KEY_DOWN) {
			panner.set_pan(0, 1, life.get_zoom());
			life.set_pan(panner.get_pan_x(), panner.get_pan_y());
			life.update();
		}
		
		if (keysHeld() & KEY_LEFT) {
			panner.set_pan(-1, 0, life.get_zoom());
			life.set_pan(panner.get_pan_x(), panner.get_pan_y());
			life.update();
		}
		
		if (keysHeld() & KEY_RIGHT) {
			panner.set_pan(1, 0, life.get_zoom());
			life.set_pan(panner.get_pan_x(), panner.get_pan_y());
			life.update();
		}

		if (keysHeld() & KEY_SELECT) {
			u32 vblankcount = 0;
			while (keysHeld() & KEY_SELECT && vblankcount < 300) { scanKeys(); swiWaitForVBlank(); vblankcount++; }
			if (vblankcount >= 300) {
				FILE *screenshot = fopen("/screenshot", "wb");
				
				fwrite((u16*)BG_BMP_RAM(0), sizeof(u16), 256*192, screenshot);
				fwrite((u16*)BG_BMP_RAM_SUB(0), sizeof(u16), 256*192, screenshot);
				
				fclose(screenshot);
				
				font.print_string_center("Screenshot saved!", 87, 0, RGB15(0, 0, 0) | BIT(15), RGB15(31, 15, 0) | BIT(15));
				while(1);
			}
		}

		swiWaitForVBlank();
	}
	
	return 0;
}
