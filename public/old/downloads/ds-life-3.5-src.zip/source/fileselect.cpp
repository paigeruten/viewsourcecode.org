// Copyright 2008 Jeremy Ruten

/*
	This file is part of DSlife.

	DSlife is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Foobar is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with DSlife.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <nds.h>
#include <fat.h>
#include <stdio.h>
#include <sys/dir.h>
#include <sys/unistd.h>
#include <string.h>
#include "screen.h"
#include "font.h"
#include "fileselect.h"

FileSelector::FileSelector(Screen *the_screen, Font *the_font) {
	screen = the_screen;
	font = the_font;
}

FileSelector::~FileSelector() {
}

char *FileSelector::select_file(char *dir_name) {
	DIR_ITER *dp;
	u8 selected_file, clicked_file = 255, start_file = 0;
	s16 i, last_file, scroll_pos = 0;
	char filename[256];
	touchPosition stylus;
	bool dont_click;

	// Get all the files in the directory into an array of strings
	dp = diropen(dir_name);
	if (dp != NULL) {
		i = 0;
		while (dirnext(dp, filename, NULL) == 0) {
			if (strlen(filename) < 32 && i < 255 && filename[0] != '.') {
				strcpy(&files[i][0], filename);	
				i++;
			}
		}
		dirclose(dp);
		
		last_file = i - 1;
	} else {
		return NULL;
	}
	
	// If there are no files in the directory then return NULL
	if (last_file == -1) {
		return NULL;
	}
	
	// Now print them out and let the user select one
	screen->clear(RGB15(0, 0, 0) | BIT(15), 0);
	selected_file = 0;
	list_files(start_file, last_file, selected_file);
	update_scrollbar(scroll_pos, RGB15(15, 15, 15) | BIT(15));
	
	// When a file is "clicked", its array index will be assigned to clicked_file
	while (clicked_file == 255) {
		scanKeys();
		stylus = touchReadXY();
		
		if (keysHeld() & KEY_UP && selected_file != 0) {
			selected_file--;
			if (selected_file < start_file) {
				start_file = selected_file;
				scroll_pos = start_file * (192-50) / (last_file-15);
				update_scrollbar(scroll_pos, RGB15(15, 15, 15) | BIT(15));
			}
			list_files(start_file, last_file, selected_file);
			for (i = 0; i < 6; i++) { swiWaitForVBlank(); }
		}
		
		if (keysHeld() & KEY_DOWN && selected_file != last_file) {
			selected_file++;
			if (selected_file > start_file + 15) {
				start_file = selected_file - 15;
				scroll_pos = start_file * (192-50) / (last_file-15);
				update_scrollbar(scroll_pos, RGB15(15, 15, 15) | BIT(15));
			}
			list_files(start_file, last_file, selected_file);
			for (i = 0; i < 6; i++) { swiWaitForVBlank(); }
		}
		
		if (keysHeld() & KEY_A) {
			while (keysHeld() & KEY_A) { scanKeys(); swiWaitForVBlank(); }
			clicked_file = selected_file;
		}
		
		if (keysHeld() & KEY_TOUCH) {
			if (stylus.px < 240) {
				if (selected_file != stylus.py/12 + start_file) {
					selected_file = stylus.py/12 + start_file;
					list_files(start_file, last_file, selected_file);
					dont_click = true;
				} else {
					dont_click = false;
				}

				while (keysHeld() & KEY_TOUCH) {
					if (selected_file != stylus.py/12 + start_file) {
						selected_file = stylus.py/12 + start_file;
						list_files(start_file, last_file, selected_file);
						dont_click = true;
					}
					
					swiWaitForVBlank();
					scanKeys();
					stylus = touchReadXY();
				}
				
				if (!dont_click) {
					clicked_file = selected_file;
				}
			} else {
				while (keysHeld() & KEY_TOUCH) {
					scroll_pos = stylus.py - 25;
					if (scroll_pos < 0) { scroll_pos = 0; }
					if (scroll_pos + 50 > 191) { scroll_pos = 141; }
					
					if (scroll_pos * (last_file-15) / (191-50) != start_file) {
						start_file = scroll_pos * (last_file-15) / (191-50);
						list_files(start_file, last_file, selected_file);
					}
					
					update_scrollbar(scroll_pos, RGB15(31, 15, 0) | BIT(15));
					
					swiWaitForVBlank();
					scanKeys();
					stylus = touchReadXY();
				}
				
				update_scrollbar(scroll_pos, RGB15(15, 15, 15) | BIT(15));
			}
		}
		
		swiWaitForVBlank();
	}
	
	return &files[clicked_file][0];
}

void FileSelector::list_files(u8 start, u8 last, u8 selected_file) {
	u16 put_x, put_y, file_num, row;
	u16 bgcolors[2] = { RGB15(5, 5, 5) | BIT(15), RGB15(10, 10, 10) | BIT(15) };
	
	for (file_num = start, row = 0; file_num < start + 16; file_num++, row++) {
		if (file_num <= last) {
			if (file_num == selected_file) {
				for (put_x = 0; put_x < 240; put_x++) {
					for (put_y = row * 12; put_y < row * 12 + 12; put_y++) {
						screen->plot(put_x, put_y, 0, RGB15(31, 15, 0) | BIT(15));
					}
				}
				
				font->print_string_xy(&files[file_num][0], 5, row * 12 + 2, 0, RGB15(0, 0, 0) | BIT(15));
			} else {
				for (put_x = 0; put_x < 240; put_x++) {
					for (put_y = row * 12; put_y < row * 12 + 12; put_y++) {
						screen->plot(put_x, put_y, 0, bgcolors[file_num & 1]);
					}
				}
				
				font->print_string_xy(&files[file_num][0], 5, row * 12 + 2, 0, RGB15(31, 31, 31) | BIT(15));
			}
		}
	}
}

void FileSelector::update_scrollbar(u8 scroll_pos, u16 color) {
	u16 put_x, put_y;
	
	for (put_x = 243; put_x < 254; put_x++) {
		for (put_y = 0; put_y < 192; put_y++) {
			if (put_y > scroll_pos && put_y < scroll_pos + 50) {
				screen->plot(put_x, put_y, 0, color);
			} else {
				screen->plot(put_x, put_y, 0, RGB15(0, 0, 0) | BIT(15));
			}
		}
	}
}

