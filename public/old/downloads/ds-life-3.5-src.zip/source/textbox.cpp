// Copyright 2008 Jeremy Ruten

/*
	This file is part of DSlife.

	DSlife is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Foobar is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with DSlife.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <nds.h>
#include <stdlib.h>
#include <string.h>
#include "screen.h"
#include "font.h"
#include "textbox.h"

Textbox::Textbox(Screen *the_screen, Font *the_font, char *initial_value, u8 the_x, u8 the_y, u8 the_width, u8 the_height, u8 the_which_screen) {
	screen = the_screen;
	font = the_font;
	strcpy(value, initial_value);
	x = the_x;
	y = the_y;
	width = the_width;
	height = the_height;
	which_screen = the_which_screen;
	focused = false;
	vblank_count = 0;
	cursor_x = 3;
}

Textbox::~Textbox() {
}

void Textbox::draw(bool draw_cursor) {
	u8 i, put_x, put_y;
	u16 cursor_colour;

	// Draw the border
	for (i = x; i <= x+width; i++) {
		screen->plot(i, y, which_screen, bordercolor);
		screen->plot(i, y+height, which_screen, bordercolor);
	}
	for (i = y; i <= y+height; i++) {
		screen->plot(x, i, which_screen, bordercolor);
		screen->plot(x+width, i, which_screen, bordercolor);
	}

	// Fill in the box
	for (put_x = x+1; put_x < x+width; put_x++) {
		for (put_y = y+1; put_y < y+height; put_y++) {
			screen->plot(put_x, put_y, which_screen, bgcolor);
		}
	}

	// Output the value
	font->print_string_xy(value, x+3, y+3, which_screen, fontcolor);

	if (draw_cursor) {
		// Make the cursor blink
		if (vblank_count < 30) {
			cursor_colour = fontcolor;
		} else if (vblank_count < 45) {
			cursor_colour = bgcolor;
		} else {
			cursor_colour = fontcolor;
			vblank_count = 0;
		}

		// Output the cursor
		cursor_x = x+3+font->string_width(value, strlen(value));
		for (i = y+3; i <= y+3+font->get_font_height(); i++) {
			screen->plot(cursor_x, i, which_screen, cursor_colour);
		}

		vblank_count++;
	}
}

void Textbox::set_value(char *new_value) {
	strcpy(value, new_value);
}
