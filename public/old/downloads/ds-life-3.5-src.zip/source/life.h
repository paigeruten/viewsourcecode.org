// Copyright 2008 Jeremy Ruten

/*
	This file is part of DSlife.

	DSlife is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Foobar is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with DSlife.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef _life_h
#define _life_h

class Life {
	public:
		// Constructors
		Life(Screen *the_screen, Font *the_font);
		~Life();

		// Accessors
		void set_rules(char *the_rules);
		void set_zoom(u8 new_zoom) { zoom = new_zoom; }
		u8 get_zoom() const { return zoom; }
		void set_pan(u8 x, u8 y) { pan_x = x; pan_y = y; }
		u8 get_pan_x() const { return pan_x; }
		u8 get_pan_y() const { return pan_y; }
		u32 get_generation() const { return generation; }
		u16 get_population() const { return population; }

		// Do one generation of life
		void generate();

		// Copy life array to screen
		void update() const;
		
		// Draw a grid over the life (only if it's zoomed in 4x or greater)
		void draw_grid() const;
		
		// Reset life array and variables
		void reset();

		// Let user draw life on the screen
		void draw_life(u8 stylus_x, u8 stylus_y, bool erase=false);
		void draw_life_line(u8 stylus_x, u8 stylus_y, u8 stylus_last_x, u8 stylus_last_y, bool erase=false);
		
		// Saving and loading
		bool save(char *filename);
		bool load(char *filename);
		
		// Recount the population
		void update_population();
	private:
		Screen *screen;
		Font *font;
		u8 *life;
		u8 *temp_life;
		u8 rules[2][9];
		u8 zoom;
		u8 pan_x;
		u8 pan_y;
		u32 generation;
		u16 population;
};

bool in_array(u8 needle, u8 *haystack);

#endif
