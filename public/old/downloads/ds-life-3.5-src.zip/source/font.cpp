// Copyright 2008 Jeremy Ruten

/*
	This file is part of DSlife.

	DSlife is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Foobar is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with DSlife.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <nds.h>
#include <fat.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "screen.h"
#include "font.h"
#include "str.h"

Font::Font(char *fontfile, Screen *the_screen) {
	screen = the_screen;
	font = 0;
	status = load_font(fontfile);
}

Font::~Font() {
	delete [] font;
	font = 0;
}

u8 Font::load_font(char *filename) {
	FILE *fontfile = fopen(filename, "r");
	char str_value[8], char_value;
	s32 num_value, i;

	if (!fontfile) {
		return ERR_FILE_NOT_FOUND;
	}

	// Get font width
	fgets(str_value, 8, fontfile);
	chop(str_value);
	num_value = intval(str_value);
	if (num_value == -1) { fclose(fontfile); return ERR_INVALID_FONT_FILE; }
	font_width = num_value;

	// Get font height
	fgets(str_value, 8, fontfile);
	chop(str_value);
	num_value = intval(str_value);
	if (num_value == -1) { fclose(fontfile); return ERR_INVALID_FONT_FILE; }
	font_height = num_value;

	// Get space between chars
	fgets(str_value, 8, fontfile);
	chop(str_value);
	num_value = intval(str_value);
	if (num_value == -1) { fclose(fontfile); return ERR_INVALID_FONT_FILE; }
	space_between_chars = num_value;

	// Skip a line
	fgets(str_value, 8, fontfile);

	// Get 128 font_widths[] values
	for (i = 0; i < 128; i++) {
		fgets(str_value, 8, fontfile);
		chop(str_value);
		num_value = intval(str_value);
		if (num_value == -1) { fclose(fontfile); return ERR_INVALID_FONT_FILE; }
		font_widths[i] = num_value;
	}

	// Skip a line
	fgets(str_value, 8, fontfile);

	// If a font was already loaded, delete the memory
	if (font != 0) {
		delete [] font;
		font = 0;
	}

	// Allocate memory for font data
	font = new u8 [font_width * font_height * 128];
	if (font == 0) { fclose(fontfile); return ERR_ALLOC_MEMORY; }

	// For the rest of the file, copy each '1' and '0' encountered to the font[] array. The i variable will keep track of how many characters have been copied so far.
	i = 0;
	char_value = fgetc(fontfile);
	while (!feof(fontfile)) {
		if (char_value == '0' || char_value == '1') {
			// Make sure we aren't past the amount of memory we allocated
			if (i == font_width*font_height*128) {
				fclose(fontfile);
				fontfile = 0;
				delete [] font;
				font = 0;
				return ERR_INVALID_FONT_FILE;
			}

			font[i] = char_value - 48;
			i++;
		}

		char_value = fgetc(fontfile);
	}

	// Make sure we got enough font data
	if (i != font_width*font_height*128) {
		fclose(fontfile);
		fontfile = 0;
		delete [] font;
		font = 0;
		return ERR_INVALID_FONT_FILE;
	}

	fclose(fontfile);

	return FONT_OK;
}

void Font::print_char(char character, u8 x, u8 y, u8 which_screen, u16 color, u16 bgcolor) const {
	u16 put_y, put_x;
	for (put_y = y; put_y < y + font_height; put_y++) {
		for (put_x = x; put_x < x + font_widths[(int)character]; put_x++) {
			switch (font[(int)character*font_width*font_height + (put_y - y)*font_width + (put_x - x)]) {
				case 1:
					screen->plot(put_x, put_y, which_screen, color);
					break;
				default:
					if (bgcolor != TRANSPARENT) { screen->plot(put_x, put_y, which_screen, bgcolor); }
					break;
			}
		}
	}
	
	// Fill in space to the right of the char if there's a solid background colour.
	if (bgcolor != TRANSPARENT) {
		for (put_y = y; put_y <= y+font_height-1; put_y++) {
			for (put_x = x+font_widths[(int)character]; put_x < x+font_widths[(int)character]+space_between_chars; put_x++) {
				screen->plot(put_x, put_y, which_screen, bgcolor);
			}
		}
	}
}

void Font::print_string_xy(char *string, u8 x, u8 y, u8 which_screen, u16 color, u16 bgcolor) const {
	u16 put_x = x, put_y = y;
	u32 current_char = 0;
	
	while (string[current_char] != '\0') {
		print_char(string[current_char], put_x, put_y, which_screen, color, bgcolor);
		put_x += space_between_chars + font_widths[(int)string[current_char]];
		current_char++;
	}
}

void Font::print_string_highlighted(char *string, u8 x, u8 y, u8 which_screen, u16 highlight_start, u16 highlight_end, u16 color, u16 bgcolor, u16 highlight_color, u16 highlight_bgcolor) const {
	u16 put_x = x, put_y = y, line_y, line_x;
	u32 current_char = 0;
	
	while (string[current_char] != '\0') {
		if ((highlight_start < highlight_end && current_char >= highlight_start && current_char < highlight_end) || (highlight_start > highlight_end && current_char < highlight_start && current_char >= highlight_end))
			print_char(string[current_char], put_x, put_y, which_screen, highlight_color, highlight_bgcolor);
		else
			print_char(string[current_char], put_x, put_y, which_screen, color, bgcolor);
		
		put_x += font_widths[(int)string[current_char]];
		
		// Fill in space between chars
		if ((highlight_start < highlight_end && current_char >= highlight_start && current_char < highlight_end) || (highlight_start > highlight_end && current_char < highlight_start && current_char >= highlight_end)) {
			for (line_y = put_y; line_y <= put_y+font_height-1; line_y++) {
				for (line_x = put_x; line_x < put_x+space_between_chars; line_x++) {
					screen->plot(line_x, line_y, which_screen, highlight_bgcolor);
				}
			}
		}
		
		put_x += space_between_chars;		
		current_char++;
	}
}

void Font::print_string_center(char *string, u8 y, u8 which_screen, u16 color, u16 bgcolor) const {
	u16 put_x = 127 - string_width(string, strlen(string)-1)/2, put_y = y;
	u32 current_char = 0;
	
	while (string[current_char] != '\0') {
		print_char(string[current_char], put_x, put_y, which_screen, color, bgcolor);
		put_x += space_between_chars + font_widths[(int)string[current_char]];		
		current_char++;
	}
}

void Font::print_number(s32 num, u8 x, u8 y, u8 which_screen, u16 color, u16 bgcolor) const {
	char numstring[20] = "", numstring_reverse[20] = "";
	s32 number = num, quotient = 1, remainder = 0;
	char remainder_str[3] = "";
	u32 current_char = 0, current_char2 = 0;
	
	// Convert num into a string
	if (number == 0) {
		strcpy(numstring_reverse, "0");
	} else {
		while (quotient != 0) {
			remainder = number % 10;
			quotient = number / 10;
			remainder_str[0] = remainder+48;
			remainder_str[1] = '\0';
			strcat(numstring, remainder_str);
			number = quotient;
		}
		
		current_char = strlen(numstring)-1;
		while (current_char != 0) {
			numstring_reverse[current_char2] = numstring[current_char];
			current_char--;
			current_char2++;
		}
		numstring_reverse[current_char2] = numstring[current_char];
	}
	
	print_string_xy(numstring_reverse, x, y, which_screen, color, bgcolor);
}

u32 Font::string_width(char *string, u8 length) const {
	u32 i = 0, c = 0;
	
	while (c != length) {
		i += font_widths[(int)string[c]];
		i += space_between_chars;
		c++;
	}
	i--;
	
	return i;
}
