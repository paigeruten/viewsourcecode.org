// Copyright 2008 Jeremy Ruten

/*
	This file is part of DSlife.

	DSlife is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Foobar is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with DSlife.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef _textbox_h
#define _textbox_h

class Textbox {
	public:
		// Constructors
		Textbox(Screen *the_screen, Font *the_font, char *initial_value, u8 the_x, u8 the_y, u8 the_width, u8 the_height, u8 the_which_screen);
		~Textbox();

		// Draw to screen and blink the cursor
		void draw(bool draw_cursor);

		// Check if stylus is touching it
		bool pressed(u8 stylus_x, u8 stylus_y) const { return (stylus_x >= x && stylus_x <= x+width && stylus_y >= y && stylus_y <= y+height && keysHeld() & KEY_TOUCH); }

		// Accessors
		void set_value(char *new_value);
		char *get_value() { return value; }
		u8 get_x() const { return x; }
		u8 get_y() const { return y; }
		void set_dimensions(u8 new_width, u8 new_height) { width = new_width; height = new_height; }
		bool is_focused() const { return focused; }
		void focus() { focused = true; }
		void unfocus() { focused = false; }
		void set_colors(u16 new_bordercolor, u16 new_bgcolor, u16 new_fontcolor) { bordercolor = new_bordercolor; bgcolor = new_bgcolor; fontcolor = new_fontcolor; }
		void set_screen(u8 new_screen) { which_screen = new_screen; }
	private:
		Screen *screen;
		Font *font;
		char value[255];
		u8 x;
		u8 y;
		u8 width;
		u8 height;
		u8 which_screen;
		bool focused;
		u8 vblank_count;
		u8 cursor_x;
		u16 bordercolor;
		u16 bgcolor;
		u16 fontcolor;
};

#endif
