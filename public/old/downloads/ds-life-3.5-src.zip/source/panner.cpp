// Copyright 2008 Jeremy Ruten

/*
	This file is part of DSlife.

	DSlife is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Foobar is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with DSlife.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <nds.h>
#include "screen.h"
#include "panner.h"

Panner::Panner(Screen *the_screen, u8 the_x, u8 the_y, u8 the_width, u8 the_height) {
	screen = the_screen;
	x = the_x;
	y = the_y;
	width = the_width;
	height = the_height;
	pan_x = 0;
	pan_y = 0;
	real_pan_x = 0;
	real_pan_y = 0;
}

Panner::~Panner() {
}

void Panner::set_pan(s8 new_pan_x, s8 new_pan_y, u8 zoom) {
	pan_x += new_pan_x;
	pan_y += new_pan_y;
	
	if (pan_x < 0) { pan_x = 0; }
	if (pan_x > width - (width/zoom)) { pan_x = width - (width/zoom); }
	if (pan_y < 0) { pan_y = 0; }
	if (pan_y > height - (height/zoom)) { pan_y = height - (height/zoom); }
	
	real_pan_x = pan_x * (256.0/(double)width);
	real_pan_y = pan_y * (192.0/(double)height);
	
	draw(zoom);
}

void Panner::draw(u8 zoom) {
	u8 put_x, put_y;
	
	// Make sure the zoom area is inside the box completely
	if (pan_x+(width/zoom) > width) { pan_x = width - (width/zoom); real_pan_x = pan_x * (256.0/(double)width); }
	if (pan_y+(height/zoom) > height) { pan_y = height - (height/zoom); real_pan_y = pan_y * (192.0/(double)height); }
	
	for (put_x = x; put_x <= x+width; put_x++) {
		for (put_y = y; put_y <= y+height; put_y++) {
			screen->plot(put_x, put_y, 0, RGB15(31, 31, 31) | BIT(15));
		}
	}
	
	for (put_x = x+pan_x; put_x <= x+pan_x+(width/zoom); put_x++) {
		screen->plot(put_x, y+pan_y, 0, RGB15(31, 0, 0) | BIT(15));
		screen->plot(put_x, y+pan_y+(height/zoom), 0, RGB15(31, 0, 0) | BIT(15));
	}
	
	for (put_y = y+pan_y; put_y <= y+pan_y+(height/zoom); put_y++) {
		screen->plot(x+pan_x, put_y, 0, RGB15(31, 0, 0) | BIT(15));
		screen->plot(x+pan_x+(width/zoom), put_y, 0, RGB15(31, 0, 0) | BIT(15));
	}
}

bool Panner::update(u16 stylus_x, u16 stylus_y, u8 zoom) {
	if (keysHeld() & KEY_TOUCH && stylus_x >= x && stylus_x <= x+width && stylus_y >= y && stylus_y <= y+height) {
		pan_x = stylus_x - x - width/zoom/2;
		pan_y = stylus_y - y - height/zoom/2;

		if (pan_x < 0) { pan_x = 0; }
		if (pan_x > width - (width/zoom)) { pan_x = width - (width/zoom); }
		if (pan_y < 0) { pan_y = 0; }
		if (pan_y > height - (height/zoom)) { pan_y = height - (height/zoom); }
		
		real_pan_x = pan_x * (256.0/(double)width);
		real_pan_y = pan_y * (192.0/(double)height);
		
		draw(zoom);
		
		return true;
	} else {
		return false;
	}
}

