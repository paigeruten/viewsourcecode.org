// Copyright 2008 Jeremy Ruten

/*
	This file is part of DSlife.

	DSlife is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Foobar is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with DSlife.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <nds.h>
#include "screen.h"

Screen::Screen(u16 *screen_address, u16 *screen2_address) {
	// Main screen turn on
	videoSetMode(MODE_5_2D | DISPLAY_BG3_ACTIVE | DISPLAY_SPR_ACTIVE | DISPLAY_SPR_1D);
	vramSetBankA(VRAM_A_MAIN_BG_0x06000000);
	BACKGROUND.control[3] = BG_BMP16_256x256 | BG_BMP_BASE(0);
	BACKGROUND.bg3_rotation.xdy = 0;
	BACKGROUND.bg3_rotation.xdx = 1 << 8;
	BACKGROUND.bg3_rotation.ydx = 0;
	BACKGROUND.bg3_rotation.ydy = 1 << 8;
	
	// Sub screen
	videoSetModeSub(MODE_5_2D | DISPLAY_BG3_ACTIVE);
	vramSetBankC(VRAM_C_SUB_BG_0x06200000);
	BACKGROUND_SUB.control[3] = BG_BMP16_256x256 | BG_BMP_BASE(0);
	BACKGROUND_SUB.bg3_rotation.xdy = 0;
	BACKGROUND_SUB.bg3_rotation.xdx = 1 << 8;
	BACKGROUND_SUB.bg3_rotation.ydx = 0;
	BACKGROUND_SUB.bg3_rotation.ydy = 1 << 8;
	
	// Set screen pointers
	screens[SCREEN_BOTTOM] = screen2_address;
	screens[SCREEN_TOP] = screen_address;

	// Screens should not be swapped at this point
	screens_swapped = false;
}

void Screen::clear(u16 color, u8 which_screen) const {
	u16 i;

	switch (which_screen) {
		case 2:
			for (i = 0; i < SCREEN_WIDTH*SCREEN_HEIGHT; i++) {
				screens[SCREEN_BOTTOM][i] = color;
				screens[SCREEN_TOP][i] = color;
			}
			break;
		case 1:
			for (i = 0; i < SCREEN_WIDTH*SCREEN_HEIGHT; i++) {
				screens[SCREEN_TOP][i] = color;
			}
			break;
		case 0:
			for (i = 0; i < SCREEN_WIDTH*SCREEN_HEIGHT; i++) {
				screens[SCREEN_BOTTOM][i] = color;
			}
			break;
		default:
			;
	}
}

void Screen::plot(u8 x, u8 y, u8 screen, u16 color, u8 zoom) const {
	u16 put_x, put_y, is_grid;

	x *= zoom;
	y *= zoom;
	
	if (zoom >= 4) {
		is_grid = 1;
	} else {
		is_grid = 0;
	}

	for (put_x = x+is_grid; put_x < x+zoom; put_x++) {
		for (put_y = y+is_grid; put_y < y+zoom; put_y++) {
			plot(put_x, put_y, screen, color);
		}
	}
}
