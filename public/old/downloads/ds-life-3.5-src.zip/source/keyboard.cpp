// Copyright 2008 Jeremy Ruten

/*
	This file is part of DSlife.

	DSlife is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Foobar is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with DSlife.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <nds.h>
#include <fat.h>
#include <stdio.h>
#include "screen.h"
#include "font.h"
#include "keyboard.h"

Keyboard::Keyboard(char *filename, Screen *the_screen, Font *the_font, u8 the_key_width, u8 space_bar_width) {
	screen = the_screen;
	font = the_font;
	key_width = the_key_width;
	status = load_keyboard(filename);
	keyboard_x = 0;
	keyboard_y = 0;
	width_of_space_bar = space_bar_width;
	highlighted_key = '\0';
}

Keyboard::~Keyboard() {
}

char Keyboard::key_pressed(bool shift, u8 stylus_x, u8 stylus_y) {
	u8 which_keyboard, current_key_index = 0, put_x = keyboard_x, put_y = keyboard_y;
	char current_key;

	// Are they holding the shift key?
	if (shift) {
		which_keyboard = 1;
	} else {
		which_keyboard = 0;
	}

	// Loop through the keyboard keys
	while (keyboard[which_keyboard][current_key_index] != '\0') {
		current_key = keyboard[which_keyboard][current_key_index];

		if (current_key != '\t' && current_key != 5) {
			if (stylus_x > put_x && (stylus_x <= put_x+key_width || (current_key == ' ' && stylus_x <= put_x+key_width+width_of_space_bar)) && stylus_y > put_y && stylus_y <= put_y+key_width && (keysHeld() & KEY_TOUCH)) {
				print_key(current_key, put_x, put_y, true);
				highlighted_key = current_key;
				return current_key;
			} else if (highlighted_key == current_key) {
				print_key(current_key, put_x, put_y, false);
				highlighted_key = '\0';
			}
		}

		if (current_key == '\t') {
			put_x += key_width/2;
		} else if (current_key == 5) {
			put_x = keyboard_x;
			put_y += key_width;
		} else {
			put_x += key_width;
		}

		current_key_index++;
	}

	return '\0';
}

u8 Keyboard::load_keyboard(char *filename) {
	FILE *keyboardfile = fopen(filename, "r");
	u16 current_char_index = 0;
	char current_char;
	u8 current_keyboard = 0, done_loading = 0;
	bool do_not_fgetc = false;

	if (!keyboardfile) {
		return KEYBOARD_FILE_NOT_FOUND;
	}

	current_char = fgetc(keyboardfile);
	while (!feof(keyboardfile) && !done_loading) {
		if (current_char == '\\') {
			current_char = fgetc(keyboardfile);
			
			if (current_char == 'n') { current_char = '\n'; }
			if (current_char == 's') { current_char = ' '; }
			if (current_char == 'b') { current_char = '\b'; }
			if (current_char == '\\') { current_char = '\\'; }
			
			keyboard[current_keyboard][current_char_index] = current_char;
			current_char_index++;
		} else if (current_char == '\n') {
			current_char = fgetc(keyboardfile);
			if (current_char == '\n') {
				keyboard[current_keyboard][current_char_index] = '\0';
				if (current_keyboard == 0) {
					current_keyboard = 1;
					current_char_index = 0;
				} else {
					done_loading = 1;
				}
			} else {
				keyboard[current_keyboard][current_char_index] = 5;
				current_char_index++;
				do_not_fgetc = true;
			}
		} else if (current_char == ' ') {
			keyboard[current_keyboard][current_char_index] = '\t';
			current_char_index++;
		} else {
			keyboard[current_keyboard][current_char_index] = current_char;
			current_char_index++;
		}

		if (!do_not_fgetc) {
			current_char = fgetc(keyboardfile);
		} else {
			do_not_fgetc = false;
		}
	}

	fclose(keyboardfile);

	return KEYBOARD_OK;
}

void Keyboard::print_key(char key, u8 x, u8 y, bool highlighted) const {
	u8 i, put_x, put_y, which_screen, space_bar_width;
	u8 *font_widths = font->get_font_widths();
	u16 the_text_color, the_key_background_color;

	// In case screens are swapped, make sure the keyboard appears on the touch screen.
	if (screen->swapped()) {
		which_screen = 1;
	} else {
		which_screen = 0;
	}

	// Is it highlighted or no?
	if (highlighted) {
		the_text_color = highlight_text_color;
		the_key_background_color = highlight_key_background_color;
	} else {
		the_text_color = text_color;
		the_key_background_color = key_background_color;
	}

	// If the key is the space bar, make the key much longer
	if (key == ' ') {
		space_bar_width = width_of_space_bar;
	} else {
		space_bar_width = 0;
	}

	// Draw the border
	for (i = x; i <= x+key_width+space_bar_width; i++) {
		screen->plot(i, y, which_screen, line_color);
		screen->plot(i, y+key_width, which_screen, line_color);
	}
	for (i = y; i <= y+key_width; i++) {
		screen->plot(x, i, which_screen, line_color);
		screen->plot(x+key_width+space_bar_width, i, which_screen, line_color);
	}

	// Fill in the box
	for (put_x = x+1; put_x < x+key_width+space_bar_width; put_x++) {
		for (put_y = y+1; put_y < y+key_width; put_y++) {
			screen->plot(put_x, put_y, which_screen, the_key_background_color);
		}
	}

	// Draw the char in the middle of the key
	font->print_char(key, x + key_width/2 - font_widths[(int)key]/2, y + ((key_width - font->get_font_height()) / 2), which_screen, the_text_color);
}

void Keyboard::print_keyboard(bool shift) const {
	u8 which_keyboard, current_key_index = 0, put_x = keyboard_x, put_y = keyboard_y;
	char current_key;

	// Are they holding the shift key?
	if (shift) {
		which_keyboard = 1;
	} else {
		which_keyboard = 0;
	}

	// Loop through the keyboard keys
	while (keyboard[which_keyboard][current_key_index] != '\0') {
		current_key = keyboard[which_keyboard][current_key_index];

		if (current_key == '\t') {
			put_x += key_width/2;
		} else if (current_key == 5) {
			put_x = keyboard_x;
			put_y += key_width;
		} else {
			print_key(current_key, put_x, put_y);
			put_x += key_width;
		}

		current_key_index++;
	}
}

void Keyboard::set_colors(u16 line, u16 key_background, u16 text, u16 background, u16 highlight_key_background, u16 highlight_text) {
	line_color = line;
	key_background_color = key_background;
	text_color = text;
	background_color = background;
	highlight_key_background_color = highlight_key_background;
	highlight_text_color = highlight_text;
}
