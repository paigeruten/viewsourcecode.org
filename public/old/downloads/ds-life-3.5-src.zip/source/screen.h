// Copyright 2008 Jeremy Ruten

/*
	This file is part of DSlife.

	DSlife is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Foobar is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with DSlife.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef _screen_h
#define _screen_h

const u8 SCREEN_TOP = 1;
const u8 SCREEN_BOTTOM = 0;

class Screen {
	public:
		Screen(u16 *screen_address, u16 *screen2_address);
		~Screen();
		void clear(u16 color, u8 which_screen=2) const;
		void plot(u8 x, u8 y, u8 screen, u16 color) const { screens[screen][x + y * SCREEN_WIDTH] = color; }
		void plot(u8 x, u8 y, u8 screen, u16 color, u8 zoom) const;
		void swap() { lcdSwap(); screens_swapped = !screens_swapped; }
		bool swapped() const { return screens_swapped; }
		u16 get_pixel(u16 x, u16 y, u8 which_screen) { return screens[which_screen][x + y * 256]; }
	private:
		u16 *screens[2];
		bool screens_swapped;
};

#endif
