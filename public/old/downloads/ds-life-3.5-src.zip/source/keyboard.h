// Copyright 2008 Jeremy Ruten

/*
	This file is part of DSlife.

	DSlife is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Foobar is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with DSlife.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef _keyboard_h
#define _keyboard_h

enum { KEYBOARD_OK, KEYBOARD_FILE_NOT_FOUND };

class Keyboard {
	public:
		// Constructors
		Keyboard(char *filename, Screen *the_screen, Font *the_font, u8 the_key_width, u8 space_bar_width);
		~Keyboard();

		// Returns key that is currently pressed, and highlights/unhighlights it
		char key_pressed(bool shift, u8 stylus_x, u8 stylus_y);

		// Load keyboard layout from file
		u8 load_keyboard(char *filename);

		// Screen output
		void print_key(char key, u8 x, u8 y, bool highlighted=false) const;
		void print_keyboard(bool shift) const;

		// Accessors
		void set_colors(u16 line, u16 key_background, u16 text, u16 background, u16 highlight_key_background, u16 highlight_text);
		u8 get_status() const { return status; }
		u8 get_x() const { return keyboard_x; }
		u8 get_y() const { return keyboard_y; }
		void set_xy(u8 x, u8 y) { keyboard_x = x; keyboard_y = y; }
	private:
		Screen *screen;
		Font *font;
		char keyboard[2][255];
		u8 key_width;
		u8 status;
		u8 keyboard_x;
		u8 keyboard_y;
		u8 width_of_space_bar;
		char highlighted_key;

		// Keyboard colours
		u16 line_color;
		u16 key_background_color;
		u16 text_color;
		u16 background_color;
		u16 highlight_key_background_color;
		u16 highlight_text_color;
};

#endif
