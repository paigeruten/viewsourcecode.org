// Copyright 2008 Jeremy Ruten

/*
	This file is part of DSlife.

	DSlife is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Foobar is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with DSlife.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef _fileselect_h
#define _fileselect_h

class FileSelector {
	public:
		// Constructors
		FileSelector(Screen *the_screen, Font *the_font);
		~FileSelector();
		
		// Makes user select a file and returns the filename (or a null pointer on failure)
		char *select_file(char *dir_name);

		// Outputs files and scroll bar to screen
		void list_files(u8 start, u8 last, u8 selected_file);
		void update_scrollbar(u8 scroll_pos, u16 color);
	private:
		Screen *screen;
		Font *font;
		char files[256][32];
};

#endif

