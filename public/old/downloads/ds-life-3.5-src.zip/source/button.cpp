// Copyright 2008 Jeremy Ruten

/*
	This file is part of DSlife.

	DSlife is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Foobar is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with DSlife.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <nds.h>
#include <string.h>
#include <stdlib.h>
#include "screen.h"
#include "font.h"
#include "keyboard.h"
#include "button.h"

Button::Button(char *the_text, Screen *the_screen, Font *the_font, u8 the_which_screen, u8 x_pos, u8 y_pos) {
	strcpy(text, the_text);
	screen = the_screen;
	font = the_font;
	which_screen = the_which_screen;
	x = x_pos;
	y = y_pos;
	width = 6 + font->string_width(text, strlen(text));
	height = 6 + font->get_font_height();
}

Button::~Button() {
}

bool Button::check(u8 stylus_x, u8 stylus_y) {
	if (stylus_x >= x && stylus_x <= x+width && stylus_y >= y && stylus_y <= y+height && keysHeld() & KEY_TOUCH) {
		if (!is_highlighted) {
			is_highlighted = true;
			draw();
		}

		return true;
	} else {
		if (is_highlighted) {
			is_highlighted = false;
			draw();
		}

		return false;
	}
}

void Button::toggle_check(u8 stylus_x, u8 stylus_y) {
	if (stylus_x >= x && stylus_x <= x+width && stylus_y >= y && stylus_y <= y+height && keysDown() & KEY_TOUCH) {
		is_highlighted = !is_highlighted;
		draw();
	}
}

void Button::draw() {
	u8 i, put_x, put_y;
	u16 the_text_color, the_background_color, the_bordercolor;

	// Is it highlighted or no?
	if (is_highlighted) {
		the_text_color = highlight_fontcolor;
		the_background_color = highlight_bgcolor;
		the_bordercolor = highlight_bordercolor;
	} else {
		the_text_color = fontcolor;
		the_background_color = bgcolor;
		the_bordercolor = bordercolor;
	}

	// Draw the border
	for (i = x; i <= x+width; i++) {
		screen->plot(i, y, which_screen, the_bordercolor);
		screen->plot(i, y+height, which_screen, the_bordercolor);
	}
	for (i = y; i <= y+height; i++) {
		screen->plot(x, i, which_screen, the_bordercolor);
		screen->plot(x+width, i, which_screen, the_bordercolor);
	}

	// Fill in the box
	for (put_x = x+1; put_x < x+width; put_x++) {
		for (put_y = y+1; put_y < y+height; put_y++) {
			screen->plot(put_x, put_y, which_screen, the_background_color);
		}
	}

	// Output the button text
	font->print_string_xy(text, x+3, y+3, which_screen, the_text_color);
}

void Button::set_text(char *new_text) {
	strcpy(text, new_text);
}
