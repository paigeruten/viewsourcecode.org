// Copyright 2008 Jeremy Ruten

/*
	This file is part of DSlife.

	DSlife is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Foobar is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with DSlife.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef _str_h
#define _str_h

s32 intval(char *string);
char *strval(u32 num);
bool is_numeric(char *string);
void chop(char *string);
s32 strpos(const char *haystack, const char *needle, u32 offset);
char *substr(const char *string, u32 start, u32 end);

#endif
