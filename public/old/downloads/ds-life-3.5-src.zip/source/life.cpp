// Copyright 2008 Jeremy Ruten

/*
	This file is part of DSlife.

	DSlife is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Foobar is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with DSlife.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <nds.h>
#include <fat.h>
#include <stdio.h>
#include <string.h>
#include "screen.h"
#include "font.h"
#include "life.h"
#include "str.h"

bool in_array(u8 needle, u8 *haystack) {
	u8 current_num = 0;

	while (haystack[current_num] != 255) {
		if (needle == haystack[current_num]) {
			return true;
		}
		current_num++;
	}

	return false;
}

Life::Life(Screen *the_screen, Font *the_font) {
	u16 put_x, put_y;

	screen = the_screen;
	font = the_font;

	life = new u8 [256*192];
	temp_life = new u8 [256*192];

	// Fill life array with zeroes (dead cells)
	for (put_x = 0; put_x <= 255; put_x++) {
		for (put_y = 0; put_y <= 191; put_y++) {
			life[put_x + put_y * 256] = 0;
		}
	}

	set_rules("23/3");
	zoom = 1;
	pan_x = 0;
	pan_y = 0;
	generation = 0;
	population = 0;
}

Life::~Life() {
	delete [] life;
	life = 0;
	delete [] temp_life;
	temp_life = 0;
}

void Life::set_rules(char *the_rules) {
	u8 current_char = 0, rule_side = 0, rule_index = 0;

	while (the_rules[current_char] != '\0') {
		if (the_rules[current_char] == '/') {
			rules[rule_side][rule_index] = 255;
			rule_side = 1;
			rule_index = 0;
		} else {
			rules[rule_side][rule_index] = the_rules[current_char] - 48;
			rule_index++;
		}

		current_char++;
	}
	
	rules[rule_side][rule_index] = 255;
}

void Life::generate() {
	u16 cell_x, cell_y;
	u8 num_neighbours;

	population = 0;

	for (cell_x = 1; cell_x < 255; cell_x++) {
		for (cell_y = 1; cell_y < 191; cell_y++) {
			num_neighbours = life[(cell_x-1) + (cell_y-1) * 256] + 
			                 life[(cell_x-1) + (cell_y) * 256] + 
			                 life[(cell_x-1) + (cell_y+1) * 256] + 
			                 life[(cell_x) + (cell_y-1) * 256] + 
			                 life[(cell_x) + (cell_y+1) * 256] + 
			                 life[(cell_x+1) + (cell_y-1) * 256] + 
			                 life[(cell_x+1) + (cell_y) * 256] + 
			                 life[(cell_x+1) + (cell_y+1) * 256];
			

			if (life[cell_x + cell_y * 256] == 1) {
				if (!in_array(num_neighbours, &rules[0][0])) {
					temp_life[cell_x + cell_y * 256] = 0;
				} else {
					temp_life[cell_x + cell_y * 256] = 1;
					population++;
				}
			} else {
				if (in_array(num_neighbours, &rules[1][0])) {
					temp_life[cell_x + cell_y * 256] = 1;
					population++;
				} else {
					temp_life[cell_x + cell_y * 256] = 0;
				}
			}
		}
	}

	// Copy temp_life[][] to life[][]
	for (cell_x = 1; cell_x < 255; cell_x++) {
		for (cell_y = 1; cell_y < 191; cell_y++) {
			life[cell_x + cell_y * 256] = temp_life[cell_x + cell_y * 256];
		}
	}

	generation++;
}

void Life::update() const {
	u16 put_x, put_y, put_x_max = pan_x+256/zoom, put_y_max = pan_y+192/zoom;
	u16 colours[2] = { RGB15(31, 31, 31) | BIT(15), RGB15(0, 0, 0) | BIT(15) };
	
	if (zoom == 1) {
		for (put_x = pan_x; put_x < put_x_max; put_x++) {
			for (put_y = pan_y; put_y < put_y_max; put_y++) {
				screen->plot(put_x, put_y, 1, colours[life[put_x + put_y * 256]]);
			}
		}
	} else {
		for (put_x = pan_x; put_x < put_x_max; put_x++) {
			for (put_y = pan_y; put_y < put_y_max; put_y++) {
				screen->plot(put_x-pan_x, put_y-pan_y, 1, colours[life[put_x + put_y * 256]], zoom);
			}
		}
	}
}

void Life::draw_grid() const {
	u16 put_x, put_y;

	if (zoom >= 4) {
		// Draw lats
		for (put_x = 0; put_x < 256; put_x += zoom) {
			for (put_y = 0; put_y < 192; put_y++) {
				screen->plot(put_x, put_y, 1, RGB15(23, 23, 23) | BIT(15));
			}
		}
		
		// Draw longs
		for (put_y = 0; put_y < 192; put_y += zoom) {
			for (put_x = 0; put_x < 256; put_x++) {
				screen->plot(put_x, put_y, 1, RGB15(23, 23, 23) | BIT(15));
			}
		}
	}
}

void Life::reset() {
	u16 put_x, put_y;

	// Fill life array with zeroes (dead cells)
	for (put_x = 0; put_x <= 255; put_x++) {
		for (put_y = 0; put_y <= 191; put_y++) {
			life[put_x + put_y * 256] = 0;
		}
	}
	
	pan_x = 0;
	pan_y = 0;
	zoom = 1;
	generation = 0;
	population = 0;
}

void Life::draw_life(u8 stylus_x, u8 stylus_y, bool erase) {
	u16 index = (pan_x+stylus_x/zoom) + (pan_y+stylus_y/zoom) * 256;

	if (erase) {
		if (life[index] == 1) { population--; }
		life[index] = 0;
		screen->plot(stylus_x/zoom, stylus_y/zoom, 1, RGB15(31, 31, 31) | BIT(15), zoom);
	} else {
		if (life[index] == 0) { population++; }
		life[index] = 1;
		screen->plot(stylus_x/zoom, stylus_y/zoom, 1, RGB15(0, 0, 0) | BIT(15), zoom);
	}
}

void Life::draw_life_line(u8 stylus_x, u8 stylus_y, u8 stylus_last_x, u8 stylus_last_y, bool erase) {	
	int i, dx, dy, sdx, sdy, dxabs, dyabs, x, y, px, py;

	dx = stylus_x-stylus_last_x;
	dy = stylus_y-stylus_last_y;
	dxabs = dx;
	sdx = 1;
	
	if (dx < 0) {
		dxabs = -dx;
		sdx = -1;
	}

	dyabs = dy;
	sdy = 1;
	
	if (dy < 0) {
		dyabs = -dy;
		sdy = -1;
	}

	x = dyabs>>1;
	y = dxabs>>1;
	px = stylus_last_x;
	py = stylus_last_y;

	draw_life(px, py, erase);

	if (dxabs >= dyabs) {
		for (i = 0; i < dxabs; i++) {
			y += dyabs;
			
			if (y >= dxabs) {
				y -= dxabs;
				py += sdy;
			}
			
			px += sdx;
			draw_life(px, py, erase);
		}
	} else {
		for (i = 0; i < dyabs; i++) {
			x += dxabs;
			
			if (x >= dyabs) {
				x -= dyabs;
				px += sdx;
			}

			py += sdy;
			draw_life(px, py, erase);
		}
	}
}

bool Life::save(char *filename) {
	u16 get_x, get_y;
	char buffer[255];
	
	strcpy(buffer, "/data/life/patterns/");
	strcat(buffer, filename);
	FILE *life_file = fopen(buffer, "w");
	
	if (!life_file) { return false; }
	
	strcpy(buffer, "#Life 1.06\n");
	fwrite(buffer, sizeof(char), strlen(buffer), life_file);
	
	for (get_x = 0; get_x < 256; get_x++) {
		for (get_y = 0; get_y < 192; get_y++) {
			if (life[get_x + get_y * 256] == 1) {
				strcpy(buffer, strval(get_x));
				strcat(buffer, " ");
				strcat(buffer, strval(get_y));
				strcat(buffer, "\n");
				
				fwrite(buffer, sizeof(char), strlen(buffer), life_file);
			}
		}
	}
	
	fclose(life_file);
	
	return true;
}

bool Life::load(char *filename) {
	char buffer[255];
	
	strcpy(buffer, "/data/life/patterns/");
	strcat(buffer, filename);
	FILE *life_file = fopen(buffer, "r");
	
	if (!life_file) { return false; }

	// Skip the comment at the top	
	fgets(buffer, 255, life_file);

	reset();
	
	while (!feof(life_file)) {
		fgets(buffer, 255, life_file);
		life[intval(substr(buffer, 0, strpos(buffer, " ", 0) - 1)) + intval(substr(buffer, strpos(buffer, " ", 0) + 1, strlen(buffer)-2)) * 256] = 1;
	}
		
	fclose(life_file);
	
	return true;
}

void Life::update_population() {
	u16 put_x, put_y;
	
	population = 0;

	for (put_x = 0; put_x <= 255; put_x++) {
		for (put_y = 0; put_y <= 191; put_y++) {
			population += life[put_x + put_y * 256];
		}
	}
}

