// Copyright 2008 Jeremy Ruten

/*
	This file is part of DSlife.

	DSlife is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Foobar is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with DSlife.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef _panner_h
#define _panner_h

class Panner {
	public:
		// Constructors
		Panner(Screen *the_screen, u8 the_x, u8 the_y, u8 the_width, u8 the_height);
		~Panner();
		
		// Accessors
		u8 get_pan_x() const { return real_pan_x; }
		u8 get_pan_y() const { return real_pan_y; }
		void set_pan(s8 new_pan_x, s8 new_pan_y, u8 zoom);
		
		// Draw it to the screen
		void draw(u8 zoom);
		
		// Update pan_x and pan_y to stylus position
		bool update(u16 stylus_x, u16 stylus_y, u8 zoom);
	private:
		Screen *screen;
		u8 x;
		u8 y;
		u8 width;
		u8 height;
		s16 pan_x;
		s16 pan_y;
		u8 real_pan_x;
		u8 real_pan_y;
};

#endif

