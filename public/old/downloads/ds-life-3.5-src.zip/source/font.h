// Copyright 2008 Jeremy Ruten

/*
	This file is part of DSlife.

	DSlife is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Foobar is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with DSlife.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef _font_h
#define _font_h

enum { FONT_OK, ERR_FILE_NOT_FOUND, ERR_INVALID_FONT_FILE, ERR_ALLOC_MEMORY };

const u16 TRANSPARENT = 0;

class Font {
	public:
		// Constructors
		Font(char *fontfile, Screen *the_screen);
		~Font();

		// Accessors
		u8 get_space_between_chars() const { return space_between_chars; }
		void set_space_between_chars(u8 sbc) { space_between_chars = sbc; }
		u8 get_status() const { return status; }
		u8 get_font_height() const { return font_height; }
		u8 get_font_width() const { return font_width; }
		u8 *get_font_widths() { return font_widths; }

		// Load font from file
		u8 load_font(char *filename);

		// Printing characters/strings/numbers
		void print_char(char character, u8 x, u8 y, u8 which_screen, u16 color = RGB15(0, 0, 0) | BIT(15), u16 bgcolor = TRANSPARENT) const;
		void print_string_xy(char *string, u8 x, u8 y, u8 which_screen, u16 color = RGB15(0, 0, 0) | BIT(15), u16 bgcolor = TRANSPARENT) const;
		void print_string_highlighted(char *string, u8 x, u8 y, u8 which_screen, u16 highlight_start, u16 highlight_end, u16 color = RGB15(0, 0, 0) | BIT(15), u16 bgcolor = RGB15(31, 31, 31) | BIT(15), u16 highlight_color = RGB15(31, 31, 31) | BIT(15), u16 highlight_bgcolor = RGB15(0, 0, 0) | BIT(15)) const;
		void print_string_center(char *string, u8 y, u8 which_screen, u16 color = RGB15(0, 0, 0) | BIT(15), u16 bgcolor = TRANSPARENT) const;
		void print_number(s32 num, u8 x, u8 y, u8 which_screen, u16 color = RGB15(0, 0, 0) | BIT(15), u16 bgcolor = TRANSPARENT) const;
		
		// Returns width of string in pixels
		u32 string_width(char *string, u8 length) const;
	private:
		u8 *font;
		u8 font_widths[128];
		u8 space_between_chars;
		u8 font_height;
		u8 font_width;
		Screen *screen;
		u8 status;
};

#endif
