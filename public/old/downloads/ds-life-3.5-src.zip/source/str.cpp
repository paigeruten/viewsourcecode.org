// Copyright 2008 Jeremy Ruten

/*
	This file is part of DSlife.

	DSlife is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Foobar is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with DSlife.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <nds.h>
#include <string.h>
#include "str.h"

s32 intval(char *string) {
	u32 num = 0, current_char = 0;
	
	if (!is_numeric(string)) {
		return -1;
	}

	while (string[current_char] != '\0') {
		num *= 10;
		num += (int)string[current_char] - 48;
		current_char++;
	}
	
	return num;
}

char *strval(u32 num) {
	char numstring[10] = "";
	u32 number = num, quotient = 1, remainder = 0;
	char remainder_str[3] = "";
	u32 current_char = 0, current_char2 = 0;
	static char string[100];
	
	if (number == 0) {
		strcpy(string, "0");
	} else {
		while (quotient != 0) {
			remainder = number % 10;
			quotient = number / 10;
			remainder_str[0] = remainder+48;
			remainder_str[1] = '\0';
			strcat(numstring, remainder_str);
			number = quotient;
		}
		
		current_char = strlen(numstring)-1;
		while (current_char != 0) {
			string[current_char2] = numstring[current_char];
			current_char--;
			current_char2++;
		}
		string[current_char2] = numstring[current_char];
		string[current_char2 + 1] = '\0';
	}
	
	return string;
}

bool is_numeric(char *string) {
	u32 current_char = 0;

	while (string[current_char]) {
		if (string[current_char] < 48 || string[current_char] > 57) {
			return false;
		}
		current_char++;
	}

	return true;
}

void chop(char *string) {
	string[strlen(string)-1] = '\0';
}

s32 strpos(const char *haystack, const char *needle, u32 offset) {
	u32 current_char = offset;
	
	while (haystack[current_char] != '\0') {
		if (!strcmp(needle, substr(haystack, current_char, current_char+strlen(needle)-1))) {
			return current_char;
		}
		current_char++;
	}
	
	return -1;
}

char *substr(const char *string, u32 start, u32 end) {
	u32 current_char, current_char2 = 0;
	static char substring[2048];
	
	for (current_char = start; current_char <= end && string[current_char] != '\0'; current_char++) {
		substring[current_char2] = string[current_char];
		current_char2++;
	}
	
	substring[current_char2] = '\0';
	
	return substring;
}

