<?php

// To convert screen shot called 'blah', type 'screenshotter.php?source=blah' into address bar.
$image_source = (isset($_GET['source'])) ? $_GET['source'] : 'screenshot';

$image = imagecreatetruecolor(256, 192*2) or die('Cannot Initialize new GD image stream');

$source = fopen($image_source, 'rb');
$pixels = fread($source, 2 *         // 2 bytes per pixel
                         2 *         // 2 screens
                         256 * 192   // 256*192 pixels on the screen
	       );
fclose($source);

// Convert each pair of bytes into one 2-byte value, putting them in $temp_pixels
$temp_pixels = array();
for ($i = 0; $i < strlen($pixels); $i += 2) {
	array_push($temp_pixels, ord($pixels[$i]) + (ord($pixels[$i+1]) << 8));
}

// For each pixel, plot it on the image
$pixels = $temp_pixels;
$x = 0;
$y = 0;
foreach ($pixels as $pixel) {
	// Lowest 5 bits are the red value, next 5 bits are the green value, next 5 bits are the blue value, and highest bit is the "Alpha" which we don't really need.
	$r = intval(($pixel & 31) * 8.2258); // Multiplying by 8.2258 should change a x/31 value into a x/255 value.
	$g = intval((($pixel & 31<<5) >> 5) * 8.2258);
	$b = intval((($pixel & 31<<10) >> 10) * 8.2258);
	
	imagesetpixel($image, $x, $y, imagecolorallocate($image, $r, $g, $b));
	
	$x++;
	
	// If we're at the end of the screen, move to the next line.
	if ($x == 256) {
		$x = 0;
		$y++;
	} 
}

header('Content-type: image/png');
imagepng($image);
imagedestroy($image);

?>
