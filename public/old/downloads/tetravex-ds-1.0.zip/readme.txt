Tetravex for DS by Jeremy Ruten (jeremy.ruten@gmail.com)

How to play:
-----------

Move all the tiles from the bottom screen to the top screen to win. You can
only place a tile on the top screen grid if the numbers on the tile match
up to the numbers on the tiles next to it (unless there are no tiles.)

Read http://en.wikipedia.org/wiki/Tetravex for more information.

Controls:
--------

To move a tile from the touch screen to the top screen, tap and hold the
tile on the bottom screen and drag the stylus to where you want to place
the tile, then let go of the stylus to place it. A border around the tile
will tell you if you are allowed to place the tile: red if you aren't
allowed, green if you are.

If you want to move a tile from the top screen back to the bottom screen,
you need to switch screens using either L or R (shoulder buttons.) Then you
can move the tiles in the same way as you normally would.

To move all the tiles on the top screen at once, use the D-pad.

To start a new game press A. To start a new game with a different board
size, press X to increase the size or Y to decrease the size. The sizes go
from 2x2 to 6x6.

To get a hint (have a tile move to the right place for you) press B, but you
can only do this before you start placing tiles yourself.
