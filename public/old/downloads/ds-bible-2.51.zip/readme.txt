--------------------------------------------------------------------------------

                      DSbible by Jeremy Ruten (Jeremysr)
                           jeremy.ruten@gmail.com
                                 Version 2.5

--------------------------------------------------------------------------------

Installation
------------

  1. DLDI-patch bible.nds.
  2. Copy bible.nds to your storage device.
  3. Copy 'bible' folder to the root directory of your storage device. (If you
     already have an old version, delete it and move new folder to your storage
     device.)
  3. Run bible.nds.
  4. The first time you run it, you will have to select a language. Your
     language can be changed later by pressing the Preferences button in the
     text viewer.

Main Menu
---------

  1. Change the Bible translation by holding the stylus on the select box, and
     dragging it to the translation you want. DSbible will remember which one
     you select so you don't have to change every time you start up the program.
  2. Press one of the four buttons on the touch screen, depending on what you
     want to do:

Select a Book
-------------

  All the books in the Old Testament and New Testament of the Bible will be
  shown on the touch screen. Select one by tapping on it with the stylus twice,
  or press up and down on the D-Pad and press A to select. To scroll, use the
  scroll bar on the right.

Look Up a Verse
---------------

  Type in a location in the Bible you want to read. It can be the name of a book
  (like "Genesis"), the name of a book and a chapter (like "Genesis 1"), or the
  name of a book and a chapter and a verse (like "Genesis 1:1"). When you start
  typing the name of the book, the keyboard will guess what book you want and
  autocomplete it for you, so you don't have to worry too much about spelling.
  If it guesses wrong, you can just keep typing and it'll keep guessing.

Search Bible
------------

  Type in your search terms seperated by spaces and press enter. DSbible will
  search through the Bible translation you have loaded and look for verses
  containing at least one of your search terms. After searching, you can select
  one of the search results and DSbible will jump to that verse. The words you
  searched for will be highlighted in a red/orange colour. While in the text
  viewer, pressing X will return to the search results.

Bookmarks
---------

  You can bookmark books, chapters, and verses. To add a bookmark, select "Add
  Bookmark" and type in a location in the format described above, in "Look Up a
  Verse". If you go to bookmarks in the text viewer, the verse that you're
  currently at will be appear in the textbox. To load a bookmark, select "Load
  Bookmark" and select a bookmark to load. Bookmarked verses will be highlighted
  in yellow in the text viewer.

The Text Viewer
---------------

  1. The title bar at the top displays your current location in a format like
     "Genesis 1:1".
  2. If the translation supports footnotes, footnotes will appear in { curly
     braces } inline with the text and will be highlighted in orange.
  2. There are four ways of scrolling through text.
       1. The D-Pad: Press up or down to scroll line by line. Press left or
          right to scroll page by page.
       2. The scrollbar: There is a scrollbar on the right. Drag the black
          rectangle up or down to scroll.
       3. The buttons: The two buttons on the far left at the bottom of the
          screen skip to the previous chapter and the next chapter.
       4. Moonshell style: Drag the stylus on the text to scroll.
  3. If you have done a search, press X to return to the search results.
  4. There are 8 buttons at the bottom of the touch screen.
       1. Previous Chapter (a left arrow)
       2. Next Chapter (a right arrow)
       3. Look Up a Verse (an opened book)
       4. Search Bible (a pair of binoculars)
       5. Select a Book (a bulleted list)
       6. Bookmarks (a star)
       7. Translations (the acronyms "BBE" and "KJV")
       8. Preferences (a wrench)

The Keyboard
------------

  1.  Hold down L or R to type in special symbols and non-English letters.
  2.  Left and Right on the D-Pad move the cursor left or right.
  3.  Up on the D-Pad moves the cursor all the way to the left like the Home key.
  4.  Down on the D-Pad moves the cursor all the way to the right like the End
      key.
  5.  A is a shortcut for the enter key, B is a shortcut for the backspace.
  6.  Tapping the text in the textbox will move the cursor in between the letters
      you tapped.
  7.  Dragging text in the textbox will highlight text.
  8.  Select will copy the highlighted text, X will cut the highlighted text.
  9.  Start will paste text.
  10. Press the "Cancel" button to go back to where you were.

Translations
------------

  DSbible comes with 4 translations (3 English, 1 French), and they all take up
  about 4MB of space. If you want to free up space by removing a translation,
  you can just delete it from the /bible/translations directory.
  
  If you want to add a translation, it must be formatted correctly (see next
  section) and then put into the translations directory.
  
The Translation Format
----------------------

  Each translation is in a single text file. The first line of the file is the
  name of the translation. The next line contains the short and long names of
  the books, like this:
  
  /Genesis/Gen/Exodus/Exo/Leviticus/Lev/Numbers/Num/.../Revelation/Rev/
  
  After that, put all the verses seperated by newlines in this format:
  
  Gen 1:1 In the beginning God created the heavens and the earth.
  Gen 1:2 Now the earth was formless and empty. Darkness was on the surface of the deep. God's Spirit was hovering over the surface of the waters. |
  
  You may put slashes (/) to insert a newline, or a pipe symbol (|) to start a
  new paragraph. To insert footnotes, put it inline with the text and inside
  curly braces ({}). Here's a verse that demonstrates everything:
  
  Pro 1:12 let's swallow them up alive like Sheol {Sheol is the place of the dead.}, / and whole, like those who go down into the pit. |
  
  Note: If you are adding a translation in a non-English language, make sure the
  character encoding is set to ISO 8859-1.
  
Language Files
--------------

  If you want to translate DSbible itself to another language, go to the
  /bible/lang directory, copy and paste one of the language files and translate
  the pasted one to your language.

Thanks
------

  Thank you Josiah for creating the logo!
  Thank you Sebastiaan Leenders for reporting a major bug and helping me fix it!
  Thank you JMS for formatting the French translation and translating DSbible to French!

