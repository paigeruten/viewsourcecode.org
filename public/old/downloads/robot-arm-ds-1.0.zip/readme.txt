Robot Arm DS by Jeremy Ruten (Jeremysr)

Note: Robot Arm was a QBasic game that someone named Robin Ohm made. You can find the program here: http://www.euronet.nl/users/rkohm/software/download.htm

The help and credits are built into the game, so just put it on your DS and run it!

If you want to contact me, e-mail me here: jeremy.ruten@gmail.com
