void drawTile(u8 screen, u8 x, u8 y, u8 n1, u8 n2, u8 n3, u8 n4);
void drawTriangle(u8 screen, u8 x, u8 y, u8 section, u8 num);
void eraseTile(u8 screen, u8 x, u8 y);
void updateGrid(u8 screen);
void drawGrids();
void eraseGrids(void);
void drawBox(u8 screen, u8 x, u8 y, u8 r, u8 g, u8 b);
