// Tetravex DS by Jeremy Ruten (jeremy.ruten@gmail.com)
// October 1, 2007

#include "main.h"
#include "game.h"

int main(void) {
	irqInit();
	irqEnable(IRQ_VBLANK);
	
	setupScreens();
	splashScreen();
	menu();
	
	return 0;
}
