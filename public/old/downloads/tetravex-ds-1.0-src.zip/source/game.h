void splashScreen();
void setupScreens();
void game();
void touchedbox(u8 stylusx, u8 stylusy, s8 *gridxy);
void clearScreens();
void hint();
s8 is_valid_tile(s8 x, s8 y, s8 n_top, s8 n_right, s8 n_bottom, s8 n_left);
void menu();
