#include "main.h"
#include "puzzle.h"
#include "tile.h"

void loadPuzzle() {
	u8 x, y, i, j, x1, x2, y1, y2;
	s8 tile_values[4];
	
	clearPuzzle();
		
	for (x = 0; x < dimensions; x++) {
		for (y = 0; y < dimensions; y++) {
			// Check left side
			if (x != 0) {
				if (puzzle[x-1][y][TILE_TOP] != -1) {
					puzzle[x][y][TILE_LEFT] = puzzle[x-1][y][TILE_RIGHT];
				} else {
					randomTileNum(x, y, TILE_LEFT);
				}
			} else {
				randomTileNum(x, y, TILE_LEFT);
			}
			
			// Check top side
			if (y != 0) {
				if (puzzle[x][y-1][TILE_TOP] != -1) {
					puzzle[x][y][TILE_TOP] = puzzle[x][y-1][TILE_BOTTOM];
				} else {
					randomTileNum(x, y, TILE_TOP);
				}
			} else {
				randomTileNum(x, y, TILE_TOP);
			}
			
			// Check right side
			if (x != dimensions-1) {
				if (puzzle[x+1][y][TILE_TOP] != -1) {
					puzzle[x][y][TILE_RIGHT] = puzzle[x+1][y][TILE_LEFT];
				} else {
					randomTileNum(x, y, TILE_RIGHT);
				}
			} else {
				randomTileNum(x, y, TILE_RIGHT);
			}
			
			// Check bottom side
			if (y != dimensions-1) {
				if (puzzle[x][y+1][TILE_TOP] != -1) {
					puzzle[x][y][TILE_BOTTOM] = puzzle[x][y+1][TILE_TOP];
				} else {
					randomTileNum(x, y, TILE_BOTTOM);
				}
			} else {
				randomTileNum(x, y, TILE_BOTTOM);
			}
		}
	}

	// Make a copy of it as the solution
	for (x = 0; x < dimensions; x++) {
		for (y = 0; y < dimensions; y++) {
			for (i = 0; i <= 3; i ++) {
				original_puzzle[x][y][i] = puzzle[x][y][i];
			}
		}
	}

	// Mix up the tiles randomly
	for (i = 0; i < (dimensions^2)*10; i++) {
		// Get first tile
		x1 = (a_seed() % (dimensions));
		y1 = (a_seed() % (dimensions));
		
		// Store first tile's values
		tile_values[0] = puzzle[x1][y1][0];
		tile_values[1] = puzzle[x1][y1][1];
		tile_values[2] = puzzle[x1][y1][2];
		tile_values[3] = puzzle[x1][y1][3];

		// Get second tile
		x2 = (a_seed() % (dimensions-1));
		y2 = (a_seed() % (dimensions-1));
		
		// Switch places
		for (j = 0; j <= 3; j++) {
			puzzle[x1][y1][j] = puzzle[x2][y2][j];
			puzzle[x2][y2][j] = tile_values[j];
		}
	}
}

void clearPuzzle() {
	u8 x, y, i;
	
	for (y = 0; y < 6; y++) {
		for (x = 0; x < 6; x++) {
			for (i = 0; i <= 3; i++) {
				puzzle[x][y][i] = -1;
				solution[x][y][i] = -1;
			}
		}
	}
}

void addTile(u8 screen, u8 x, u8 y, u8 n1, u8 n2, u8 n3, u8 n4) {
	if (screen == SCREEN_TOP) {
		solution[x][y][0] = n1;
		solution[x][y][1] = n2;
		solution[x][y][2] = n3;
		solution[x][y][3] = n4;
	} else {
		puzzle[x][y][0] = n1;
		puzzle[x][y][1] = n2;
		puzzle[x][y][2] = n3;
		puzzle[x][y][3] = n4;
	}
	
	drawTile(screen, x, y, n1, n2, n3, n4);
}

void removeTile(u8 screen, u8 x, u8 y) {
	u8 i;

	for (i = 0; i <= 3; i++) {
		if (screen == SCREEN_TOP) {
			solution[x][y][i] = -1;
		} else {
			puzzle[x][y][i] = -1;
		}
	}
	
	eraseTile(screen, x, y);
}

void moveAll(u8 direction) {
	s8 x, y, i, can_move = 1;
	
	switch (direction) {
		case DIRECTION_UP:
			// Check for tiles that can't move up
			for (i = 0; i < dimensions; i++) {
				if (solution[i][0][0] != -1) { can_move = 0; }
			}
			
			if (can_move) {
				for (y = 0; y < dimensions-1; y++) {
					for (x = 0; x < dimensions; x++) {
						for (i = 0; i <= 3; i++) {
							solution[x][y][i] = solution[x][y+1][i];
						}
					}
				}
				
				for (x = 0; x < dimensions; x++) {
					for (i = 0; i <= 3; i++) {
						solution[x][dimensions-1][i] = -1;
					}
				}
			}
			break;
		case DIRECTION_RIGHT:
			// Check for tiles that can't move right
			for (i = 0; i < dimensions; i++) {
				if (solution[dimensions-1][i][0] != -1) { can_move = 0; }
			}
			
			if (can_move) {
				for (x = dimensions-1; x >= 0; x--) {
					for (y = 0; y < dimensions; y++) {
						for (i = 0; i <= 3; i++) {
							solution[x][y][i] = solution[x-1][y][i];
						}
					}
				}
				
				for (y = 0; y < dimensions; y++) {
					for (i = 0; i <= 3; i++) {
						solution[0][y][i] = -1;
					}
				}
			}
			break;
		case DIRECTION_DOWN:
			// Check for tiles that can't move down
			for (i = 0; i < dimensions; i++) {
				if (solution[i][dimensions-1][0] != -1) { can_move = 0; }
			}
			
			if (can_move) {
				for (y = dimensions-1; y >= 0; y--) {
					for (x = 0; x < dimensions; x++) {
						for (i = 0; i <= 3; i++) {
							solution[x][y][i] = solution[x][y-1][i];
						}
					}
				}
				
				for (x = 0; x < dimensions; x++) {
					for (i = 0; i <= 3; i++) {
						solution[x][0][i] = -1;
					}
				}
			}
			break;
		case DIRECTION_LEFT:
			// Check for tiles that can't move right
			for (i = 0; i < dimensions; i++) {
				if (solution[0][i][0] != -1) { can_move = 0; }
			}
			
			if (can_move) {
				for (x = 0; x < dimensions-1; x++) {
					for (y = 0; y < dimensions; y++) {
						for (i = 0; i <= 3; i++) {
							solution[x][y][i] = solution[x+1][y][i];
						}
					}
				}
				
				for (y = 0; y < dimensions; y++) {
					for (i = 0; i <= 3; i++) {
						solution[dimensions-1][y][i] = -1;
					}
				}
			}
			break;
	}
	
	updateGrid(SCREEN_TOP);
}

void randomTileNum(u8 x, u8 y, u8 position) {
	puzzle[x][y][position] = (a_seed() % 10);
}

u8 a_seed() {
	return rand()+rand();
}
