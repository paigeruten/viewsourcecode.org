#include <stdio.h>
#include <string.h>
#include "main.h"
#include "font.h"
#include "fontdata.h"

u8 numbers[10][6][6] = {
	// 0
	{
		{ 0,0,1,1,0,0 },
		{ 0,1,0,0,1,0 },
		{ 0,1,0,0,1,0 },
		{ 0,1,0,0,1,0 },
		{ 0,1,0,0,1,0 },
		{ 0,0,1,1,0,0 }
	},
	
	// 1
	{
		{ 0,0,0,1,0,0 },
		{ 0,0,1,1,0,0 },
		{ 0,0,0,1,0,0 },
		{ 0,0,0,1,0,0 },
		{ 0,0,0,1,0,0 },
		{ 0,0,1,1,1,0 }
	},
	
	// 2
	{
		{ 0,0,1,1,0,0 },
		{ 0,1,0,0,1,0 },
		{ 0,0,0,1,0,0 },
		{ 0,0,1,0,0,0 },
		{ 0,1,0,0,0,0 },
		{ 0,1,1,1,1,0 }
	},
	
	// 3
	{
		{ 0,1,1,1,0,0 },
		{ 0,0,0,0,1,0 },
		{ 0,0,1,1,0,0 },
		{ 0,0,0,0,1,0 },
		{ 0,1,1,1,0,0 },
		{ 0,0,0,0,0,0 }
	},
	
	// 4
	{
		{ 0,0,0,1,0,0 },
		{ 0,0,1,1,0,0 },
		{ 0,1,0,1,0,0 },
		{ 0,1,1,1,1,0 },
		{ 0,0,0,1,0,0 },
		{ 0,0,0,1,0,0 }
	},
	
	// 5
	{
		{ 0,0,1,1,1,0 },
		{ 0,0,1,0,0,0 },
		{ 0,0,1,1,0,0 },
		{ 0,0,0,0,1,0 },
		{ 0,0,0,0,1,0 },
		{ 0,0,1,1,0,0 }
	},
	
	// 6
	{
		{ 0,0,1,1,0,0 },
		{ 0,1,0,0,1,0 },
		{ 0,1,0,0,0,0 },
		{ 0,1,1,1,0,0 },
		{ 0,1,0,0,1,0 },
		{ 0,0,1,1,0,0 }
	},
	
	// 7
	{
		{ 0,1,1,1,1,0 },
		{ 0,0,0,0,1,0 },
		{ 0,0,0,1,0,0 },
		{ 0,0,0,1,0,0 },
		{ 0,0,0,1,0,0 },
		{ 0,0,0,1,0,0 }
	},
	
	// 8
	{
		{ 0,0,1,1,0,0 },
		{ 0,1,0,0,1,0 },
		{ 0,0,1,1,0,0 },
		{ 0,1,0,0,1,0 },
		{ 0,0,1,1,0,0 },
		{ 0,0,0,0,0,0 }
	},
	
	// 9
	{
		{ 0,0,1,1,0,0 },
		{ 0,1,0,0,1,0 },
		{ 0,0,1,1,1,0 },
		{ 0,0,0,0,1,0 },
		{ 0,1,0,0,1,0 },
		{ 0,0,1,1,0,0 }
	}
};

void outputTileNumber(u8 screen, u8 x, u8 y, u8 num) {
	u8 put_y, put_x, colour;
	
	if (num == 0) { colour = 31; } else { colour = 0; }
	
	for (put_y = y; put_y < y + 6; put_y++) {
		for (put_x = x; put_x < x + 6; put_x++) {
			if (numbers[num][put_y - y][put_x - x] == 1) {
				if (screen == SCREEN_BOTTOM) {
					BG_GFX_SUB[put_x + put_y * 256] = RGB15(colour, colour, colour) | BIT(15);
				} else {
					VRAM_A[put_x + put_y * SCREEN_WIDTH] = RGB15(colour, colour, colour);
				}
			}
		}
	}
}

void printString(char *str, u8 x, u8 y, u8 screen) {
	u8 curr_x = x;
	u8 put_y, put_x;
	u8 curr_char = 0;
	u8 pixel_colour;
	while (*(str+curr_char) != '\0' && curr_x < SCREEN_WIDTH - 7) {
		for (put_y = y; put_y < y + 8; put_y++) {
			for (put_x = curr_x; put_x < curr_x + 8; put_x++) {
				pixel_colour = font[(int)*(str+curr_char)][put_y - y][put_x - curr_x];
				if (screen == SCREEN_TOP) {
					switch (pixel_colour) {
						case 1:
							VRAM_A[put_x + put_y * SCREEN_WIDTH] = RGB15(0,0,0); // black
							break;
						case 2:
							VRAM_A[put_x + put_y * SCREEN_WIDTH] = RGB15(31,31,31); // white
							break;
						default:
							// transparent (don't do anything)
							break;
					}
				} else {
					switch (pixel_colour) {
						case 1:
							BG_GFX_SUB[put_x + put_y * 256] = RGB15(0,0,0) | BIT(15); // black
							break;
						case 2:
							BG_GFX_SUB[put_x + put_y * 256] = RGB15(31,31,31) | BIT(15); // white
							break;
						default:
							// transparent (don't do anything)
							break;
					}
				}
			}
		}
		
		curr_x += 8;
		curr_char++;
	}
}

void printChar(char char_, u8 x, u8 y, u8 screen) {
	u8 put_y, put_x;
	u8 pixel_colour;
	for (put_y = y; put_y < y + 8; put_y++) {
		for (put_x = x; put_x < x + 8; put_x++) {
			pixel_colour = font[(int)char_][put_y - y][put_x - x];
			if (screen == SCREEN_TOP) {
				switch (pixel_colour) {
					case 1:
						VRAM_A[put_x + put_y * SCREEN_WIDTH] = RGB15(0,0,0); // black
						break;
					case 2:
						VRAM_A[put_x + put_y * SCREEN_WIDTH] = RGB15(31,31,31); // white
						break;
					default:
						// transparent (don't do anything)
						break;
				}
			} else {
				switch (pixel_colour) {
					case 1:
						BG_GFX_SUB[put_x + put_y * 256] = RGB15(0,0,0) | BIT(15); // black
						break;
					case 2:
						BG_GFX_SUB[put_x + put_y * 256] = RGB15(31,31,31) | BIT(15); // white
						break;
					default:
						// transparent (don't do anything)
						break;
				}
			}
		}
	}
}

void showError(char *str) {
	printString(str, 5, 5, SCREEN_TOP);
}

void printStringCenter(u8 screen, u8 y, char *str) {
	u8 i = 0;
	u8 num_x = 0;
	while (*(str+i) != '\0') {
		num_x += 8;
		i++;
	}
	printString(str, 127 - (num_x / 2), y, screen);
}

void printStringCenterGrid(u8 screen, u8 y, char *str) {
	u8 i = 0;
	u8 num_x = 0;
	while (*(str+i) != '\0') {
		num_x += 8;
		i++;
	}
	printString(str, ((dimensions*26 / 2) + 49) - (num_x / 2), y, screen);
}

void printNumber(s8 num, u8 x, u8 y, u8 screen) {
	char num_str[20];
	sprintf(num_str, "%d", num);
	printString(num_str, x, y, screen);
}

void printInstructions() {
	char str[30];
	
	strcpy(str, "  Move tile");
	str[0] = BUTTON_STYLUS;
	printString(str, 10, 10, SCREEN_BOTTOM);
	
	strcpy(str, "  Move all tiles at once");
	str[0] = BUTTON_DPAD;
	printString(str, 10, 20, SCREEN_BOTTOM);
	
	strcpy(str, "  New puzzle");
	str[0] = BUTTON_A;
	printString(str, 10, 30, SCREEN_BOTTOM);
	
	strcpy(str, "  Hint (only at start of game)");
	str[0] = BUTTON_B;
	printString(str, 10, 40, SCREEN_BOTTOM);
	
	strcpy(str, "  Increase puzzle size");
	str[0] = BUTTON_X;
	printString(str, 10, 50, SCREEN_BOTTOM);
	
	strcpy(str, "  Decrease puzzle size");
	str[0] = BUTTON_Y;
	printString(str, 10, 60, SCREEN_BOTTOM);
	
	strcpy(str, " /  Switch screens");
	str[0] = BUTTON_L;
	str[2] = BUTTON_R;
	printString(str, 10, 70, SCREEN_BOTTOM);
}
