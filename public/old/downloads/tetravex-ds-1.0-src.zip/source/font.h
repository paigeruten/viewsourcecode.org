u8 numbers[10][6][6];

void outputTileNumber(u8 screen, u8 x, u8 y, u8 num);
void printString(char *str, u8 x, u8 y, u8 screen);
void printChar(char char_, u8 x, u8 y, u8 screen);
void showError(char *str);
void printStringCenter(u8 screen, u8 y, char *str);
void printStringCenterGrid(u8 screen, u8 y, char *str);
void printNumber(s8 num, u8 x, u8 y, u8 screen);
void printInstructions();
