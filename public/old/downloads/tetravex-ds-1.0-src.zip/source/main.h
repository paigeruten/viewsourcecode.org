#include <nds.h>
#include <stdlib.h>

#define SCREEN_TOP 1
#define SCREEN_BOTTOM 0

#define TILE_TOP 0
#define TILE_RIGHT 1
#define TILE_BOTTOM 2
#define TILE_LEFT 3

#define DIRECTION_UP 0
#define DIRECTION_RIGHT 1
#define DIRECTION_DOWN 2
#define DIRECTION_LEFT 3

#define COLOR_BLACK RGB15(0,0,0)
#define COLOR_BROWN RGB15(24,16,2)
#define COLOR_RED RGB15(26,0,0)
#define COLOR_ORANGE RGB15(31,15,0)
#define COLOR_YELLOW RGB15(30,27,0)
#define COLOR_GREEN RGB15(14,26,3)
#define COLOR_BLUE RGB15(7,13,21)
#define COLOR_PURPLE RGB15(15,10,15)
#define COLOR_GREY RGB15(23,23,23)
#define COLOR_WHITE RGB15(31,31,31)

s8 puzzle[6][6][4]; // The grid on the bottom screen
s8 original_puzzle[6][6][4]; // The solution
s8 solution[6][6][4]; // The grid on the top screen
u16 vblank_count;
u8 dimensions;
