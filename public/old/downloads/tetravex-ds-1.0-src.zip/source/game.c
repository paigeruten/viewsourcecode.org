#include <math.h>
#include "main.h"
#include "game.h"
#include "puzzle.h"
#include "tile.h"
#include "font.h"

void splashScreen() {
	printStringCenter(SCREEN_TOP, 95, "Press A to start");
	printInstructions();
	while (!(keysHeld() & KEY_A)) {	scanKeys(); swiWaitForVBlank(); vblank_count++;	}	
	while (keysHeld() & KEY_A) { scanKeys(); swiWaitForVBlank(); }
}

void setupScreens() {
	// Main screen turn on
	videoSetMode(MODE_FB0);
	vramSetBankA(VRAM_A_LCD);

	// Sub screen turn on
	videoSetModeSub(MODE_5_2D | DISPLAY_BG2_ACTIVE);
	vramSetBankC(VRAM_C_SUB_BG);
	SUB_BG2_CR = BG_BMP16_256x256;
	SUB_BG2_XDX = 1 << 8;
	SUB_BG2_XDY = 0 << 8;
	SUB_BG2_YDX = 0 << 8;
	SUB_BG2_YDY = 1 << 8;
}

void menu() {
	dimensions = 3;
	while (1) {
		game();
	}
}

void game() {
	u8 i, j, won = 0, quit = 0, screens_swapped = 0, game_started = 0; // game_started is changed to 1 when the player places the first tile. After that, hints can't be used.
	s8 gridxy[2], current_nums[4], old_x, old_y, old_x2, old_y2, valid_tile, tile_x = 0, tile_y = 0;
	touchPosition stylus;

	clearScreens();
	printStringCenterGrid(SCREEN_TOP, 5, "Solve here");
	
	srand(vblank_count);
	loadPuzzle();
	drawGrids();
	updateGrid(SCREEN_BOTTOM);
	
	while (!quit) {
		scanKeys();
		
		if (keysHeld() & KEY_TOUCH && !screens_swapped) {
			stylus = touchReadXY();
			touchedbox(stylus.px, stylus.py, gridxy);
			
			old_x = gridxy[0];
			old_y = gridxy[1];
			old_x2 = old_x;
			old_y2 = old_y;
			
			// First make sure they are touching the grid, then make sure that there is a tile there
			if (gridxy[0] != -1 && puzzle[gridxy[0]][gridxy[1]][0] != -1) {
				for (i = 0; i <= 3; i++)
					current_nums[i] = puzzle[gridxy[0]][gridxy[1]][i];
				removeTile(SCREEN_BOTTOM, gridxy[0], gridxy[1]);
				drawTile(SCREEN_TOP, gridxy[0], gridxy[1], current_nums[0], current_nums[1], current_nums[2], current_nums[3]);
				valid_tile = is_valid_tile(gridxy[0], gridxy[1], current_nums[0], current_nums[1], current_nums[2], current_nums[3]);
				if (valid_tile == 1) {
					drawBox(SCREEN_TOP, gridxy[0], gridxy[1], 0, 31, 0);
				} else {
					drawBox(SCREEN_TOP, gridxy[0], gridxy[1], 31, 0, 0);
				}
				
				while (keysHeld() & KEY_TOUCH) {
					scanKeys();
					
					stylus = touchReadXY();
					
					if (stylus.px != 0 && stylus.py != 0)
						touchedbox(stylus.px, stylus.py, gridxy);
										
					tile_x = gridxy[0];
					tile_y = gridxy[1];
					
					if (gridxy[0] != -1 && (old_x2 != gridxy[0] || old_y2 != gridxy[1])) {
						drawBox(SCREEN_TOP, old_x2, old_y2, 31, 31, 31);
						eraseTile(SCREEN_TOP, old_x2, old_y2);
						updateGrid(SCREEN_TOP);
						drawTile(SCREEN_TOP, gridxy[0], gridxy[1], current_nums[0], current_nums[1], current_nums[2], current_nums[3]);
						valid_tile = is_valid_tile(gridxy[0], gridxy[1], current_nums[0], current_nums[1], current_nums[2], current_nums[3]);
						if (valid_tile == 1) {
							drawBox(SCREEN_TOP, gridxy[0], gridxy[1], 0, 31, 0);
						} else {
							drawBox(SCREEN_TOP, gridxy[0], gridxy[1], 31, 0, 0);
						}
												
						old_x2 = gridxy[0];
						old_y2 = gridxy[1];
						
						tile_x = gridxy[0];
						tile_y = gridxy[1];
					}
					
					swiWaitForVBlank();
				}
				
				if (tile_x != -1 && valid_tile) {
					addTile(SCREEN_TOP, tile_x, tile_y, current_nums[0], current_nums[1], current_nums[2], current_nums[3]);
					game_started = 1;
				} else {
					addTile(SCREEN_BOTTOM, old_x, old_y, current_nums[0], current_nums[1], current_nums[2], current_nums[3]);
				}
				
				drawBox(SCREEN_TOP, old_x2, old_y2, 31, 31, 31);
				updateGrid(SCREEN_TOP);
				updateGrid(SCREEN_BOTTOM);
				
				// Check if they won
				won = 1;
				for (i = 0; i < dimensions; i++)
					for (j = 0; j < dimensions; j++)
						if (puzzle[i][j][0] != -1)
							won = 0;
				if (won)
					quit = 1;
			} else {		
				while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
			}
		}
		
		if (keysHeld() & KEY_TOUCH && screens_swapped) {
			stylus = touchReadXY();
			
			touchedbox(stylus.px, stylus.py, gridxy);
				
			old_x = gridxy[0];
			old_y = gridxy[1];
			old_x2 = old_x;
			old_y2 = old_y;
			
			// First make sure they are touching the grid, then make sure that there is a tile there
			if (gridxy[0] != -1 && solution[gridxy[0]][gridxy[1]][0] != -1) {
				for (i = 0; i <= 3; i++)
					current_nums[i] = solution[gridxy[0]][gridxy[1]][i];
				removeTile(SCREEN_TOP, gridxy[0], gridxy[1]);
				drawTile(SCREEN_BOTTOM, gridxy[0], gridxy[1], current_nums[0], current_nums[1], current_nums[2], current_nums[3]);
				if (puzzle[gridxy[0]][gridxy[1]][0] == -1) {
					drawBox(SCREEN_BOTTOM, gridxy[0], gridxy[1], 0, 31, 0);
				} else {
					drawBox(SCREEN_BOTTOM, gridxy[0], gridxy[1], 31, 0, 0);
				}
				
				while (keysHeld() & KEY_TOUCH) {
					scanKeys();
					
					stylus = touchReadXY();
					
					if (stylus.px != 0 && stylus.py != 0)
						touchedbox(stylus.px, stylus.py, gridxy);
					
					tile_x = gridxy[0];
					tile_y = gridxy[1];
					
					if (gridxy[0] != -1 && (old_x2 != gridxy[0] || old_y2 != gridxy[1])) {
						drawBox(SCREEN_BOTTOM, old_x2, old_y2, 31, 31, 31);
						eraseTile(SCREEN_BOTTOM, old_x2, old_y2);
						updateGrid(SCREEN_BOTTOM);
						drawTile(SCREEN_BOTTOM, gridxy[0], gridxy[1], current_nums[0], current_nums[1], current_nums[2], current_nums[3]);
						
						if (puzzle[gridxy[0]][gridxy[1]][0] == -1) {
							drawBox(SCREEN_BOTTOM, gridxy[0], gridxy[1], 0, 31, 0);
						} else {
							drawBox(SCREEN_BOTTOM, gridxy[0], gridxy[1], 31, 0, 0);
						}
						
						old_x2 = gridxy[0];
						old_y2 = gridxy[1];
						
						tile_x = gridxy[0];
						tile_y = gridxy[1];
					}
					
					swiWaitForVBlank();
				}
				
				if (tile_x != -1 && puzzle[gridxy[0]][gridxy[1]][0] == -1) {
					addTile(SCREEN_BOTTOM, gridxy[0], gridxy[1], current_nums[0], current_nums[1], current_nums[2], current_nums[3]);
				} else {
					addTile(SCREEN_TOP, old_x, old_y, current_nums[0], current_nums[1], current_nums[2], current_nums[3]);
				}
				
				drawBox(SCREEN_BOTTOM, old_x2, old_y2, 31, 31, 31);
				updateGrid(SCREEN_TOP);
				updateGrid(SCREEN_BOTTOM);
			} else {		
				while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
			}
		}
		
		if (keysHeld() & KEY_R || keysHeld() & KEY_L) {
			lcdSwap();
			if (screens_swapped) { screens_swapped = 0; } else { screens_swapped = 1; }
			while (keysHeld() & KEY_R || keysHeld() & KEY_L) { scanKeys(); swiWaitForVBlank(); }
		}
		
		if (keysHeld() & KEY_UP) {
			moveAll(DIRECTION_UP);
			while (keysHeld() & KEY_UP) { scanKeys(); swiWaitForVBlank(); }
		}
		
		if (keysHeld() & KEY_RIGHT) {
			moveAll(DIRECTION_RIGHT);
			while (keysHeld() & KEY_RIGHT) { scanKeys(); swiWaitForVBlank(); }
		}
		
		if (keysHeld() & KEY_DOWN) {
			moveAll(DIRECTION_DOWN);
			while (keysHeld() & KEY_DOWN) { scanKeys(); swiWaitForVBlank(); }
		}
		
		if (keysHeld() & KEY_LEFT) {
			moveAll(DIRECTION_LEFT);
			while (keysHeld() & KEY_LEFT) { scanKeys(); swiWaitForVBlank(); }
		}
		
		if (keysHeld() & KEY_A) {
			quit = 1;
			while (keysHeld() & KEY_A) { scanKeys(); swiWaitForVBlank(); }
		}
		
		if (keysHeld() & KEY_X) {
			dimensions++;
			if (dimensions == 7) { dimensions = 2; }
			quit = 1;
			while (keysHeld() & KEY_X) { scanKeys(); swiWaitForVBlank(); }
		}

		if (keysHeld() & KEY_Y) {
			dimensions--;
			if (dimensions == 1) { dimensions = 6; }
			quit = 1;
			while (keysHeld() & KEY_Y) { scanKeys(); swiWaitForVBlank(); }
		}
		
		if (keysHeld() & KEY_B) {
			if (!game_started)
				hint();
			while (keysHeld() & KEY_B) { scanKeys(); swiWaitForVBlank(); }
		}
		
		vblank_count++;
		swiWaitForVBlank();
	}
	
	if (screens_swapped) {
		lcdSwap();
		screens_swapped = 0;
	}
	
	if (won) {
		printStringCenterGrid(SCREEN_BOTTOM, 5, "You won!");
		printStringCenterGrid(SCREEN_BOTTOM, 17+(dimensions*26)+5, "Press A");
		
		while (!(keysHeld() & KEY_A)) { scanKeys(); swiWaitForVBlank();	}
	}
}

void touchedbox(u8 stylusx, u8 stylusy, s8 *gridxy) {
	s8 grid_x, grid_y;
	
	if (stylusx < 49 || stylusy < 17 || stylusx >= 49+dimensions*26 || stylusy >= 17+dimensions*26) {
		gridxy[0] = -1;
		gridxy[1] = -1;
	} else {	
		stylusx -= 49;
		stylusy -= 17;
		
		grid_x = floor(stylusx/26);
		grid_y = floor(stylusy/26);
		
		gridxy[0] = grid_x;
		gridxy[1] = grid_y;
	}
}

void clearScreens() {
	u16 x, y;
	for (y = 0; y < 192; y++) {
		for (x= 0; x < 256; x++) {
			BG_GFX_SUB[x + y * 256] = RGB15(0, 0, 0) | BIT(15);
			VRAM_A[x + y * SCREEN_WIDTH] = RGB15(0, 0, 0);
		}
	}
}

void hint() {
	u8 x, y, x2, y2, fin = 0, fin2 = 0;
	
	while (!fin) {
		x = rand() % dimensions;
		y = rand() % dimensions;
	
		if (solution[x][y][0] == -1) {
			addTile(SCREEN_TOP, x, y, original_puzzle[x][y][0], original_puzzle[x][y][1], original_puzzle[x][y][2], original_puzzle[x][y][3]);
			
			// Find the tile which has those four numbers
			for (x2 = 0; x2 < dimensions && !fin2; x2++) {
				for (y2 = 0; y2 < dimensions && !fin2; y2++) {
					if (puzzle[x2][y2][0] == original_puzzle[x][y][0] && puzzle[x2][y2][1] == original_puzzle[x][y][1] && puzzle[x2][y2][2] == original_puzzle[x][y][2] && puzzle[x2][y2][3] == original_puzzle[x][y][3]) {
						removeTile(SCREEN_BOTTOM, x2, y2);
						fin2 = 1;
					}
				}
			}
			
			fin = 1;
		}
	}
	
	updateGrid(SCREEN_TOP);
	updateGrid(SCREEN_BOTTOM);
}

s8 is_valid_tile(s8 x, s8 y, s8 n_top, s8 n_right, s8 n_bottom, s8 n_left) {
	// Check if there is already a tile there
	if (solution[x][y][0] == -1) {
		// Check the tiles on the four sides
		if (
			(solution[x][y+1][TILE_TOP] == n_bottom || (solution[x][y+1][TILE_TOP] == -1 || y == dimensions-1)) && 
			(solution[x-1][y][TILE_RIGHT] == n_left || (solution[x-1][y][TILE_TOP] == -1 || x == 0)) && 
			(solution[x][y-1][TILE_BOTTOM] == n_top || (solution[x][y-1][TILE_TOP] == -1 || y == 0)) && 
			(solution[x+1][y][TILE_LEFT] == n_right || (solution[x+1][y][TILE_TOP] == -1 || x == dimensions-1))
		) {
			return 1;	
		} else {
			return 0;
		}
	} else {
		return 0;
	}
}
