void loadPuzzle();
void clearPuzzle();
void addTile(u8 screen, u8 x, u8 y, u8 n1, u8 n2, u8 n3, u8 n4);
void removeTile(u8 screen, u8 x, u8 y);
void moveAll(u8 direction);
void randomTileNum(u8 x, u8 y, u8 position);
u8 a_seed();
