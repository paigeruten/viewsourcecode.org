#include <nds.h>
#include <fat.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

///////////////////////////////////////////////////////////
// Edit any of these you want
///////////////////////////////////////////////////////////

// FAT_OFF is for testing on emulator (make sure one of them is defined but not both and not neither!)
#define FAT_ON
//#define FAT_OFF

// Whitespace
#define SPACE_BETWEEN_CHARS 2
#define SPACE_BETWEEN_LINES 1
#define MARGIN_SIDES 5
#define MARGIN_MAIN_TOP 5
#define MARGIN_MAIN_BOTTOM 5
#define MARGIN_SUB_TOP 5
#define MARGIN_SUB_BOTTOM 5

// Colours
#define HIGHLIGHT_COLOUR RGB15(31,31,31)
#define HIGHLIGHT_BGCOLOUR RGB15(0,0,0)

// Buttons
#define CURSOR_LEFT (keysHeld() & KEY_LEFT)
#define CURSOR_RIGHT (keysHeld() & KEY_RIGHT)
#define CURSOR_HOME (keysHeld() & KEY_UP)
#define CURSOR_END (keysHeld() & KEY_DOWN)
#define KEY_SHIFT ((keysHeld() & KEY_L) || (keysHeld() & KEY_R))
#define KEY_ENTER (keysHeld() & KEY_A)
#define KEY_BACKSPACE (keysHeld() & KEY_B)
#define KEY_CUT (keysHeld() & KEY_X)
#define KEY_COPY (keysHeld() & KEY_SELECT)
#define KEY_PASTE (keysHeld() & KEY_START)

// The following defines holds the keyboard layout. Rows of keys are seperated by back-slashes (escape them, of course).
// Letters, numbers, and symbols represent keys for those chars. Special keys are:
//
//	\n	Enter key
//	\b	Backspace
//	\t	Space bar
//
// A space ( ) causes there to be blank space 10px wide to be put in that row.
#define KEYBOARD_LAYOUT       "1234567890-=\b\\qwertyuiop[]\\asdfghjkl;\n\\zxcvbnm,./\'\\    \t"
#define KEYBOARD_LAYOUT_SHIFT "!@#$%^&*()_+\b\\QWERTYUIOP{}\\ASDFGHJKL:\n\\ZXCVBNM<>?\"\\    \t"
#define ENTER_KEY_WIDTH 50
#define SPACE_BAR_WIDTH 120

// Coordinates of where to start printing keyboard (each row of keys starts printing at KEYBOARD_X)
#define KEYBOARD_X 5
#define KEYBOARD_Y 60

// Size and position of textbox where the string being entered on the keyboard is echoed. (There is no TEXTBOX_X because the textbox is autmatically centered.)
#define TEXTBOX_WIDTH 200
#define TEXTBOX_HEIGHT 24
#define TEXTBOX_Y 20

// Path to directory that contains the question file(s)
#define PATH_TO_QUESTIONS "/"

///////////////////////////////////////////////////////////
// DO NOT edit any of the below defines unless you're sure
// you know what you're doing...
///////////////////////////////////////////////////////////

#define SCREEN_TOP 1
#define SCREEN_BOTTOM 0
#define FONT_WIDTH 20
#define FONT_HEIGHT 16

#define ON 1
#define OFF 0

#define TEXTBOX_LEFT_X (127-(TEXTBOX_WIDTH/2))
#define TEXTBOX_RIGHT_X (127+(TEXTBOX_WIDTH/2))

