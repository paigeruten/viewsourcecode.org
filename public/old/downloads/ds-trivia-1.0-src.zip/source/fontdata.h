// All the char data is stored here
u8 font[138][FONT_HEIGHT][FONT_WIDTH];

// The widths (px) of each char
u8 font_widths[138];
