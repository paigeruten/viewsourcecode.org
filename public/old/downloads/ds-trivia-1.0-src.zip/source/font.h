// Print character to screen
void print_char(char character, u8 x, u8 y, u8 screen);

// Print character to screen with a background colour
void print_highlighted_char(char character, u8 x, u8 y, u8 screen);

// Print string on single line starting at (x, y)
void print_string_xy(char *string, u8 x, u8 y, u8 screen);

// Print string and highlight part of it (from highlight_start to highlight_end)
void print_string_highlighted(char *string, u8 x, u8 y, u8 screen, u16 highlight_start, u16 highlight_end);

// Print string to screen starting at offset until no room left on screen
void print_string(char *string, u32 offset);

// Prints num to the screen (converts it to a string first)
void print_number(u32 num, u8 x, u8 y, u8 screen);

// Insert newlines into string to prevent words from looking like th
// is.
void wordwrap_string(char *string);

// Scroll down one line (returns new value of pos)
u32 scroll_down(char *string, u32 pos);

// Scroll up one line (returns new value of pos)
u32 scroll_up(char *string, u32 pos);

// Fill screen with white pixels
void clear_screen(u8 screen);

// Clear both screens
void clear_screens();

// Clear just the text part of the screens (leave the MARGIN_MAIN_TOP and MARGIN_SUB_BOTTOM alone)
void clear_text();

// Print string in center of screen
void print_string_center(char *string, u8 y, u8 screen);

// Print string aligned to the right of the screen
void print_string_right(char *string, u8 y, u8 screen);

// Returns the width of string if it were printed on the screen (length is where it stops counting the width (it doesn't check for '\0'))
u32 string_width(char *string, u8 length);

// Makes a filled in rectangle with a border and prints string[] into the box. If height or width are 0, they are automatically adjusted to fit the text perfectly. If x or y are 0, the box is centered horizontally or vertically.
void popup_text_box(char *string, u8 x, u8 y, u8 height, u8 width, u8 bgcolour, u8 bordercolour, u8 screen);

