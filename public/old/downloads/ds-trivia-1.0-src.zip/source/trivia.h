// Gets line number [question_num] from questions file and stores each part of the question in the question/answer/category strings. Returns 0 if it fails (can't open
// file, line number doesn't exist, question isn't in the right format...)
u8 get_question(char *filename, u32 question_num, char *category, char *question, char *answer);

// Print a question, let them answer it, return whether they got it right or wrong
u8 print_question(char *category, char *question_text, char *hint, char *answer, u8 letters_shown);

// Convert a string to lowercase
void str2lower(char *string);

// Takes the answer and converts all the letters into dots (.) except punctuation, stores it in hint.
void answer2dots(char *answer, char *hint);

// Change some dots into letters, letters_shown is the percentage of letters to reveal
void reveal_hint(char *answer, char *hint, u8 letters_shown);

// Return number of dots (periods) in a string
u16 num_of_dots(char *string);

// Calls popup_text_box() saying "Correct!" or "Wrong!" depending on whether correct is true or false
void print_correct_box(u8 correct);

