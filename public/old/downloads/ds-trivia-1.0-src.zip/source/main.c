#include "main.h"
#include "font.h"
#include "keyboard.h"
#include "trivia.h"

int main(void) {
	char category[256], question[256], answer[256], hint[256], message[1024], num_questions_str[128] = "10", path[256] = "";
	char character;
	u8 correct = 1, letter_hint = 0;
	u16 current_question = 0, num_questions = 0, points = 0, max_points = 0, num_of_questions = 1;
	u32 vblank_count = 0;
	s16 x = 0;
	
	irqInit();
	irqEnable(IRQ_VBLANK);
	
	// Main screen turn on
	videoSetMode(MODE_FB0);
	vramSetBankA(VRAM_A_LCD);
	
	// Sub screen turn on
	videoSetModeSub(MODE_5_2D | DISPLAY_BG2_ACTIVE);
	vramSetBankC(VRAM_C_SUB_BG);
	SUB_BG2_CR = BG_BMP16_256x256;
	SUB_BG2_XDX = 1 << 8;
	SUB_BG2_XDY = 0 << 8;
	SUB_BG2_YDX = 0 << 8;
	SUB_BG2_YDY = 1 << 8;
	
	clear_screens();
	
	popup_text_box("Initializing FAT...", 0, 0, 0, 0, 28, 24, SCREEN_TOP);
	if (!fatInitDefault()) {
		clear_screens();
		print_string("Failed!\n\nMake sure it's\nDLDI-patched correctly.", 0);
		while(1);
	}
	clear_screens();
	
	// Get the number of questions
#ifdef FAT_ON
	strcpy(path, PATH_TO_QUESTIONS);
	strcat(path, "questions");
	FILE *question_file = fopen(path, "r");
	
	if (!question_file) {
		strcpy(message, "Could not find questions file. Make sure its name is 'questions' and is located in the root directory.");
		wordwrap_string(message);
		print_string(message, 0);
		while(1);
	}
	
	while (!feof(question_file)) {
		character = fgetc(question_file);
		if (character == '\n') {
			num_of_questions++;
		}
	}
	fclose(question_file);
#endif

#ifdef FAT_OFF
	num_of_questions = 10000;
#endif
	
	print_string_center("Controls", 5, SCREEN_BOTTOM);
	strcpy(message, "\n\n\n\n\n\n\n\n\n\n\n\nD-Pad: Move cursor\nA: Enter\nB: Backspace\nL/R: Shift\nX: Cut\nSelect: Copy\nStart: Paste\nStylus: Move cursor/highlight");
	wordwrap_string(message);
	print_string(message, 0);
	
	popup_text_box("Press A to begin", 0, 0, 0, 0, 28, 24, SCREEN_TOP);
	while (!(keysHeld() & KEY_A)) { scanKeys(); swiWaitForVBlank(); vblank_count++; }
	srand(vblank_count);
	while (keysHeld() & KEY_A) { scanKeys(); swiWaitForVBlank(); vblank_count++; }
	srand(vblank_count);
	current_question = rand() % num_of_questions;
	
	clear_screens();
	
how_many:
	strcpy(message, "How many questions do you want?");
	wordwrap_string(message);
	print_string(message, 0);
	clear_screen(SCREEN_BOTTOM);
	print_keyboard(KEYBOARD_LAYOUT);
	keyboard_string(num_questions_str);
	if (!is_numeric(num_questions_str)) {
		clear_screen(SCREEN_TOP);
	
		strcpy(message, "That's not a number! Press A to try again.");
		wordwrap_string(message);
		print_string(message, 0);
		
		while (!(keysHeld() & KEY_A)) { scanKeys(); swiWaitForVBlank(); }
		while (keysHeld() & KEY_A) { scanKeys(); swiWaitForVBlank(); }
		
		clear_screen(SCREEN_TOP);
		goto how_many;
	}
	num_questions = str2num(num_questions_str);
	max_points = num_questions*100;
	points = 0;
	
	clear_screens();
	
	for (x = 1; x <= num_questions; x++) {
		get_question("questions", current_question, category, question, answer);
		
		if (letter_hint == 0) {
			answer2dots(answer, hint);
		}
		
		clear_screens();
		
		sprintf(message, "%d Points", points);
		print_string_xy(message, MARGIN_SIDES, 170, SCREEN_TOP);
		
		sprintf(message, "%d / %d", x, num_questions);
		print_string_right(message, 170, SCREEN_TOP);
		
		print_keyboard(KEYBOARD_LAYOUT);
		correct = print_question(category, question, hint, answer, letter_hint);
		
		if (correct == 3) {
			current_question = rand() % num_of_questions;
			letter_hint = 0;
		} else if (correct == 2) {
			x = num_questions+1;
		} else if (correct) {
			print_correct_box(1);
			current_question = rand() % num_of_questions;
			points += 100-letter_hint;
			letter_hint = 0;
		} else {
			print_correct_box(0);
			letter_hint += 20;
			if (letter_hint > 100) {
				current_question = rand() % num_of_questions;
				letter_hint = 0;
			} else {
				x--;
			}
		}
	}
	
	clear_screens();
	
	sprintf(message, "You scored %d points out of %d maximum points possible (%d%%), with %d questions.\n\nPress A to play again.", points, num_questions*100, (points*100) / (num_questions*100), num_questions);
	wordwrap_string(message);
	print_string(message, 0);
	
	while (!(keysHeld() & KEY_A)) { scanKeys(); swiWaitForVBlank(); }
	while (keysHeld() & KEY_A) { scanKeys(); swiWaitForVBlank(); }
	
	clear_screens();
	goto how_many;
	
	return 0;
}
