#include "main.h"
#include "keyboard.h"
#include "font.h"
#include "fontdata.h"

char clipboard[1024] = "";

void keyboard_string(char *string) {
	char key = '\0';
	char input[256] = "";
	touchPosition stylus;
	u8 cursor_pos = 0, highlight_cursor = 0, highlight_cursor_last = 0, vblank_count = 0, cursor_x = 0, i = 0, update_cursor = 0, highlighted = OFF, shift = 0;
	u16 current_char;
	
	// If there's something in string[], put the string into the textbox and highlight it
	if (strlen(string) > 0) {
		strcpy(input, string);
		highlighted = ON;
		update_cursor = 1;
		highlight_cursor = strlen(input);
		print_string_highlighted(input, TEXTBOX_LEFT_X+2, TEXTBOX_Y+6, SCREEN_BOTTOM, cursor_pos, highlight_cursor);
	}

	while (key != '\n') {
		scanKeys();
		
		if (keysHeld() & KEY_TOUCH) {
			stylus = touchReadXY();
		
			// Check if they are touching inside the textbox
			if (stylus.px > TEXTBOX_LEFT_X && stylus.px < TEXTBOX_RIGHT_X && stylus.py > TEXTBOX_Y && stylus.py < TEXTBOX_Y+TEXTBOX_HEIGHT) {
				highlighted = OFF;
				cursor_pos = stylus2cursor(stylus.px, input);
				update_cursor = 1;
				update_textbox(input);
				
				// Text highlighting
				while (keysHeld() & KEY_TOUCH) {
					scanKeys();
					stylus = touchReadXY();
					
					// Test if the stylus is still in the box
					if (stylus.px > TEXTBOX_LEFT_X && stylus.px < TEXTBOX_RIGHT_X && stylus.py > TEXTBOX_Y && stylus.py < TEXTBOX_Y+TEXTBOX_HEIGHT)
						highlight_cursor = stylus2cursor(stylus.px, input);
					if (highlight_cursor != highlight_cursor_last) {
						clear_textbox();
						print_string_highlighted(input, TEXTBOX_LEFT_X+2, TEXTBOX_Y+6, SCREEN_BOTTOM, cursor_pos, highlight_cursor);
					}
					highlight_cursor_last = highlight_cursor;
					
					swiWaitForVBlank();
				}
				
				if (highlight_cursor != cursor_pos) {
					highlighted = ON;
					clear_textbox();
					print_string_highlighted(input, TEXTBOX_LEFT_X+2, TEXTBOX_Y+6, SCREEN_BOTTOM, cursor_pos, highlight_cursor);
				} else {
					highlighted = OFF;
					clear_textbox();
					print_string_xy(input, TEXTBOX_LEFT_X+2, TEXTBOX_Y+6, SCREEN_BOTTOM);
				}
			} else {
				if (shift)
					key = get_key(KEYBOARD_LAYOUT_SHIFT, stylus.px, stylus.py);
				else
					key = get_key(KEYBOARD_LAYOUT, stylus.px, stylus.py);
				if (key == '\b') {
					switch (highlighted) {
						case ON:
							if (cursor_pos < highlight_cursor) {
								current_char = cursor_pos;
								while (current_char != highlight_cursor) {
									delete_char(input, cursor_pos+1);
									current_char++;
								}
							} else {
								current_char = highlight_cursor;
								while (current_char != cursor_pos) {
									delete_char(input, highlight_cursor+1);
									current_char++;
								}
								cursor_pos = highlight_cursor;
							}
							
							update_cursor = 1;
							update_textbox(input);
							highlighted = OFF;
							break;
						case OFF:
							delete_char(input, cursor_pos);
							if (cursor_pos > 0) cursor_pos--;
							update_cursor = 1;
							update_textbox(input);
							break;
					}
				} else if (key == '\t') {
					switch (highlighted) {
						case ON:
							if (cursor_pos < highlight_cursor) {
								current_char = cursor_pos;
								while (current_char != highlight_cursor) {
									delete_char(input, cursor_pos+1);
									current_char++;
								}
							} else {
								current_char = highlight_cursor;
								while (current_char != cursor_pos) {
									delete_char(input, highlight_cursor+1);
									current_char++;
								}
								cursor_pos = highlight_cursor;
							}
							
							insert_char(input, cursor_pos, ' ');
							cursor_pos++;							
							update_cursor = 1;
							update_textbox(input);
							highlighted = OFF;
							break;
						case OFF:
							insert_char(input, cursor_pos, ' ');
							update_cursor = 1;
							cursor_pos++;
							update_textbox(input);
							break;
					}
				} else if (key != '\0' && key != '\n') {
					switch (highlighted) {
						case ON:
							if (cursor_pos < highlight_cursor) {
								current_char = cursor_pos;
								while (current_char != highlight_cursor) {
									delete_char(input, cursor_pos+1);
									current_char++;
								}
							} else {
								current_char = highlight_cursor;
								while (current_char != cursor_pos) {
									delete_char(input, highlight_cursor+1);
									current_char++;
								}
								cursor_pos = highlight_cursor;
							}
							
							insert_char(input, cursor_pos, key);
							cursor_pos++;							
							update_cursor = 1;
							update_textbox(input);
							highlighted = OFF;
							break;
						case OFF:
							insert_char(input, cursor_pos, key);
							update_cursor = 1;
							cursor_pos++;
							update_textbox(input);
							break;
					}
				}
			
				if (key) {
					if (shift)
						highlight_key(KEYBOARD_LAYOUT_SHIFT, key, ON);
					else
						highlight_key(KEYBOARD_LAYOUT, key, ON);
				}
				while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
				if (key) {
					if (shift)
						highlight_key(KEYBOARD_LAYOUT_SHIFT, key, OFF);
					else
						highlight_key(KEYBOARD_LAYOUT, key, OFF);
				}
			}
		}

		// Shift key
		if (KEY_SHIFT && !shift) {
			clear_keyboard();
			print_keyboard(KEYBOARD_LAYOUT_SHIFT);
			shift = 1;
		}
		if (!KEY_SHIFT && shift) {
			clear_keyboard();
			print_keyboard(KEYBOARD_LAYOUT);
			shift = 0;
		}

		// Cursor keys
		if (CURSOR_LEFT) {
			highlighted = OFF;
			if (cursor_pos > 0) cursor_pos--;
			update_cursor = 1;
			update_textbox(input);
			while (CURSOR_LEFT) { scanKeys(); swiWaitForVBlank(); }
		}
		if (CURSOR_RIGHT) {
			highlighted = OFF;
			if (cursor_pos < strlen(input)) cursor_pos++;
			update_cursor = 1;
			update_textbox(input);
			while (CURSOR_RIGHT) { scanKeys(); swiWaitForVBlank(); }
		}
		if (CURSOR_HOME) { // "home" key
			highlighted = OFF;
			cursor_pos = 0;
			update_cursor = 1;
			update_textbox(input);
			while (CURSOR_HOME) { scanKeys(); swiWaitForVBlank(); }
		}
		if (CURSOR_END) { // "end" key
			highlighted = OFF;
			cursor_pos = strlen(input);
			update_cursor = 1;
			update_textbox(input);
			while (CURSOR_END) { scanKeys(); swiWaitForVBlank(); }
		}
		
		// Clipboard functions
		if (KEY_COPY) {
			if (highlighted) {
				clipboard_copy(input, cursor_pos, highlight_cursor);
				while (KEY_COPY) { scanKeys(); swiWaitForVBlank(); }
			}
		}
		if (KEY_CUT) {
			if (highlighted) {
				clipboard_copy(input, cursor_pos, highlight_cursor);
				while (KEY_CUT) { scanKeys(); swiWaitForVBlank(); }
				
				// Erase highlighted text
				if (cursor_pos < highlight_cursor) {
					current_char = cursor_pos;
					while (current_char != highlight_cursor) {
						delete_char(input, cursor_pos+1);
						current_char++;
					}
				} else {
					current_char = highlight_cursor;
					while (current_char != cursor_pos) {
						delete_char(input, highlight_cursor+1);
						current_char++;
					}
					cursor_pos = highlight_cursor;
				}
				
				update_cursor = 1;
				update_textbox(input);
				highlighted = OFF;
			}
		}
		if (KEY_PASTE) {
			if (highlighted) {
				// Erase highlighted text
				if (cursor_pos < highlight_cursor) {
					current_char = cursor_pos;
					while (current_char != highlight_cursor) {
						delete_char(input, cursor_pos+1);
						current_char++;
					}
				} else {
					current_char = highlight_cursor;
					while (current_char != cursor_pos) {
						delete_char(input, highlight_cursor+1);
						current_char++;
					}
					cursor_pos = highlight_cursor;
				}
			
				cursor_pos = clipboard_paste(input, cursor_pos);
				update_cursor = 1;
				update_textbox(input);
				highlighted = OFF;
				while (KEY_PASTE) { scanKeys(); swiWaitForVBlank(); }
			} else {
				cursor_pos = clipboard_paste(input, cursor_pos);
				update_cursor = 1;
				update_textbox(input);
				while (KEY_PASTE) { scanKeys(); swiWaitForVBlank(); }
			}
		}
		
		// Shortcut keys
		if (KEY_ENTER) {
			key = '\n';
			if (shift) {
				highlight_key(KEYBOARD_LAYOUT_SHIFT, key, ON);
				while (KEY_ENTER) { scanKeys(); swiWaitForVBlank(); }
				highlight_key(KEYBOARD_LAYOUT_SHIFT, key, OFF);
			} else {
				highlight_key(KEYBOARD_LAYOUT, key, ON);
				while (KEY_ENTER) { scanKeys(); swiWaitForVBlank(); }
				highlight_key(KEYBOARD_LAYOUT, key, OFF);
			}
		}
		if (KEY_BACKSPACE) {
			key = '\b';
			
			switch (highlighted) {
				case ON:
					if (cursor_pos < highlight_cursor) {
						current_char = cursor_pos;
						while (current_char != highlight_cursor) {
							delete_char(input, cursor_pos+1);
							current_char++;
						}
					} else {
						current_char = highlight_cursor;
						while (current_char != cursor_pos) {
							delete_char(input, highlight_cursor+1);
							current_char++;
						}
						cursor_pos = highlight_cursor;
					}
					
					update_cursor = 1;
					update_textbox(input);
					highlighted = OFF;
					break;
				case OFF:
					delete_char(input, cursor_pos);
					if (cursor_pos > 0) cursor_pos--;
					update_cursor = 1;
					update_textbox(input);
					break;
			}
			
			if (shift) {
				highlight_key(KEYBOARD_LAYOUT_SHIFT, key, ON);
				while (KEY_BACKSPACE) { scanKeys(); swiWaitForVBlank(); }
				highlight_key(KEYBOARD_LAYOUT_SHIFT, key, OFF);
			} else {
				highlight_key(KEYBOARD_LAYOUT, key, ON);
				while (KEY_BACKSPACE) { scanKeys(); swiWaitForVBlank(); }
				highlight_key(KEYBOARD_LAYOUT, key, OFF);
			}
		}

		// Update the flashing cursor (unless something is highlighted)
		if (!highlighted) {
			i = 0;
			if (vblank_count == 1 || update_cursor == 1) {
				cursor_x = string_width(input, cursor_pos) + (TEXTBOX_LEFT_X+2);
				for (i = TEXTBOX_Y + 2; i < TEXTBOX_Y + TEXTBOX_HEIGHT - 2; i++)
					BG_GFX_SUB[cursor_x + i * 256] = RGB15(0,0,0) | BIT(15); // black
				update_cursor = 0;
			} else if (vblank_count == 30) {
				cursor_x = string_width(input, cursor_pos) + (TEXTBOX_LEFT_X+2);
				for (i = TEXTBOX_Y + 2; i < TEXTBOX_Y + TEXTBOX_HEIGHT - 2; i++)
					BG_GFX_SUB[cursor_x + i * 256] = RGB15(31,31,31) | BIT(15); // white
			}
		}
		
		if (vblank_count == 45) {
			vblank_count = 0;
		}

		swiWaitForVBlank();
		vblank_count++;
	}
	
	clear_textbox();
	strcpy(string, input);
}

void update_textbox(char *string) {
	clear_textbox();
	print_string_xy(string, TEXTBOX_LEFT_X+2, TEXTBOX_Y+6, SCREEN_BOTTOM);
}

void delete_char(char *string, u8 cursor) {
	int i = 0, j = 0;
	while (string[i] != '\0')
		i++;
	i++;
	for (j = cursor-1; j < i; j++)
		string[j] = string[j+1];
	string[i] = '\0';
}

void insert_char(char *string, u8 cursor, char key) {
	int i = 0, j = 0;
	while (string[i] != '\0')
		i++;
	i++;
	for (j = i; j > cursor; j--)
		string[j] = string[j-1];
	string[cursor] = key;
}

void clear_textbox() {
	u8 x, y;
	for (y = TEXTBOX_Y+1; y < TEXTBOX_Y+TEXTBOX_HEIGHT; y++)
		for (x = TEXTBOX_LEFT_X+1; x < TEXTBOX_RIGHT_X-1; x++)
			BG_GFX_SUB[x + y * 256] = RGB15(31,31,31) | BIT(15); // white
}

void print_keyboard(char *layout) {
	u8 current_char = 0, i = 0;
	u16 put_x = KEYBOARD_X, put_y = KEYBOARD_Y;
	
	// Print all the keys in layout
	while (layout[current_char] != '\0') {
		if (layout[current_char] == '\\') {
			put_x = KEYBOARD_X;
			put_y += 19;
		} else if (layout[current_char] == '\n') {
			print_key(put_x, put_y, ENTER_KEY_WIDTH, layout[current_char]);
			put_x += ENTER_KEY_WIDTH;
		} else if (layout[current_char] == '\t') {
			print_key(put_x, put_y, SPACE_BAR_WIDTH, layout[current_char]);
			put_x += SPACE_BAR_WIDTH;
		} else if (layout[current_char] == ' ') {
			put_x += 10;
		} else {
			print_key(put_x, put_y, 20, layout[current_char]);
			put_x += 19;
		}
		
		current_char++;
	}
	
	// Print textbox where characters are echoed
	for (i = TEXTBOX_LEFT_X; i < TEXTBOX_RIGHT_X; i++) {
		BG_GFX_SUB[i + TEXTBOX_Y * 256] = RGB15(24,24,24) | BIT(15); // grey
		BG_GFX_SUB[i + (TEXTBOX_Y+TEXTBOX_HEIGHT) * 256] = RGB15(24,24,24) | BIT(15); // grey
	}
	for (i = TEXTBOX_Y; i < TEXTBOX_Y+TEXTBOX_HEIGHT; i++) {
		BG_GFX_SUB[TEXTBOX_LEFT_X + i * 256] = RGB15(24,24,24) | BIT(15); // grey
		BG_GFX_SUB[TEXTBOX_RIGHT_X + i * 256] = RGB15(24,24,24) | BIT(15); // grey
	}
}

void print_key(u8 x, u8 y, u8 width, char key) {
	u8 i;
	
	// First make the border (just a box)
	for (i = x; i < x+width; i++) {
		BG_GFX_SUB[i + y * 256] = RGB15(24,24,24) | BIT(15); // grey
		BG_GFX_SUB[i + (y+19) * 256] = RGB15(24,24,24) | BIT(15); // grey
	}
	for (i = y; i < y+20; i++) {
		BG_GFX_SUB[x + i * 256] = RGB15(24,24,24) | BIT(15); // grey
		BG_GFX_SUB[(x+width-1) + i * 256] = RGB15(24,24,24) | BIT(15); // grey
	}
	
	// Now print the char
	if (key == '\n')
		print_string_xy("Enter", x+((ENTER_KEY_WIDTH-40)/2), y+4, SCREEN_BOTTOM);
	else
		print_char(key, x+(width/2-font_widths[(int)key]/2), y+3, SCREEN_BOTTOM);
}

void get_key_xy(char *layout, char key, u8 *x, u8 *y, u8 *width) {
	u32 current_char = 0;
	u16 current_width = KEYBOARD_X, current_height = KEYBOARD_Y;
	
	// First, store the width
	switch (key) {
		case '\n':
			*width = ENTER_KEY_WIDTH;
			break;
		case '\t':
			*width = SPACE_BAR_WIDTH;
			break;
		default:
			*width = 20;
			break;
	}
	
	while (layout[current_char] != key && layout[current_char] != '\0') {
		if (layout[current_char] == '\\') {
			current_width = KEYBOARD_X;
			current_height += 19;
		} else if (layout[current_char] == '\n') {
			current_width += ENTER_KEY_WIDTH;
		} else if (layout[current_char] == '\t') {
			current_width += SPACE_BAR_WIDTH;
		} else if (layout[current_char] == ' ') {
			current_width += 10;
		} else {
			current_width += 19;
		}

		current_char++;
	}
	
	*x = current_width;
	*y = current_height;
}

char get_key(char *layout, u16 stylus_x, u16 stylus_y) {
	u8 i = 0, key_found = 0;
	u8 x, y, width;
	char key = '\0';
	
	for (i = 8; i < 128 && !key_found; i++) {
		get_key_xy(layout, i, &x, &y, &width);
		
		if (stylus_x > x && stylus_x < x+width && stylus_y > y && stylus_y < y+20 && i != '\\' && i != ' ') {
			key_found = 1;
			key = i;
		}
	}
	
	if ((!key_found || font_widths[(int)key] == 0) && key != '\n') {
		return '\0';
	} else {
		return key;
	}
}

void highlight_key(char *layout, char key, u8 on_off) {
	u8 x, y, width;
	u8 colour = 0, i = 0;

	get_key_xy(layout, key, &x, &y, &width);
	
	switch (on_off) {
		case ON:
			colour = 2;
			break;
		case OFF:
			colour = 24;
			break;
	}
	
	for (i = x; i < x+width; i++) {
		BG_GFX_SUB[i + y * 256] = RGB15(colour,colour,colour) | BIT(15);
		BG_GFX_SUB[i + (y+19) * 256] = RGB15(colour,colour,colour) | BIT(15);
	}
	for (i = y; i < y+20; i++) {
		BG_GFX_SUB[x + i * 256] = RGB15(colour,colour,colour) | BIT(15);
		BG_GFX_SUB[(x+width-1) + i * 256] = RGB15(colour,colour,colour) | BIT(15);
	}
}

u16 stylus2cursor(u8 stylus_x, char *string) {
	u8 width = TEXTBOX_LEFT_X;
	u16 current_char = 0;
	
	// Get the char that the stylus is touching
	while (width < stylus_x && string[current_char] != '\0') {
		width += font_widths[(int)string[current_char]];
		width += SPACE_BETWEEN_CHARS;
		current_char++;
	}
	width -= SPACE_BETWEEN_CHARS;
	current_char--;
	
	// Are they touching to the left or right of the center of the char?
	if (stylus_x < width - (font_widths[(int)string[current_char]]/2))
		return current_char;
	else
		return current_char+1;
}

void clear_keyboard() {
	u16 put_x, put_y;
	
	for (put_y = KEYBOARD_Y; put_y < SCREEN_HEIGHT; put_y++)
		for (put_x = KEYBOARD_X; put_x < SCREEN_WIDTH; put_x++)
			BG_GFX_SUB[put_x + put_y * 256] = RGB15(31,31,31) | BIT(15); // white
}

void clipboard_copy(char *string, u16 start, u16 end) {
	u16 current_char, current_char2 = 0;
	
	if (start < end) {
		current_char = start;
		while (current_char != end) {
			clipboard[current_char2] = string[current_char];
			current_char++;
			current_char2++;
		}
	} else {
		current_char = end;
		while (current_char != start) {
			clipboard[current_char2] = string[current_char];
			current_char++;
			current_char2++;
		}
	}
	
	clipboard[current_char2] = '\0';
}

u16 clipboard_paste(char *string, u16 pos) {
	u16 current_char = 0, position = pos;
	
	while (current_char != strlen(clipboard)) {
		insert_char(string, position, clipboard[current_char]);
		current_char++;
		position++;
	}
	
	return position;
}

u8 is_numeric(char *string) {
	u16 current_char = 0;
	
	while (string[current_char] != '\0') {
		if (string[current_char] < 48 || string[current_char] > 57)
			return 0;
		current_char++;
	}
	
	return 1;
}

u32 str2num(char *string) {
	u32 num = 0, current_char = 0;
	
	while (string[current_char] != '\0') {
		num *= 10;
		num += (int)string[current_char] - 48;
		current_char++;
	}
	
	return num;
}

