#include "main.h"
#include "trivia.h"
#include "font.h"
#include "keyboard.h"

u8 get_question(char *filename, u32 question_num, char *category, char *question_text, char *answer) {
	u8 pipes_found = 0;
	u32 current_char = 0, current_char2 = 0, current_line = 0;
	char path[256] = PATH_TO_QUESTIONS;
	char question[512] = "";
	strcat(path, filename);
	
#ifdef FAT_ON
	FILE *question_file = fopen(path, "r");
	
	if (question_file == NULL)
		return 0;
	
	fgets(question, 512, question_file);
	while (current_line != question_num) {
		fgets(question, 512, question_file);
		current_line++;
	}
#endif

#ifdef FAT_OFF
	strcpy(question, "True or False|2 true|Does laser stand for `Light Amplification by the Stimulated Emission of Radiation'?");
#endif
	
	// Go through the line and copy the current_char to the category or question or answer strings depending on how many pipe chars it found so far
	while (question[current_char] != '\0') {
		if (question[current_char] == '|') {
			// Terminate the strings
			if (pipes_found == 0) {
				category[current_char2] = '\0';
			}
			if (pipes_found == 1) {
				answer[current_char2] = '\0';
			}
		
			pipes_found++;
			current_char2 = 0;
		} else {
			if (pipes_found == 0) {
				category[current_char2] = question[current_char];
			}
			if (pipes_found == 1) {
				answer[current_char2] = question[current_char];
			}
			if (pipes_found == 2) {
				question_text[current_char2] = question[current_char];
			}
			current_char2++;
		}
		
		current_char++;
	}
	
	question_text[current_char2] = '\0';
	
	// For case-insensitivity
	str2lower(answer);
	
#ifdef FAT_ON
	fclose(question_file);
#endif
	
	return 1;
}

u8 print_question(char *category, char *question_text, char *hint, char *answer, u8 letters_shown) {
	char question[512] = "";
	char guess[512] = "";
	
	// Put together a string to display on the screen
	strcat(question, category);
	if (category[0] != '\0') {
		strcat(question, ": "); // Only print the colon-space if a category exists
	}
	strcat(question, question_text);
	strcat(question, "\n\nHint: ");
	reveal_hint(answer, hint, letters_shown);
	strcat(question, hint);
	
	wordwrap_string(question);
	print_string(question, 0);
	keyboard_string(guess);
	str2lower(guess);
	
	if (!strcmp(guess, "/skip") || !strcmp(guess, "/s"))
		return 3;
	else if (!strcmp(guess, "/quit") || !strcmp(guess, "/q"))
		return 2;
	else if (!strcmp(guess, answer))
		return 1;
	else
		return 0;
}

void str2lower(char *string) {
	u32 current_char = 0;
	
	while (string[current_char] != 0) {
		if (string[current_char] >= 65 && string[current_char] <= 90) string[current_char] += 32;
		current_char++;
	}
}

void answer2dots(char *answer, char *hint) {
	u16 current_char = 0, letters = 0;
	
	// Copy *answer to *hint, replacing [a-zA-Z] with dots
	while (answer[current_char] != '\0') {
		if ((answer[current_char] >= 65 && answer[current_char] <= 90) || (answer[current_char] >= 97 && answer[current_char] <= 122) || (answer[current_char] >= 48 && answer[current_char] <= 57)) {
			hint[current_char] = '.';
			letters++;
		} else {
			hint[current_char] = answer[current_char];
		}		
		current_char++;
	}
	hint[current_char] = '\0';
}

void reveal_hint(char *answer, char *hint, u8 letters_shown) {
	u16 revealed_letters, current_char = 0, current_char2 = 0, num_dots = num_of_dots(hint);

	// Reveal some random letters depending on letters_shown (which is the percentage of letters to be shown)
	revealed_letters = (letters_shown * 0.01) * num_dots;
	while (current_char2 != revealed_letters) {
		current_char = rand() % strlen(answer);
		if (hint[current_char] == '.') {
			hint[current_char] = answer[current_char];
			current_char2++;
		}
	}
}

u16 num_of_dots(char *string) {
	u16 num_dots = 0, current_char = 0;
	
	while (string[current_char] != '\0') {
		if (string[current_char] == '.') num_dots++;
		current_char++;
	}
	
	return num_dots;
}

void print_correct_box(u8 correct) {
	char txt[15];
	u8 vblank_count = 0;
	
	if (correct) {
		strcpy(txt, "Correct!");
	} else {
		strcpy(txt, "Wrong!");
	}
	
	popup_text_box(txt, 0, 0, 0, 0, 28, 24, SCREEN_TOP);
	
	// Wait 0.75 seconds (screen should be cleared/reset after calling this function... this gives them a chance to actually read what the box says!)
	while (vblank_count < 45) {
		vblank_count++;
		swiWaitForVBlank();
	}
}

