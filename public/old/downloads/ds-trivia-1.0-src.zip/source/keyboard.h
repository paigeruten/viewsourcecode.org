// Used for copying, cutting, pasting
char clipboard[1024];

// Wait for user to enter a string into the keyboard and press enter. String gets stored in string.
void keyboard_string(char *string);

// Print keyboard to screen
void print_keyboard(char *layout);

// Print a single key
void print_key(u8 x, u8 y, u8 width, char key);

// Store x, y coordinates and width of a key into *key_x and *key_y
void get_key_xy(char *layout, char key, u8 *x, u8 *y, u8 *width);

// Get char that is being pressed on keyboard
char get_key(char *layout, u16 stylus_x, u16 stylus_y);

// Draws a different-coloured border around a key (like to show that it's being pressed)
void highlight_key(char *layout, char key, u8 on_off);

// Print string to textbox
void update_textbox(char *string);

// Insert a char anywhere in a string
void insert_char(char *string, u8 cursor, char key);

// Clear the textbox
void clear_textbox();

// Deletes a char anywhere in the string
void delete_char(char *string, u8 cursor);

// Returns the position in the string where the stylus is touching in the textbox
u16 stylus2cursor(u8 stylus_x, char *string);

// Erase the keyboard (not the whole screen or textbox)
void clear_keyboard();

// Clipboard functions
void clipboard_copy(char *string, u16 start, u16 end);
u16 clipboard_paste(char *string, u16 pos);

// Check if a string is a number
u8 is_numeric(char *string);

// Convert a string to number
u32 str2num(char *string);

