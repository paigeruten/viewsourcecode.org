#include "main.h"
#include "font.h"
#include "fontdata.h"

void print_char(char character, u8 x, u8 y, u8 screen) {
	u8 pixel_colour;
	u16 put_y, put_x;
	for (put_y = y; put_y < y + FONT_HEIGHT; put_y++) {
		for (put_x = x; put_x < x + font_widths[(int)character]; put_x++) {
			pixel_colour = font[(int)character][put_y - y][put_x - x];
			if (screen == SCREEN_TOP) {
				switch (pixel_colour) {
					case 1:
						VRAM_A[put_x + put_y * SCREEN_WIDTH] = RGB15(7,7,7); // dark grey
						break;
					default:
						// transparent (do nothing)
						break;
				}
			} else {
				switch (pixel_colour) {
					case 1:
						BG_GFX_SUB[put_x + put_y * 256] = RGB15(7,7,7) | BIT(15); // dark grey
						break;
					default:
						// transparent (do nothing)
						break;
				}
			}
		}
	}
}

void print_highlighted_char(char character, u8 x, u8 y, u8 screen) {
	u8 pixel_colour;
	u16 put_y, put_x;
	for (put_y = y; put_y < y + FONT_HEIGHT; put_y++) {
		for (put_x = x; put_x < x + font_widths[(int)character]; put_x++) {
			pixel_colour = font[(int)character][put_y - y][put_x - x];
			if (screen == SCREEN_TOP) {
				switch (pixel_colour) {
					case 1:
						VRAM_A[put_x + put_y * SCREEN_WIDTH] = HIGHLIGHT_COLOUR;
						break;
					default:
						VRAM_A[put_x + put_y * SCREEN_WIDTH] = HIGHLIGHT_BGCOLOUR;
						break;
				}
			} else {
				switch (pixel_colour) {
					case 1:
						BG_GFX_SUB[put_x + put_y * 256] = HIGHLIGHT_COLOUR | BIT(15);
						break;
					default:
						BG_GFX_SUB[put_x + put_y * SCREEN_WIDTH] = HIGHLIGHT_BGCOLOUR | BIT(15);
						break;
				}
			}
		}
	}
}

void print_string_xy(char *string, u8 x, u8 y, u8 screen) {
	u16 put_x = x, put_y = y;
	u32 current_char = 0;
	
	while (string[current_char] != '\0') {
		print_char(string[current_char], put_x, put_y, screen);
		put_x += SPACE_BETWEEN_CHARS + font_widths[(int)string[current_char]];		
		current_char++;
	}
}

void print_string_highlighted(char *string, u8 x, u8 y, u8 screen, u16 highlight_start, u16 highlight_end) {
	u16 put_x = x, put_y = y, line_y, line_x;
	u32 current_char = 0;
	
	while (string[current_char] != '\0') {
		if ((highlight_start < highlight_end && current_char >= highlight_start && current_char < highlight_end) || (highlight_start > highlight_end && current_char < highlight_start && current_char >= highlight_end))
			print_highlighted_char(string[current_char], put_x, put_y, screen);
		else
			print_char(string[current_char], put_x, put_y, screen);
		
		put_x += font_widths[(int)string[current_char]];
		
		// Fill in space between chars
		if ((highlight_start < highlight_end && current_char >= highlight_start && current_char < highlight_end) || (highlight_start > highlight_end && current_char < highlight_start && current_char >= highlight_end)) {
			for (line_y = put_y; line_y <= put_y+FONT_HEIGHT-1; line_y++) {
				for (line_x = put_x; line_x < put_x+SPACE_BETWEEN_CHARS; line_x++) {
					switch (screen) {
						case SCREEN_TOP:
							VRAM_A[line_x + line_y * SCREEN_WIDTH] = HIGHLIGHT_BGCOLOUR;
							break;
						case SCREEN_BOTTOM:
							BG_GFX_SUB[line_x + line_y * 256] = HIGHLIGHT_BGCOLOUR | BIT(15);
							break;
					}
				}
			}
		}
		
		put_x += SPACE_BETWEEN_CHARS;		
		current_char++;
	}
}

void print_string_center(char *string, u8 y, u8 screen) {
	u16 put_x = 127 - string_width(string, strlen(string))/2, put_y = y;
	u32 current_char = 0;
	
	while (string[current_char] != '\0') {
		print_char(string[current_char], put_x, put_y, screen);
		put_x += SPACE_BETWEEN_CHARS + font_widths[(int)string[current_char]];		
		current_char++;
	}
}

void print_string_right(char *string, u8 y, u8 screen) {
	u16 put_x = SCREEN_WIDTH - string_width(string, strlen(string)) - MARGIN_SIDES, put_y = y;
	u32 current_char = 0;
	
	while (string[current_char] != '\0') {
		print_char(string[current_char], put_x, put_y, screen);
		put_x += SPACE_BETWEEN_CHARS + font_widths[(int)string[current_char]];		
		current_char++;
	}
}

void print_string(char *string, u32 offset) {
	u8 page_done;
	u16 put_x, put_y;
	u32 current_char = offset, next_page_pos = offset;
	
	// Top screen
	page_done = 0;
	put_x = MARGIN_SIDES;
	put_y = MARGIN_MAIN_TOP;
	while (string[current_char] != '\0' && !page_done) {
		if (string[current_char] == '\n') {
			put_y += FONT_HEIGHT + SPACE_BETWEEN_LINES;
			put_x = MARGIN_SIDES;
		} else {
			print_char(string[current_char], put_x, put_y, SCREEN_TOP);
			put_x += SPACE_BETWEEN_CHARS + font_widths[(int)string[current_char]];
		}
		
		if (put_y > 192 - MARGIN_MAIN_BOTTOM - FONT_HEIGHT) {
			page_done = 1;
			next_page_pos = current_char+1; // Where it will continue printing from on the bottom screen
		}
		
		current_char++;
	}

	// Bottom screen (make sure we're not at the end of the string, first)
	if (string[current_char] != '\0') {
		page_done = 0;
		put_x = MARGIN_SIDES;
		put_y = MARGIN_SUB_TOP;
		current_char = next_page_pos;
		while (string[current_char] != '\0' && !page_done) {
			if (string[current_char] == '\n') {
				put_y += FONT_HEIGHT + SPACE_BETWEEN_LINES;
				put_x = MARGIN_SIDES;
			} else {
				print_char(string[current_char], put_x, put_y, SCREEN_BOTTOM);
				put_x += SPACE_BETWEEN_CHARS + font_widths[(int)string[current_char]];
			}
			
			if (put_y > 192 - MARGIN_SUB_BOTTOM - FONT_HEIGHT) {
				page_done = 1;
			}
			
			current_char++;
		}
	}
}

void print_number(u32 num, u8 x, u8 y, u8 screen) {
	char numstring[20] = "", numstring_reverse[20] = "";
	u32 number = num, quotient = 1, remainder = 0;
	char remainder_str[3] = "";
	u32 current_char = 0, current_char2 = 0;
	
	// Convert num into a string
	if (number == 0) {
		strcpy(numstring_reverse, "0");
	} else {
		while (quotient != 0) {
			remainder = number % 10;
			quotient = number / 10;
			remainder_str[0] = remainder+48;
			remainder_str[1] = '\0';
			strcat(numstring, remainder_str);
			number = quotient;
		}
		
		current_char = strlen(numstring)-1;
		while (current_char != 0) {
			numstring_reverse[current_char2] = numstring[current_char];
			current_char--;
			current_char2++;
		}
		numstring_reverse[current_char2] = numstring[current_char];
	}
	
	print_string_xy(numstring_reverse, x, y, screen);
}

void wordwrap_string(char *string) {
	u32 current_char = 0, last_space_pos = 0;
	u16 width = MARGIN_SIDES;
	
	// Goes through each char keeping track of the width it would be when actually printing out the string, and replaces
	// spaces with newlines where text would go past the right margin.
	while (string[current_char] != '\0') {
		width += font_widths[(int)string[current_char]] + SPACE_BETWEEN_CHARS;
		
		if (string[current_char] == '\n') {
			width = MARGIN_SIDES;
		}
		
		if (string[current_char] == ' ') {
			last_space_pos = current_char; // Used when changing the space into a newline
		}
		
		if (width > 256 - MARGIN_SIDES) {
			string[last_space_pos] = '\n';
			current_char = last_space_pos;
			width = MARGIN_SIDES;
		}
		
		current_char++;
	}
}

u32 scroll_down(char *string, u32 pos) {
	// Find the next newline or end of string
	while (string[pos] != '\n' && pos >= 0 && string[pos] != '\0')
		pos++;
	pos++;
	clear_screens();
	if (string[pos-1] == '\0') pos = scroll_up(string, pos); // If it's past the end of the string, scroll back up so you can at least see the very last line.
	print_string(string, pos);
	
	return pos;
}

u32 scroll_up(char *string, u32 pos) {
	u8 first_newline = 0;
	
	// Don't scroll up if we're already at the top
	if (pos > 0) {
		pos--;
		
		// Find closest newline (searching backwards)
		while ((string[pos] != '\n' || !first_newline) && pos > 0) {
			pos--;
			if (string[pos] == '\n') first_newline = 1;
		}
		if (pos != 0) pos++; // Don't print the newline
		clear_screens();
		print_string(string, pos);
	}
	
	return pos;
}

void clear_screen(u8 screen) {
	u32 i;
	
	switch (screen) {
		case SCREEN_TOP:
			for (i = 0; i < (SCREEN_HEIGHT+1) * (SCREEN_WIDTH+1); i++)
				VRAM_A[i] = RGB15(31,31,31); // white
			break;
		case SCREEN_BOTTOM:
			for (i = 0; i < 256*256; i++)
				BG_GFX_SUB[i] = RGB15(31,31,31) | BIT(15); // white
			break;
	}
}

void clear_screens() {
	u32 i;

	for (i = 0; i < 256*192; i++)
		VRAM_A[i] = RGB15(31,31,31); // white

	for (i = 0; i < 256*256; i++)
		BG_GFX_SUB[i] = RGB15(31,31,31) | BIT(15); // white
}

void clear_text() {
	u32 i, j;
	
	for (i = MARGIN_MAIN_TOP; i < (SCREEN_HEIGHT+1); i++)
		for (j = 0; j < (SCREEN_WIDTH+1); j++)
			VRAM_A[j + i * SCREEN_WIDTH] = RGB15(31,31,31); // white
	for (i = 0; i < (SCREEN_HEIGHT+1) - MARGIN_SUB_BOTTOM; i++)
		for (j = 0; j < (SCREEN_WIDTH+1); j++)
			BG_GFX_SUB[j + i * 256] = RGB15(31,31,31) | BIT(15); // white
}

u32 string_width(char *string, u8 length) {
	u32 width = 0, character = 0;
	
	while (character != length) {
		width += font_widths[(int)string[character]];
		width += SPACE_BETWEEN_CHARS;
		character++;
	}
	width--;
	
	return width;
}

void popup_text_box(char *string, u8 x, u8 y, u8 height, u8 width, u8 bgcolour, u8 bordercolour, u8 screen) {
	u8 put_x = x, put_y = y;
	u16 str_width = string_width(string, strlen(string));
	
	// Get default values
	if (x == 0) {
		x = (128 - str_width/2) - 5;
	}
	if (y == 0) {
		y = (96 - FONT_HEIGHT/2) - 5;
	}
	if (height == 0) {
		height = FONT_HEIGHT + 10;
	}
	if (width == 0) {
		width = str_width + 10;
	}
	
	// Draw box background
	for (put_x = x+1; put_x < x+width; put_x++) {
		for (put_y = y+1; put_y < y+height; put_y++) {
			if (screen == SCREEN_TOP) {
				VRAM_A[put_x + put_y * SCREEN_WIDTH] = RGB15(bgcolour,bgcolour,bgcolour);
			} else {
				BG_GFX_SUB[put_x + put_y * 256] = RGB15(bgcolour,bgcolour,bgcolour) | BIT(15);
			}
		}
	}
	
	// Draw borders
	for (put_x = x; put_x <= x+width; put_x++) {
		if (screen == SCREEN_TOP) {
			VRAM_A[put_x + y * SCREEN_WIDTH] = RGB15(bordercolour,bordercolour,bordercolour);
			VRAM_A[put_x + (y+height) * SCREEN_WIDTH] = RGB15(bordercolour,bordercolour,bordercolour);
		} else {
			BG_GFX_SUB[put_x + y * 256] = RGB15(bordercolour,bordercolour,bordercolour) | BIT(15);
			BG_GFX_SUB[put_x + (y+height) * 256] = RGB15(bordercolour,bordercolour,bordercolour) | BIT(15);
		}
	}
	for (put_y = y; put_y <= y+height; put_y++) {
		if (screen == SCREEN_TOP) {
			VRAM_A[x + put_y * SCREEN_WIDTH] = RGB15(bordercolour,bordercolour,bordercolour);
			VRAM_A[(x+width) + put_y * SCREEN_WIDTH] = RGB15(bordercolour,bordercolour,bordercolour);
		} else {
			BG_GFX_SUB[x + put_y * 256] = RGB15(bordercolour,bordercolour,bordercolour) | BIT(15);
			BG_GFX_SUB[(x+width) + put_y * 256] = RGB15(bordercolour,bordercolour,bordercolour) | BIT(15);
		}
	}

	// Put string
	print_string_xy(string, x+6, y+7, screen);
}

