#ifndef _sprite_h
#define _sprite_h

extern Screen screen;

class Sprite {
	public:
		// Constructors
		Sprite(u8 *the_data, Color the_color, s16 the_x, s16 the_y, u8 the_width, u8 the_height, u8 the_num_frames);
		~Sprite();
		
		// Accessors
		u8 *get_data() const { return data; }
		void set_data(u8 *new_data) { data = new_data; }
		void set_color(Color new_color) { color = new_color; }
		Color get_color() const { return color; }
		void set_x(s16 new_x) { x = new_x; }
		s16 get_x() const { return x; }
		void set_y(s16 new_y) { y = new_y; }
		s16 get_y() const { return y; }
		void move_x(s16 amount) { x += amount; }
		void move_y(s16 amount) { y += amount; }
		void set_width(u8 new_width) { width = new_width; }
		u8 get_width() const { return width; }
		void set_height(u8 new_height) { height = new_height; }
		u8 get_height() const { return height; }
		void set_frame(u8 new_frame) { frame = new_frame; }
		u8 get_frame() const { return frame; }
		void set_num_frames(u8 new_num_frames) { num_frames = new_num_frames; }
		u8 get_num_frames() const { return num_frames; }
		
		// Methods
		void draw() const;
		void erase(Color background_color) const;
		void next_frame();
		bool collision(Sprite *sprite) const;
		
	private:
		u8 *data;
		Color color;
		s16 x;
		s16 y;
		u8 width;
		u8 height;
		u8 frame;
		u8 num_frames;
};

#endif
