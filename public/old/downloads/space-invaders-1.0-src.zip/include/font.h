#ifndef _font_h
#define _font_h

class Font {
	public:
		// Constructors
		Font(u8 *the_data, u8 *the_widths);
		~Font();
		
		// Accessors
		void set_color(Color new_color) { color = new_color; }
		Color get_color() const { return color; }
		
		// Methods
		void print_char(char ch, s16 x, s16 y);
		void print_string(const char *string, s16 x, s16 y);
		void print_string_center(const char *string);
		void print_number(s32 num, s16 x, s16 y);
		u32 string_width(const char *string) const;
		
	private:
		u8 *data;
		u8 *widths;
		Color color;
};

extern Font font;

#endif
