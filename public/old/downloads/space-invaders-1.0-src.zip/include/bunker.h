#ifndef _bunker_h
#define _bunker_h

const Color BUNKER_COLOR = RGB(0, 31, 0);
const s16 BUNKER_Y = 130;

class Bunker: public Sprite {
	public:
		// Constructors
		Bunker();
		~Bunker();
	
	private:
		u8 *bunker_pixels;
};

#endif
