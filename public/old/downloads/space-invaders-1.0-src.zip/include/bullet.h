#ifndef _bullet_h
#define _bullet_h

enum BulletType { BULLET_HUMAN = 0, BULLET_SQUIGGLY = 1, BULLET_CROSS = 2 };
enum Direction { DIRECTION_UP, DIRECTION_DOWN, DIRECTION_LEFT, DIRECTION_RIGHT };
const Color BULLET_COLOR = RGB(31, 31, 31);

class Bullet : public Sprite {
	public:
		// Constructors
		Bullet();
		~Bullet();
		
		// Accessors
		BulletType get_type() const { return type; }
		void set_type(BulletType new_type) { type = new_type; }
		Direction get_direction() const { return direction; }
		void set_direction(Direction new_direction) { direction = new_direction; }
		
		// Methods
		void init(BulletType the_type, s16 the_x, s16 the_y);
		bool move();
		
	private:
		BulletType type;
		Direction direction;
};

#endif
