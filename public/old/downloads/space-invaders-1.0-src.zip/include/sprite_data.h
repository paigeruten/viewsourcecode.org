#ifndef _sprite_data_h
#define _sprite_data_h

// The player
const u8 PLAYER_WIDTH = 15;
const u8 PLAYER_HEIGHT = 8;
extern u8 player_data[PLAYER_WIDTH * PLAYER_HEIGHT * 3];

// Space invaders
const u8 NUM_INVADERS = 3;
const u8 INVADER_WIDTH = 12;
const u8 INVADER_HEIGHT = 8;
extern u8 invaders_data[NUM_INVADERS][INVADER_WIDTH * INVADER_HEIGHT * 2];
extern u8 invader_exploded[INVADER_WIDTH * INVADER_HEIGHT];

// Bunker
const u8 BUNKER_WIDTH = 24;
const u8 BUNKER_HEIGHT = 18;
extern u8 bunker_data[BUNKER_WIDTH * BUNKER_HEIGHT];

// UFO
const u8 UFO_WIDTH = 16;
const u8 UFO_HEIGHT = 7;
extern u8 ufo_data[UFO_WIDTH * UFO_HEIGHT];

// Bullets
const u8 NUM_BULLETS = 3;
const u8 BULLET_WIDTH = 3;
const u8 BULLET_HEIGHT = 5;
extern u8 bullets_data[NUM_BULLETS][BULLET_WIDTH * BULLET_HEIGHT * 2];

#endif
