#ifndef _game_h
#define _game_h

const u8 INVADER_ROWS = 5;
const u8 INVADER_COLUMNS = 11;

const s16 INVADERS_X = 16;
const s16 INVADERS_Y = 64;
const u8 INVADERS_SPACING = 5;

const s16 INVADERS_X_RIGHT = SCREEN_WIDTH - INVADERS_X - ((INVADER_COLUMNS * INVADER_WIDTH) + (INVADER_COLUMNS * INVADERS_SPACING) - INVADERS_SPACING);

const u8 MAX_BULLETS = 10;

enum GameState { GAMESTATE_WON, GAMESTATE_LOST, GAMESTATE_PLAYING };

class Game {
	public:
		// Constructors
		Game();
		~Game();
		void construct();
		void destruct();
		
		// Methods
		void start();
		void game();
		
	private:
		Player *player;
		Bullet *bullets[MAX_BULLETS];
		Invader *invaders[INVADER_ROWS][INVADER_COLUMNS];
		UFO *ufo;
		u32 vblank_count;
		bool shot;
		u8 invaders_x;
		u8 invaders_y;
		u8 speed;
		Direction direction;
		GameState state;
		u16 wave;
		u8 num_alive_invaders;
		u32 score;
		u8 lives;
		
		void handle_input();
		void erase(Color color) const;
		void update();
		void draw() const;
		void update_info_bar() const;
};

#endif
