#ifndef _ufo_h
#define _ufo_h

enum UfoState { UFO_FLYING, UFO_NOT_FLYING, UFO_SHOT_DOWN };

const Color UFO_COLOR = RGB(31, 0, 0);
const s16 UFO_Y = 50;

class UFO : public Sprite {
	public:
		// Constructors
		UFO();
		~UFO();
		
		// Accessors
		void set_state(UfoState new_state) { state = new_state; timer = 0; }
		UfoState get_state() const { return state; }
		
		// Methods
		void move();
		void reset();
		u32 score();
		
	private:
		Direction direction;
		UfoState state;
		u32 timer;
		u16 last_score;
};

#endif
