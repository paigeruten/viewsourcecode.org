#ifndef _invader_h
#define _invader_h

enum InvaderType { INVADER_OCTOPUS = 0, INVADER_CRAB = 1, INVADER_SQUID = 2 };
enum InvaderState { INVADER_OK, INVADER_EXPLODING, INVADER_DEAD };

const Color INVADER_COLOR = RGB(31, 31, 31);

class Invader : public Sprite {
	public:
		// Constructors
		Invader();
		~Invader();
		
		// Accessors
		InvaderType get_type() const { return type; }
		void set_type(InvaderType new_type) { type = new_type; }
		InvaderState get_state() const { return state; }
		void set_state(InvaderState new_state) { state = new_state; }
		
		// Methods
		void init(InvaderType the_type, s16 the_x, s16 the_y);
		void update(u32 vblank_count, bool animate, Direction direction);
		u8 points_worth() const;
		
	private:
		InvaderType type;
		InvaderState state;
		u32 when_exploded;
};

#endif
