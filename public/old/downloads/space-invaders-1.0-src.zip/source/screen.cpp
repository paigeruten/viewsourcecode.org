#include <nds.h>
#include "screen.h"

Screen::Screen() {
	// Main screen turn on
	videoSetMode(MODE_5_2D | DISPLAY_BG3_ACTIVE | DISPLAY_SPR_ACTIVE | DISPLAY_SPR_1D);
	vramSetBankA(VRAM_A_MAIN_BG_0x06000000);
	BACKGROUND.control[3] = BG_BMP16_256x256 | BG_BMP_BASE(0);
	BACKGROUND.bg3_rotation.xdy = 0;
	BACKGROUND.bg3_rotation.xdx = 1 << 8;
	BACKGROUND.bg3_rotation.ydx = 0;
	BACKGROUND.bg3_rotation.ydy = 1 << 8;
	
	// Sub screen
	videoSetModeSub(MODE_5_2D | DISPLAY_BG3_ACTIVE);
	vramSetBankC(VRAM_C_SUB_BG_0x06200000);
	BACKGROUND_SUB.control[3] = BG_BMP16_256x256 | BG_BMP_BASE(0);
	BACKGROUND_SUB.bg3_rotation.xdy = 0;
	BACKGROUND_SUB.bg3_rotation.xdx = 1 << 8;
	BACKGROUND_SUB.bg3_rotation.ydx = 0;
	BACKGROUND_SUB.bg3_rotation.ydy = 1 << 8;
	
	// Set screen pointers
	screens[SCREEN_TOP] = (Color *)BG_BMP_RAM(0);
	screens[SCREEN_BOTTOM] = (Color *)BG_BMP_RAM_SUB(0);

	// Screens should not be swapped at this point
	screens_swapped = false;
}

Screen::~Screen() {
}

void Screen::clear(Color color) const {
	u16 i;

	for (i = 0; i < SCREEN_WIDTH * SCREEN_HEIGHT; i++) {
		screens[SCREEN_TOP][i] = color;
		screens[SCREEN_BOTTOM][i] = color;
	}
}

void Screen::darken() const {
	u16 i;
	Color pixel;
	
	for (i = 0; i < SCREEN_WIDTH * SCREEN_HEIGHT; i++) {
		pixel = screens[SCREEN_TOP][i];
		screens[SCREEN_TOP][i] = ((pixel & 0x1F) >> 1) |
		                          ((((pixel >> 5) & 0x1F) >> 1) << 5) |
		                          ((((pixel >> 10) & 0x1F) >> 1) << 10) |
								  (1 << 15);
	}
}

Color Screen::get_pixel(u16 x, u16 y) const {
	u8 screen = SCREEN_TOP;
	
	if (y >= SCREEN_HEIGHT) {
		y -= SCREEN_HEIGHT;
		screen = SCREEN_BOTTOM;
	}
	
	return screens[screen][x + y * SCREEN_WIDTH];
}
