#include <nds.h>
#include "screen.h"
#include "sprite.h"
#include "sprite_data.h"
#include "player.h"

void Player::move_left(u8 amount) {
	if (get_x() - amount < PLAYER_MARGIN) {
		set_x(PLAYER_MARGIN);
	} else {
		move_x(-amount);
	}
}

void Player::move_right(u8 amount) {
	if (get_x() + amount > SCREEN_WIDTH - PLAYER_MARGIN - get_width()) {
		set_x(SCREEN_WIDTH - PLAYER_MARGIN - get_width());
	} else {
		move_x(amount);
	}
}
