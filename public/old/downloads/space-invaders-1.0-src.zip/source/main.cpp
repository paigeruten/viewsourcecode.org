#include <nds.h>
#include "screen.h"
#include "sprite.h"
#include "sprite_data.h"
#include "player.h"
#include "bullet.h"
#include "invader.h"
#include "ufo.h"
#include "game.h"
#include "font_data.h"
#include "font.h"

Screen screen;
Font font(font_data, font_widths);

int main(void) {
	irqInit();
	irqEnable(IRQ_VBLANK);

	Screen screen;

	while (1) {
		Game space_invaders;

		screen.clear(RGB(0, 0, 0));

		space_invaders.start();
		
		screen.clear(RGB(0, 0, 0));
		
		font.set_color(RGB(0, 31, 0));
		font.print_string_center("-Game Over-");

		while (keysHeld() & KEY_START) { scanKeys(); }
		while (!(keysHeld() & KEY_START)) { scanKeys(); }
		while (keysHeld() & KEY_START) { scanKeys(); }
	}

	return 0;
}
