#include <nds.h>
#include <string.h>
#include "screen.h"
#include "sprite_data.h"
#include "sprite.h"
#include "bunker.h"

Bunker::Bunker() : Sprite(NULL, BUNKER_COLOR, 0, BUNKER_Y, BUNKER_WIDTH, BUNKER_HEIGHT, 1) {
	bunker_pixels = new u8 [BUNKER_WIDTH * BUNKER_HEIGHT];
	memcpy(bunker_pixels, bunker_data, BUNKER_WIDTH * BUNKER_HEIGHT);
	
	set_data(bunker_pixels);
}

Bunker::~Bunker() {
	delete [] bunker_pixels;
	bunker_pixels = NULL;
}
