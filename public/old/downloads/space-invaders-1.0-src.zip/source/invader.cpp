#include <nds.h>
#include "screen.h"
#include "sprite_data.h"
#include "sprite.h"
#include "bullet.h"
#include "invader.h"

Invader::Invader() : Sprite(NULL, INVADER_COLOR, 0, 0, INVADER_WIDTH, INVADER_HEIGHT, 2) {
	type = INVADER_OCTOPUS;
	state = INVADER_OK;
	when_exploded = 0;
}

Invader::~Invader() {
}

void Invader::init(InvaderType the_type, s16 the_x, s16 the_y) {
	type = the_type;
	set_x(the_x);
	set_y(the_y);
	
	set_data(&invaders_data[type][0]);
}

void Invader::update(u32 vblank_count, bool animate, Direction direction) {
	if (animate) {
		next_frame();
		
		switch (direction) {
			case DIRECTION_UP:
				move_y(-5);
				break;
			
			case DIRECTION_DOWN:
				move_y(5);
				break;
			
			case DIRECTION_LEFT:
				move_x(-2);
				break;
			
			case DIRECTION_RIGHT:
				move_x(2);
				break;
		}
	}
	
	if (state == INVADER_EXPLODING) {
		if (when_exploded == 0) {
			when_exploded = vblank_count;
			
			set_data(invader_exploded);
			set_num_frames(1);
			set_frame(0);
		} else {
			if (vblank_count - when_exploded > 20) {
				state = INVADER_DEAD;
			}
		}
	}
}

u8 Invader::points_worth() const {
	u8 points;

	switch (type) {
		case INVADER_OCTOPUS:
			points = 10;
			break;
			
		case INVADER_CRAB:
			points = 20;
			break;
			
		case INVADER_SQUID:
			points = 30;
			break;
			
		default:
			points = 0;
			break;
	}
	
	return points;
}
