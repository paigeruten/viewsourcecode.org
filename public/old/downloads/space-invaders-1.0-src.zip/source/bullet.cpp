#include <nds.h>
#include "screen.h"
#include "sprite.h"
#include "sprite_data.h"
#include "bullet.h"

Bullet::Bullet() : Sprite(NULL, BULLET_COLOR, 0, 0, BULLET_WIDTH, BULLET_HEIGHT, 2) {
}

Bullet::~Bullet() {
}

bool Bullet::move() {
	u8 speed;

	switch (type) {
		case BULLET_HUMAN:
			speed = 3;
			break;
		
		case BULLET_SQUIGGLY:
		case BULLET_CROSS:
			speed = 2;
			break;
	}

	switch (direction) {
		case DIRECTION_UP:
			move_y(-speed);
			break;
		case DIRECTION_DOWN:
			move_y(speed);
			break;
	}
	
	if (get_y() < 32 || get_y() > SCREEN_HEIGHT - get_height()) {
		return false;
	} else {
		return true;
	}
}

void Bullet::init(BulletType the_type, s16 the_x, s16 the_y) {
	type = the_type;
	
	switch (type) {
		case BULLET_HUMAN:
			direction = DIRECTION_UP;
			break;
			
		case BULLET_SQUIGGLY:
		case BULLET_CROSS:
			direction = DIRECTION_DOWN;
			break;
	}
	
	set_data(&bullets_data[type][0]);
	set_x(the_x);
	set_y(the_y);
}
