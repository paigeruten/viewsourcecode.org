#include <nds.h>
#include <string.h>
#include "screen.h"
#include "font_data.h"
#include "font.h"

Font::Font(u8 *the_data, u8 *the_widths) {
	data = the_data;
	widths = the_widths;
	color = RGB(31, 31, 31);
}

Font::~Font() {
}

void Font::print_char(char ch, s16 x, s16 y) {
	s16 put_x;
	s16 put_y;
	u8 get_x;
	u8 get_y;
	u32 offset = (u8)ch * FONT_WIDTH * FONT_HEIGHT;
	
	get_x = 0;
	
	for (put_x = x; put_x < x + widths[(u8)ch]; put_x++) {
		get_y = 0;
		
		for (put_y = y; put_y < y + FONT_HEIGHT; put_y++) {
			if (data[offset + (get_x + get_y * FONT_WIDTH)]) {
				if (put_x >= 0 && put_x < SCREEN_WIDTH && put_y >= 0 && put_y < SCREEN_HEIGHT * 2) {
					screen.plot(put_x, put_y, color);
				}
			}
			
			get_y++;
		}
		
		get_x++;
	}
}

void Font::print_string(const char *string, s16 x, s16 y) {
	u32 current_char = 0;
	s16 put_x = x, put_y = y;
	
	while (string[current_char]) {
		print_char(string[current_char], put_x, put_y);
		put_x += widths[(u8)string[current_char]] + 1;
		
		current_char++;
	}
}

void Font::print_string_center(const char *string) {
	s16 x = SCREEN_WIDTH / 2 - string_width(string) / 2;
	s16 y = SCREEN_HEIGHT / 2 - FONT_HEIGHT / 2;
	
	print_string(string, x, y);
}

void Font::print_number(s32 num, s16 x, s16 y) {
	char numstring[10] = "";
	u32 number = num, quotient = 1, remainder = 0;
	char remainder_str[3] = "";
	u32 current_char = 0, current_char2 = 0;
	static char string[100];
	
	if (number == 0) {
		strcpy(string, "0");
	} else {
		while (quotient != 0) {
			remainder = number % 10;
			quotient = number / 10;
			remainder_str[0] = remainder+48;
			remainder_str[1] = '\0';
			strcat(numstring, remainder_str);
			number = quotient;
		}
		
		current_char = strlen(numstring)-1;
		while (current_char != 0) {
			string[current_char2] = numstring[current_char];
			current_char--;
			current_char2++;
		}
		string[current_char2] = numstring[current_char];
		string[current_char2 + 1] = '\0';
	}
	
	print_string(string, x, y);
}


u32 Font::string_width(const char *string) const {
	u32 current_char = 0;
	u32 width = 0;
	
	while (string[current_char]) {
		width += widths[(u8)string[current_char]] + 1;
		
		current_char++;
	}
	
	return width - 1;
}
