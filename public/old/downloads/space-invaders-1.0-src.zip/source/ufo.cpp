#include <nds.h>
#include <stdlib.h>
#include "screen.h"
#include "sprite_data.h"
#include "sprite.h"
#include "bullet.h"
#include "ufo.h"
#include "font.h"

UFO::UFO() : Sprite(ufo_data, UFO_COLOR, -(UFO_WIDTH), UFO_Y, UFO_WIDTH, UFO_HEIGHT, 1) {
	state = UFO_NOT_FLYING;
}

UFO::~UFO() {
}

void UFO::move() {
	if (state == UFO_FLYING) {
		switch (direction) {
			case DIRECTION_LEFT:
				if (get_x() < -get_width()) {
					state = UFO_NOT_FLYING;
				} else {
					move_x(-2);
				}
				break;
			
			case DIRECTION_RIGHT:
				if (get_x() > SCREEN_WIDTH) {
					state = UFO_NOT_FLYING;
				} else {
					move_x(2);
				}
				break;
		}
	}
	
	if (state == UFO_SHOT_DOWN && timer >= 16) {
		state = UFO_NOT_FLYING;
		timer = 0;
	}
	
	if (state == UFO_SHOT_DOWN) {
		if (timer % 4 == 0 || timer == 0) {
			font.set_color(RGB(31, 0, 0));
			font.print_number(last_score, get_x() + 2, get_y() + 1);
		} else if (timer % 2 == 0) {
			font.set_color(RGB(0, 0, 0));
			font.print_number(last_score, get_x() + 2, get_y() + 1);
		}
		
		timer++;
	}
}

void UFO::reset() {
	if (rand() & 1) {
		direction = DIRECTION_LEFT;
		set_x(SCREEN_WIDTH);
	} else {
		direction = DIRECTION_RIGHT;
		set_x(-get_width());
	}
	
	state = UFO_FLYING;
}

u32 UFO::score() {
	u16 possible_scores[6] = { 50, 100, 150, 200, 250, 300 };
	
	last_score = possible_scores[rand() % 6];
	
	return last_score;
}
