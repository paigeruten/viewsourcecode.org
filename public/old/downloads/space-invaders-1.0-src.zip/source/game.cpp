#include <nds.h>
#include <stdlib.h>
#include "screen.h"
#include "sprite_data.h"
#include "sprite.h"
#include "player.h"
#include "bullet.h"
#include "invader.h"
#include "font_data.h"
#include "font.h"
#include "ufo.h"
#include "game.h"

Game::Game() {
	construct();
}

Game::~Game() {
	destruct();
}

void Game::construct() {
	vblank_count = 0;
	shot = false;
	player = new Player;
	ufo = new UFO;
	invaders_x = INVADERS_X;
	invaders_y = INVADERS_Y;
	direction = DIRECTION_RIGHT;
	speed = 50;
	state = GAMESTATE_PLAYING;
	wave = 1;
	num_alive_invaders = INVADER_ROWS * INVADER_COLUMNS;
	score = 0;
	lives = 3;
	
	for (u8 i = 0; i < MAX_BULLETS; i++) {
		bullets[i] = NULL;
	}
	
	InvaderType invader_type;
	for (u8 i = 0; i < INVADER_ROWS; i++) {
		switch (i) {
			case 0:
				invader_type = INVADER_SQUID;
				break;
				
			case 1:
			case 2:
				invader_type = INVADER_CRAB;
				break;
				
			case 3:
			case 4:
				invader_type = INVADER_OCTOPUS;
				break;
			
			default:
				invader_type = INVADER_OCTOPUS;
		}
		
		for (u8 j = 0; j < INVADER_COLUMNS; j++) {
			s16 invader_x = INVADERS_X + (j * INVADER_WIDTH) + (j * INVADERS_SPACING);
			s16 invader_y = INVADERS_Y + (i * INVADER_HEIGHT) + (i * INVADERS_SPACING);
		
			invaders[i][j] = new Invader;
			invaders[i][j]->init(invader_type, invader_x, invader_y);
		}
	}
}

void Game::destruct() {
	delete player;
	player = NULL;
	
	delete ufo;
	ufo = NULL;
	
	for (u8 i = 0; i < MAX_BULLETS; i++) {
		if (bullets[i] != NULL) {
			delete bullets[i];
			bullets[i] = NULL;
		}
	}
	
	for (u8 i = 0; i < INVADER_ROWS; i++) {
		for (u8 j = 0; j < INVADER_COLUMNS; j++) {
			delete invaders[i][j];
			invaders[i][j] = NULL;
		}
	}
}

void Game::start() {
	while (true) {
		game();
		
		screen.clear(RGB(0, 0, 0));
		
		if (state == GAMESTATE_LOST) {
			break;
		}
		
		u8 the_wave = wave + 1;
		u32 the_score = score;
		u8 the_player_x = player->get_x();
		u8 the_lives = lives;
		
		destruct();
		construct();
		
		wave = the_wave;
		score = the_score;
		player->set_x(the_player_x);
		lives = the_lives;
	}
}

void Game::game() {
	state = GAMESTATE_PLAYING;
	
	update_info_bar();
	
	while (state == GAMESTATE_PLAYING) {
		scanKeys();
		
		erase(RGB(0, 0, 0));
		handle_input();
		update();
		draw();
		
		swiWaitForVBlank();
		vblank_count++;
	}
}

void Game::handle_input() {
	if (keysHeld() & (KEY_LEFT | KEY_Y)) {
		player->move_left(2);
	}
	
	if (keysHeld() & (KEY_RIGHT | KEY_A)) {
		player->move_right(2);
	}
	
	if ((keysHeld() & (KEY_L | KEY_R)) && !shot) {
		for (u8 i = 0; i < MAX_BULLETS; i++) {
			if (bullets[i] == NULL) {
				bullets[i] = new Bullet;
				bullets[i]->init(BULLET_HUMAN, player->get_x() + (player->get_width() / 2), player->get_y());
				shot = true;
				
				break;
			}
		}
	}
	
	if (keysHeld() & KEY_START) {
		draw();
		screen.darken();
		screen.darken();
		font.set_color(RGB(0, 31, 0));
		font.print_string_center("-Paused-");
		
		while (keysHeld() & KEY_START) { scanKeys(); swiWaitForVBlank(); }	
		while (!(keysHeld() & KEY_START)) { scanKeys(); swiWaitForVBlank(); }
		while (keysHeld() & KEY_START) { scanKeys(); swiWaitForVBlank(); }
		
		screen.clear(RGB(0, 0, 0));
		
		update_info_bar();
	}
}

void Game::erase(Color color) const {
	player->erase(color);
	
	if (ufo->get_state() == UFO_FLYING) {
		ufo->erase(color);
	}
	
	for (u8 i = 0; i < MAX_BULLETS; i++) {
		if (bullets[i] != NULL) {
			bullets[i]->erase(color);
		}
	}
	
	for (u8 i = 0; i < INVADER_ROWS; i++) {
		for (u8 j = 0; j < INVADER_COLUMNS; j++) {
			invaders[i][j]->erase(color);
		}
	}
}

void Game::update() {
	bool animate = false;

	if (vblank_count % speed == 0) {
		animate = true;
		
		if (direction == DIRECTION_DOWN) {
			if (invaders_x <= INVADERS_X) {
				direction = DIRECTION_RIGHT;
			} else {
				direction = DIRECTION_LEFT;
			}
		} else {		
			if (direction == DIRECTION_LEFT && invaders_x <= INVADERS_X) {
				direction = DIRECTION_DOWN;
			}
			
			if (direction == DIRECTION_RIGHT && invaders_x >= INVADERS_X_RIGHT) {
				direction = DIRECTION_DOWN;
			}
		}
		
		switch (direction) {
			case DIRECTION_RIGHT:
				invaders_x += 2;
				break;
			
			case DIRECTION_DOWN:
				invaders_y += 5;
				break;
			
			case DIRECTION_LEFT:
				invaders_x -= 2;
				break;
		}
	}
	
	num_alive_invaders = 0;
	for (u8 i = 0; i < INVADER_ROWS; i++) {
		for (u8 j = 0; j < INVADER_COLUMNS; j++) {
			invaders[i][j]->update(vblank_count, animate, direction);
			
			if (invaders[i][j]->get_state() == INVADER_OK) {
				if (invaders[i][j]->get_y() >= PLAYER_Y - 16) {
					state = GAMESTATE_LOST;
				}
				
				if (rand() % (speed * 30) == 0) {
					// Check if the current invader is at the bottom of its column
					bool at_bottom = true;
					
					for (u8 k = i + 1; k < INVADER_COLUMNS; k++) {
						if (invaders[k][j]->get_state() == INVADER_OK) {
							at_bottom = false;
							break;
						}
					}
					
					if (at_bottom) {					
						for (u8 k = 0; k < MAX_BULLETS; k++) {
							if (bullets[k] == NULL) {
								BulletType bullet_type;
								
								if (rand() & 1) {
									bullet_type = BULLET_SQUIGGLY;
								} else {
									bullet_type = BULLET_CROSS;
								}
							
								bullets[k] = new Bullet;
								bullets[k]->init(bullet_type, invaders[i][j]->get_x() + (invaders[i][j]->get_width() / 2), invaders[i][j]->get_y());
								
								break;
							}
						}
					}
				}
				
				num_alive_invaders++;
			}
		}
	}
	
	if (wave >= 20) {
		speed = 3;
	} else {
		u8 new_speed = (num_alive_invaders + (3 * (20 - wave))) / 2;
		if (new_speed <= speed - 5) {
			speed = new_speed;
		}
	}
	
	if (speed < 3) { speed = 3; }
	
	if (num_alive_invaders == 0) {
		state = GAMESTATE_WON;
	}
	
	if (ufo->get_state() != UFO_NOT_FLYING) {
		if (vblank_count % 4 == 0) {
			ufo->move();
		}
	} else {
		if (rand() % 1000 == 0) {
			ufo->reset();
		}
	}
	
	for (u8 i = 0; i < MAX_BULLETS; i++) {
		if (bullets[i] != NULL) {
			bool on_screen;
			
			if (bullets[i]->get_type() == BULLET_HUMAN) {
				for (u8 row = 0; row < INVADER_ROWS; row++) {
					for (u8 column = 0; column < INVADER_COLUMNS; column++) {
						if (invaders[row][column]->get_state() == INVADER_OK) {
							if (bullets[i]->collision(invaders[row][column])) {
								delete bullets[i];
								bullets[i] = NULL;
								
								shot = false;
								
								invaders[row][column]->set_state(INVADER_EXPLODING);
								
								u32 old_score = score;
								
								score += invaders[row][column]->points_worth();
								lives += (score / 1500) - (old_score / 1500);
								
								update_info_bar();
								
								goto bullet_is_gone_so_no_more_collisions;
							}
						}
					}
				}
				
				if (ufo->get_state() == UFO_FLYING && bullets[i]->collision(ufo)) {
					delete bullets[i];
					bullets[i] = NULL;
					
					shot = false;
					
					ufo->set_state(UFO_SHOT_DOWN);
					ufo->erase(RGB(0, 0, 0));
					
					u32 old_score = score;
					
					score += ufo->score();
					lives += (score / 1500) - (old_score / 1500);
					
					update_info_bar();
				}
				
				bullet_is_gone_so_no_more_collisions: ;
			} else {
				if (bullets[i]->collision(player)) {
					bullets[i]->erase(RGB(0, 0, 0));
				
					for (u8 k = 0; k < MAX_BULLETS; k++) {
						if (bullets[k] != NULL) {
							delete bullets[k];
							bullets[k] = NULL;
						}
					}
					
					draw();
					
					player->set_frame(1);
					
					for (u16 vblank = 0; vblank < 90; vblank++) {
						player->erase(RGB(0, 0, 0));
						player->draw();
						
						if (vblank % 8 == 0) {
							player->next_frame();
							
							if (player->get_frame() == 0) {
								player->next_frame();
							}
						}
						
						swiWaitForVBlank();
					}
					
					lives--;
					
					if (lives == 0) {
						state = GAMESTATE_LOST;
					}
					
					update_info_bar();
					
					player->set_frame(0);
					player->erase(RGB(0, 0, 0));
					player->draw();
					
					shot = false;
				}
			}
			
			if (bullets[i] != NULL) {			
				on_screen = bullets[i]->move();
				
				if (vblank_count % 10 == 0) {
					bullets[i]->next_frame();
				}
				
				if (!on_screen) {
					if (bullets[i]->get_type() == BULLET_HUMAN) {
						shot = false;
					}
				
					delete bullets[i];
					bullets[i] = NULL;
				}
			}
		}
	}
}

void Game::draw() const {
	player->draw();
	
	if (ufo->get_state() == UFO_FLYING) {
		ufo->draw();
	}
	
	for (u8 i = 0; i < MAX_BULLETS; i++) {
		if (bullets[i] != NULL) {
			bullets[i]->draw();
		}
	}
	
	for (u8 i = 0; i < INVADER_ROWS; i++) {
		for (u8 j = 0; j < INVADER_COLUMNS; j++) {
			if (invaders[i][j]->get_state() != INVADER_DEAD) {
				invaders[i][j]->draw();
			}
		}
	}
}

void Game::update_info_bar() const {
	for (u16 put_x = font.string_width("Score") + 15; put_x < font.string_width("Score") + 65; put_x++) {
		for (u16 put_y = 10; put_y < 10 + FONT_HEIGHT; put_y++) {
			screen.plot(put_x, put_y, RGB(0, 0, 0));
		}
	}
	
	for (u16 put_x = font.string_width("Lives") + 100; put_x < SCREEN_WIDTH; put_x++) {
		for (u16 put_y = 7; put_y < 7 + PLAYER_HEIGHT*2 + 5; put_y++) {
			screen.plot(put_x, put_y, RGB(0, 0, 0));
		}
	}
	
	font.set_color(RGB(31, 31, 31));
	font.print_string("Score", 10, 10);
	font.set_color(RGB(0, 31, 0));
	font.print_number(score, font.string_width("Score") + 15, 10);
	
	font.set_color(RGB(31, 31, 31));
	font.print_string("Lives", 95, 10);
	
	u8 put_x = font.string_width("Lives") + 100;
	u8 put_y = 7;

	Sprite laser_turret(player_data, PLAYER_COLOR, put_x, put_y, PLAYER_WIDTH, PLAYER_HEIGHT, 3);
	
	for (u8 i = 1; i <= lives; i++) {
		laser_turret.draw();
		put_x += laser_turret.get_width() + 5;
		
		if (put_x + laser_turret.get_width() + 5 >= SCREEN_WIDTH) {
			put_x = font.string_width("Lives") + 100;
			put_y += laser_turret.get_height() + 5;
		}
		
		laser_turret.set_x(put_x);
		laser_turret.set_y(put_y);
	}
}
