#include <nds.h>
#include "screen.h"
#include "sprite.h"

Sprite::Sprite(u8 *the_data, Color the_color, s16 the_x, s16 the_y, u8 the_width, u8 the_height, u8 the_num_frames) {
	data = the_data;
	color = the_color;
	x = the_x;
	y = the_y;
	width = the_width;
	height = the_height;
	num_frames = the_num_frames;
	frame = 0;
}

Sprite::~Sprite() {
}

void Sprite::draw() const {
	u16 offset = frame * width * height;
	s16 put_x;
	s16 put_y;
	u8 get_x;
	u8 get_y;
	
	get_x = 0;
	
	for (put_x = x; put_x < x + width; put_x++) {
		get_y = 0;
		
		for (put_y = y; put_y < y + height; put_y++) {
			if (data[offset + (get_x + get_y * width)]) {
				if (put_x >= 0 && put_x < SCREEN_WIDTH && put_y >= 0 && put_y < SCREEN_HEIGHT * 2) {
					screen.plot(put_x, put_y, color);
				}
			}
			
			get_y++;
		}
		
		get_x++;
	}
}

void Sprite::erase(Color background_color) const {
	s16 put_x;
	s16 put_y;
	
	for (put_x = x; put_x < x + width; put_x++) {		
		for (put_y = y; put_y < y + height; put_y++) {
			screen.plot(put_x, put_y, background_color);
		}
	}
}

void Sprite::next_frame() {
	frame++;
	
	if (frame >= num_frames) {
		frame = 0;
	}
}

bool Sprite::collision(Sprite *sprite) const {
	s16 sprite1_x = x;
	s16 sprite1_y = y;
	u8 sprite1_width = width;
	u8 sprite1_height = height;
	
	s16 sprite2_x = sprite->get_x();
	s16 sprite2_y = sprite->get_y();
	u8 sprite2_width = sprite->get_width();
	u8 sprite2_height = sprite->get_height();
	
	// Fix a weird bug
	sprite2_x += sprite2_width / 2;

	return (sprite2_x >= sprite1_x - (sprite1_width + sprite2_width) / 2) &&
	       (sprite2_x <= sprite1_x + (sprite1_width + sprite2_width) / 2) &&
	       (sprite2_y >= sprite1_y - (sprite1_height + sprite2_height) / 2) &&
	       (sprite2_y <= sprite1_y + (sprite1_height + sprite2_height) / 2);
}
