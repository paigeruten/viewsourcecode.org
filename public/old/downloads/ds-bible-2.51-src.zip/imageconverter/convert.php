<?php

// Use this script to convert PNG and JPEG images to image files that my Image class can use.
// To use it from the command line type something like:
/*
	$ php convert.php image.png
*/
// And it'll make a new file called image.img
// The image type is inferred from the filename's extension.

function get_rgb($rgb) {
	$r = ($rgb >> 16) & 0xFF;
	$g = ($rgb >> 8) & 0xFF;
	$b = $rgb & 0xFF;
	
	return array($r, $g, $b);
}

// Prints debugging information if '--debug' is passed as a command line argument
function debug($txt) {
	global $argv;

	if (in_array('--debug', $argv)) {
		echo $txt;
	}
}

// Load the image given as a command line argument
if (substr($argv[1], -3) == 'jpg') {
	$img = imagecreatefromjpeg($argv[1]);
} else {
	$img = imagecreatefrompng($argv[1]);
}

if (!$img) {
	die("Could not create image from $argv[1]!\n");
}

$img_info = getimagesize($argv[1]);
$img_size['x'] = $img_info[0];
$img_size['y'] = $img_info[1];

// Open output file. It will have the same path and name as the input file, except its extension will be .img.
$outfile = fopen(substr($argv[1], 0, strlen($argv[1]) - 3).'img', 'w');

// Write the width and height of the image to the output file.
fwrite($outfile, chr(intval($img_size['x'])));
fwrite($outfile, chr(intval($img_size['y'])));

// Loop through all the pixels of the image
for ($y = 0; $y < $img_size['y']; $y++) {
	for ($x = 0; $x < $img_size['x']; $x++) {
		// Get red green blue values of the current pixel
		list($r, $g, $b) = get_rgb(imagecolorat($img, $x, $y));
		
		debug("Red:      $r\nGreen:    $g\nBlue:     $b\n\n");
		
		// Set bit 15 of the new color
		$color = 1 << 15;
		
		// Current RGB values are out of 255. We need them out of 31.
		$r = round($r*31/255);
		$g = round($g*31/255);
		$b = round($b*31/255);
		
		debug("16-Red:   $r\n16-Green: $g\n16-Blue:  $b\n\n");
		
		// Write 5-bit RGB values to the color.
		$color |= $r;
		$color |= ($g << 5);
		$color |= ($b << 10);
		
		debug("Colour:   $color\n\n");
		
		// Split the 16-bit color into 2 bytes, since fwrite only writes single bytes to files.
		$color_low = $color & 0xFF;
		$color_high = ($color & (0xFF << 8)) >> 8;
		
		debug("Colour-high: $color_high\nColour-low:  $color_low\n\n-----\n\n");
		
		// Write the color to the output file
		fwrite($outfile, chr(intval($color_low)));
		fwrite($outfile, chr(intval($color_high)));
	}
}

fclose($outfile);

?>
