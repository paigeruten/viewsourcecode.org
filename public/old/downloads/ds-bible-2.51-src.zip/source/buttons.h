#ifndef _buttons_h
#define _buttons_h

#define NUM_OF_BUTTONS 8
#define BUTTON_HEIGHT 15
#define BUTTON_WIDTH 15

// Prints the buttons out on the bottom screen
void print_buttons(u16 *screen);

// Prints a single button
void print_button(u8 button_id, u8 x, u8 y, u8 pressed, u16 *screen);

// Check which button is pressed, if any
s8 button_pressed(u8 stylus_x, u8 stylus_y);

#endif

