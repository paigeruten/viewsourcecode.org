#include <nds.h>
#include <fat.h>
#include <stdio.h>
#include <string.h>
#include "load.h"
#include "str.h"
#include "books.h"
#include "screen.h"
#include "font.h"
#include "scroll.h"
#include "assoc_array.h"
#include "str_array.h"

extern u16 *screens[4];
extern AssocArray language;

char *book;
char bookname_long[32];
char bookname_short[4];
u32 chapters[151];
u32 verses[151][200];
extern char translation[256];
extern fpos_t book_positions[100];
extern u32 highlighted_text[256];
extern u32 highlighted_search_results[2048];

u8 load_book(char *bookname) {
	char current_book[3], last_book[3] = ":D", current_c[4], last_c[4], current_v[4];
	u8 colon_pos, second_space_pos, book_found = 0;
	u32 current_char = 0;
	char chapter_text[20];
	char *line;
	char *v_text;
	FILE *txt_file;
	
	strcpy(chapter_text, language.get("chapter"));
	
	// Don't bother loading the book if it's already loaded
	if (!strcmp(bookname, bookname_short)) {
		goto skip_loading;
	}
	
	memset(highlighted_search_results, 0, 2048);
	
	scrcpy(screens[BUFFER_TOP], screens[SCREEN_TOP]);
	scrcpy(screens[BUFFER_BOTTOM], screens[SCREEN_BOTTOM]);
	
	darken_screen(screens[BUFFER_TOP]);
	darken_screen(screens[BUFFER_BOTTOM]);
	
	draw_alert_box(language.get("loading_book"), screens[BUFFER_TOP]);
	
	scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
	scrcpy(screens[SCREEN_BOTTOM], screens[BUFFER_BOTTOM]);
	
	txt_file = fopen(translation, "r");
	
	if (txt_file == NULL) {
		return 1;
	}
	
	line = new char [1024];
	v_text = new char [1024];

	strcpy(bookname_short, bookname);
	strcpy(bookname_long, book_short2long(bookname));
	
	fseek(txt_file, book_positions[book_index(bookname_long)], SEEK_SET);
	
	while (fgets(line, 1024, txt_file)) {
		if (strlen(line) > 6) {
			strcpy(current_book, substr(line, 0, 2));
			
			if (!strcmp(current_book, bookname)) {
				book_found = 1;
				colon_pos = strpos(line, ":");
				second_space_pos = strpos(line, " ", 4);
				
				strcpy(current_c, substr(line, 4, colon_pos-1));
				strcpy(current_v, substr(line, colon_pos+1, second_space_pos-1));
				strcpy(v_text, substr(line, second_space_pos+1, strlen(line)-2));
				
				format_line(v_text);
				
				if (strcmp(current_c, last_c)) {
					if (strcmp(current_c, "1")) {
						strcpy(&book[current_char], "\n\n");
						current_char += 2;
					}
					chapters[intval(current_c)] = current_char;
					strcpy(&book[current_char], chapter_text);
					current_char += strlen(chapter_text);
					strcpy(&book[current_char], current_c);
					current_char += strlen(current_c);
					strcpy(&book[current_char], "\n");
					current_char++;
				}
				
				strcpy(last_c, current_c);
				
				verses[intval(current_c)][intval(current_v)] = current_char;
				
				strcpy(&book[current_char], superscript(current_v));
				current_char += strlen(superscript(current_v));
				
				if (v_text[strlen(v_text) - 1] != '\n') {
					strcat(v_text, " ");
				}
				
				strcpy(&book[current_char], v_text);
				current_char += strlen(v_text);
			} else if (book_found) {
				break;
			}
			
			strcpy(last_book, current_book);
		}
	}
	
	fclose(txt_file);
	
	delete [] line;
	delete [] v_text;
	
skip_loading:
	
	char *bookmarks = new char [4096];
		
	FILE *bookmarks_file = fopen("/bible/bookmarks", "r");
	strcpy(bookmarks, "");
	fgets(bookmarks, 4095, bookmarks_file);
	fclose(bookmarks_file);
	
	memset(highlighted_text, 0, 256);
	
	if (bookmarks[0]) {
		char the_book[32];
		char the_chapter[10];
		char the_verse[10];
		char str[32];
		s32 the_position;
		u8 current_index = 0;
		for (u8 i = 0; i < count(bookmarks); i++) {
			if (check_location(array_index(bookmarks, i), the_book, the_chapter, the_verse)) {
				if (!strcmp(the_book, bookname_short)) {
					strcpy(str, language.get("chapter"));
					strcat(str, the_chapter);
					the_position = strpos(book, str);
					
					if (the_position != -1) {
						strcpy(str, the_verse);
						current_char = 0;
						while (str[current_char] != '\0') {
							str[current_char] += 120;
							current_char++;
						}
						the_position = strpos(book, str, the_position);
						
						highlighted_text[current_index] = the_position;
						
						while (book[the_position] >= 168 && book[the_position] <= 177) {
							the_position++;
						}
						
						s32 book_len = strlen(book);
						while ((book[the_position] < 168 || book[the_position] > 177) && the_position < book_len && strcmp(language.get("chapter"), substr(book, the_position, the_position + strlen(language.get("chapter")) - 1))) {
							the_position++;
						}
						
						highlighted_text[current_index + 1] = the_position - 1;
						
						current_index += 2;
					}
				}
			}
		}
	}
	
	delete [] bookmarks;
	bookmarks = 0;
	
	if (!book_found) {
		return 2;
	}
	
	return 0;
}

void format_line(char *line) {
	while (strpos(line, "\r") != -1) {
		remove_character(line, strpos(line, "\r"));
	}

	s16 pipe_pos;	
	while (1) {
		pipe_pos = strpos(line, "|");
		
		if (pipe_pos == -1) {
			break;
		}
		
		if (line[pipe_pos - 1] == ' ') {
			remove_character(line, pipe_pos - 1);
			pipe_pos--;
		}
		
		if (line[pipe_pos + 1] == ' ') {
			remove_character(line, pipe_pos + 1);
		}
		
		line[pipe_pos] = '\n';
		
		if (line[pipe_pos + 1] == '\0') {
			line[pipe_pos + 1] = '\n';
			line[pipe_pos + 2] = '\0';
		} else {
			add_character(line, pipe_pos + 1, '\n');
		}
	}
	
	s16 slash_pos;
	while (1) {
		slash_pos = strpos(line, "/");
		
		if (slash_pos == -1) {
			break;
		}
		
		if (line[slash_pos - 1] == ' ') {
			remove_character(line, slash_pos - 1);
			slash_pos--;
		}
		
		if (line[slash_pos + 1] == ' ') {
			remove_character(line, slash_pos + 1);
		}
		
		line[slash_pos] = '\n';
	}
}

