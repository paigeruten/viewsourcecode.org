#include <nds.h>
#include <fat.h>
#include <stdio.h>
#include "screenshotter.h"
#include "screen.h"
#include "font.h"
#include "keyboard.h"
#include "scroll.h"

extern char KEYBOARD_LAYOUT[];
extern char KEYBOARD_LAYOUT_SHIFT[];
extern char KEYBOARD_LAYOUT2[];
extern char KEYBOARD_LAYOUT2_SHIFT[];

extern u16 *screens[4];

void screenshotter() {
	char filename[256] = "";
	
	scanKeys();
	
	if ((keysHeld() & KEY_L) && (keysHeld() & KEY_R) && (keysHeld() & KEY_START) && (keysHeld() & KEY_SELECT)) {
		while (keysHeld()) { scanKeys(); }
		
		scrcpy(screens[BUFFER_TOP], screens[SCREEN_TOP]);
		scrcpy(screens[BUFFER_BOTTOM], screens[SCREEN_BOTTOM]);
		
		clear_screen(31, 31, 31, screens[SCREEN_TOP]);
		clear_screen(31, 31, 31, screens[SCREEN_BOTTOM]);
		
		draw_titlebar("Take screenshot", screens[SCREEN_TOP]);
		print_string("Type a filename.", 0, screens[SCREEN_TOP], screens[SCREEN_BOTTOM]);
		
		print_keyboard(KEYBOARD_LAYOUT, screens[SCREEN_BOTTOM]);
		
		if (keyboard_string(filename, screens[SCREEN_BOTTOM], "", KEYBOARD_LAYOUT, KEYBOARD_LAYOUT_SHIFT) == OK) {
			FILE *screenshot = fopen(filename, "wb");
			fwrite(screens[BUFFER_TOP], sizeof(u16), 256*192, screenshot);
			fwrite(screens[BUFFER_BOTTOM], sizeof(u16), 256*192, screenshot);
			fclose(screenshot);
		}
		
		scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
		scrcpy(screens[SCREEN_BOTTOM], screens[BUFFER_BOTTOM]);
	}
}

