#ifndef _load_h
#define _load_h

// Loads book into book[] array, adding superscripts and chapter titles along the way. Also records the position of each c and v. Returns 0 if successful, 1 if it couldn't open the file, or 2 if it couldn't find the book.
u8 load_book(char *book);

void format_line(char *line);

#endif
