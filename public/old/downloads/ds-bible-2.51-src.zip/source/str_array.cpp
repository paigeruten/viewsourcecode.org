#include <nds.h>
#include <string.h>
#include "str_array.h"
#include "str.h"

u16 count(const char *array) {
	return str_count(array, '/')+1;
}

void array_remove(char *array, char *element) {
	char temp_array[2048] = "";
	u8 num_of_elements, x;
	
	num_of_elements = count(array);
	
	for (x = 0; x < num_of_elements; x++) {
		if (strcmp(element, array_index(array, x))) {
			strcat(temp_array, array_index(array, x));
			strcat(temp_array, "/");
		}
	}
	
	if (strlen(temp_array) != 0) {
		temp_array[strlen(temp_array)-1] = '\0';
	}
	
	strcpy(array, temp_array);
}

char *array_index(const char *array, u8 index) {
	static char element[1024];
	s16 x = -1, i, j;
	
	for (j = 0; j < index; j++) {
		x = strpos(array, "/", x+1);
	}
	
	i = strpos(array, "/", x+1);
	
	if (i == -1) {
		strcpy(element, substr(array, x+1, strlen(array)-1));
	} else {
		strcpy(element, substr(array, x+1, i-1));
	}
	
	return element;
}

u8 get_array_index(const char *array, const char *element) {
	u8 i = 0;
	
	while (1) {
		if (!strcmp(element, array_index(array, i))) {
			return i;
		}
		
		i++;
	}
}

bool in_array(const char *needle, const char *haystack) {
	u8 haystack_count = count(haystack);

	for (u8 i = 0; i < haystack_count; i++) {
		if (!strcmp(array_index(haystack, i), needle)) {
			return true;
		}
	}
	
	return false;
}

