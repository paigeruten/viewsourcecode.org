u8 book_index(char *bookname);
char *book_long2short(char *bookname);
char *book_short2long(char *bookname);
u16 book_short2length(char *bookname);
