#ifndef _screen_h
#define _screen_h

enum { SCREEN_BOTTOM = 0, SCREEN_TOP = 1, BUFFER_BOTTOM = 2, BUFFER_TOP = 3 };

void init_screens(void);
void clear_screen(u8 r, u8 g, u8 b, u16 *screen);
void clear_screens(u16 *screen1, u16 *screen2, u16 colour);
void draw_box(u8 x, u8 y, u8 x2, u8 y2, u16 colour, u16 *screen, bool fill);
void darken_screen(u16 *screen);
void lighten_screen(u16 *screen);
void shift_right_packed(u16 *number, u8 start_bit, u8 end_bit);
void scrcpy(u16 *dest, const u16 *source);

#endif
