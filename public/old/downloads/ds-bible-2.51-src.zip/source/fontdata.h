#ifndef _fontdata_h
#define _fontdata_h

// The font's dimensions
#define FONT_WIDTH 19
#define FONT_HEIGHT 15

#endif
