#include <nds.h>
#include <string.h>
#include <stdlib.h>
#include "screen.h"
#include "font.h"
#include "image.h"
#include "button.h"

Button::Button(char *the_text, u16 *the_screen, u8 x_pos, u8 y_pos, Image *button_img, Image *button_pressed_img) {
	strcpy(text, the_text);
	screen = the_screen;
	button_image = button_img;
	button_pressed_image = button_pressed_img;
	x = x_pos;
	y = y_pos;
	width = button_image->get_width();
	height = button_image->get_height();
}

Button::~Button() {
}

bool Button::check(u8 stylus_x, u8 stylus_y) {
	if (stylus_x >= x && stylus_x <= x+width && stylus_y >= y && stylus_y <= y+height && keysHeld() & KEY_TOUCH) {
		if (!is_highlighted) {
			is_highlighted = true;
			draw();
		}

		return true;
	} else {
		if (is_highlighted) {
			is_highlighted = false;
			draw();
		}

		return false;
	}
}

void Button::toggle_check(u8 stylus_x, u8 stylus_y) {
	if (stylus_x >= x && stylus_x <= x+width && stylus_y >= y && stylus_y <= y+height && keysDown() & KEY_TOUCH) {
		is_highlighted = !is_highlighted;
		draw();
	}
}

void Button::draw() {
	// Is it highlighted or no?
	if (is_highlighted) {
		button_pressed_image->draw(x, y);
	} else {
		button_image->draw(x, y);
	}

	// Output the button text
	print_string_center(text, y + 8, screen, RGB15(0, 0, 0) | BIT(15));
}

void Button::set_text(char *new_text) {
	strcpy(text, new_text);
}

