#include <nds.h>
#include <fat.h>
#include <stdio.h>
#include <sys/dir.h>
#include <sys/unistd.h>
#include <string.h>
#include "screen.h"
#include "scroll.h"
#include "image.h"
#include "button.h"
#include "selectbox.h"
#include "str_array.h"
#include "str.h"
#include "font.h"
#include "assoc_array.h"
#include "screenshotter.h"

extern u16 *screens[4];
extern char *book;
extern u32 chapters[151];
extern u32 verses[151][200];
extern char translation[256];
extern char translations[1024];
extern char languages[1024];

extern char BOOK_SELECTION_LIST[1024];
extern char BOOK_AUTOTYPE_LIST[1024];
extern char BOOK_SHORT2LONG_LIST[1024];
extern char BOOK_LENGTHS[1024];

AssocArray language;
AssocArray preferences;

extern u32 highlighted_text[256];

void get_translations(char *return_translations) {
	DIR_ITER *dp;
	FILE *bible_file;
	char filename[256], path[256] = "/bible/translations", translation_name[256];
	
	strcpy(return_translations, "");

	// Get all the files in the directory into an array of strings
	dp = diropen(path);
	if (dp != NULL) {
		while (dirnext(dp, filename, NULL) == 0) {
			if (filename[0] != '.') {
				strcpy(path, "/bible/translations/");
				strcat(path, filename);
				
				bible_file = fopen(path, "r");
				fgets(translation_name, 255, bible_file);
				fclose(bible_file);
				
				if (translation_name[strlen(translation_name) - 1] == '\n') {
					translation_name[strlen(translation_name) - 1] = '\0';
				}
				
				strcat(return_translations, translation_name);
				strcat(return_translations, "/");
			}
		}
		dirclose(dp);
	}
	
	// Chop off the last slash
	if (return_translations[0]) {
		chop(return_translations);
	}
}

void get_languages(char *return_languages) {
	DIR_ITER *dp;
	FILE *lang_file;
	char filename[256], path[256] = "/bible/lang", language_name[256];
	
	strcpy(return_languages, "");

	// Get all the files in the directory into an array of strings
	dp = diropen(path);
	if (dp != NULL) {
		while (dirnext(dp, filename, NULL) == 0) {
			if (filename[0] != '.') {
				strcpy(path, "/bible/lang/");
				strcat(path, filename);
				
				lang_file = fopen(path, "r");
				fgets(language_name, 255, lang_file);
				fclose(lang_file);
				
				if (language_name[strlen(language_name) - 1] == '\n') {
					language_name[strlen(language_name) - 1] = '\0';
				}
				
				strcat(return_languages, language_name);
				strcat(return_languages, "/");
			}
		}
		dirclose(dp);
	}
	
	// Chop off the last slash
	if (return_languages[0]) {
		chop(return_languages);
	}
}

int main(void) {
	char msg[1024];

	touchPosition stylus;

	irqInit();
	irqEnable(IRQ_VBLANK);

	book = new char [307200];

	memset(highlighted_text, 0, 256);

	init_screens();
	
	clear_screen(31, 31, 31, screens[BUFFER_TOP]);
	clear_screen(31, 31, 31, screens[BUFFER_BOTTOM]);

	// Init FAT
	draw_titlebar("Please wait...", screens[BUFFER_TOP]);
	print_string("Initializing FAT...", 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);
	
	scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
	scrcpy(screens[SCREEN_BOTTOM], screens[BUFFER_BOTTOM]);
	
	if (!fatInitDefault()) {
		print_string("Initializing FAT...\nFailed!\n\nMake sure it's\nDLDI-patched correctly.", 0, screens[SCREEN_TOP], screens[SCREEN_BOTTOM]);
		while(1);
	}
	
	// Load images
	Image image_button(screens[SCREEN_BOTTOM], "/bible/images/button.img");
	Image image_button_pressed(screens[SCREEN_BOTTOM], "/bible/images/button_pressed.img");
	Image image_selectbox(screens[SCREEN_BOTTOM], "/bible/images/select.img");
	Image image_selectbox_pressed(screens[SCREEN_BOTTOM], "/bible/images/select_pressed.img");
	Image image_selector(screens[BUFFER_TOP], "/bible/images/select_box_selector.img");
	Image image_select_scroll(screens[BUFFER_TOP], "/bible/images/select_scroll.img");
	Image image_select_scroll_disabled(screens[BUFFER_TOP], "/bible/images/select_scroll_disabled.img");
	Image image_logo(screens[SCREEN_TOP], "/bible/images/logo.img");
	
	// Get list of translations and languages
	get_translations(translations);
	get_languages(languages);
	
	// Load their preferences
	if (preferences.load_from_file("/bible/preferences") == ASSOC_ARRAY_OK) {
		if (!in_array(preferences.get("translation"), translations)) {
			preferences.set("translation", array_index(translations, 0));
		}
		
		if (!in_array(preferences.get("language"), languages)) {
			preferences.set("language", array_index(languages, 0));
		}
		
		load_language();
	} else {
		// They don't have a preferences file so let them choose a language and write it to the file
		clear_screen(31, 31, 31, screens[BUFFER_TOP]);
		clear_screen(29, 29, 28, screens[BUFFER_BOTTOM]);
		
		preferences.append("language", array_index(languages, 0));
		load_language();

		draw_titlebar(language.get("preferences_titlebar"), screens[BUFFER_TOP]);
		strcpy(msg, language.get("preferences_text"));
		wordwrap_string(msg);
		print_string(msg, 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);
		
		Selectbox language_select(screens[SCREEN_BOTTOM], 5, 10, 246, 31, &image_selectbox, &image_selectbox_pressed, &image_selector, &image_select_scroll, &image_select_scroll_disabled, languages, array_index(languages, 0));
		Button button_save(language.get("button_save"), screens[SCREEN_BOTTOM], 5, 50, &image_button, &image_button_pressed);
		
		scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
		scrcpy(screens[SCREEN_BOTTOM], screens[BUFFER_BOTTOM]);
		
		language_select.draw_button();
		button_save.draw();
		
		while (1) {
			scanKeys();
			stylus = touchReadXY();
			
			if (language_select.update(stylus.px, stylus.py)) {
				preferences.set("language", language_select.get_selected_option());
				load_language();
				
				clear_screen(31, 31, 31, screens[BUFFER_TOP]);

				draw_titlebar(language.get("preferences_titlebar"), screens[BUFFER_TOP]);
				strcpy(msg, language.get("preferences_text"));
				wordwrap_string(msg);
				print_string(msg, 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);
				
				button_save.set_text(language.get("button_save"));
				
				scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
				
				language_select.draw_button();
				button_save.draw();
			}
			
			if (button_save.check(stylus.px, stylus.py)) {
				while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
				button_save.check(stylus.px, stylus.py);
				break;
			}
		}
		
		// If they chose French and have the French Bible, make it the default translation
		if (in_array("Louis Second 1910 French", translations) && strcmp(preferences.get("language"), "English")) {
			preferences.append("translation", "Louis Second 1910 French");
		// Otherwise use the World English Bible if they have it
		} else if (in_array("World English Bible", translations)) {
			preferences.append("translation", "World English Bible");
		// And if they don't have the WEB, use the first translation in the array
		} else {
			preferences.append("translation", array_index(translations, 0));
		}
		
		preferences.write_to_file("/bible/preferences", "Preferences");
	}
	
	Button button_bookselect(language.get("button_select"), screens[SCREEN_BOTTOM], 5, 50, &image_button, &image_button_pressed);
	Button button_lookup(language.get("button_lookup"), screens[SCREEN_BOTTOM], 5, 85, &image_button, &image_button_pressed);
	Button button_search(language.get("button_search"), screens[SCREEN_BOTTOM], 5, 120, &image_button, &image_button_pressed);
	Button button_bookmarks(language.get("button_bookmarks"), screens[SCREEN_BOTTOM], 5, 155, &image_button, &image_button_pressed);

	// Make a selectbox
	Selectbox selectbox(screens[SCREEN_BOTTOM], 5, 10, 246, 31, &image_selectbox, &image_selectbox_pressed, &image_selector, &image_select_scroll, &image_select_scroll_disabled, translations, preferences.get("translation"));
		
	// Splash screen
	Image splash(screens[SCREEN_BOTTOM], "/bible/images/neoflash.img");
	splash.draw(0, 0);
	
	// Load the translation while the splash screen is still onscreen
	translation2filename(false);
	
	image_logo.draw(0, 0);
	clear_screen(29, 29, 28, screens[SCREEN_BOTTOM]);
	
	selectbox.draw_button();
	button_bookselect.draw();
	button_lookup.draw();
	button_search.draw();
	button_bookmarks.draw();
	
	while (1) {
		scanKeys();
		stylus = touchReadXY();
		
		screenshotter();
		
		if (selectbox.update(stylus.px, stylus.py)) {
			preferences.set("translation", selectbox.get_selected_option());
			selectbox.draw_button();
			scrcpy(screens[BUFFER_BOTTOM], screens[SCREEN_BOTTOM]);
		}
		
		if (button_bookselect.check(stylus.px, stylus.py)) {
			while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
			button_bookselect.check(stylus.px, stylus.py);
		
			bible(screens[SCREEN_TOP], screens[SCREEN_BOTTOM], ACTION_SELECTBOOK, selectbox.get_selected_option());
			
			clear_screen(29, 29, 28, screens[SCREEN_BOTTOM]);
			image_logo.draw(0, 0);
			selectbox.draw_button();
			button_bookselect.draw();
			button_lookup.draw();
			button_search.draw();
			button_bookmarks.draw();
			scanKeys();
			while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
		}
		
		if (button_lookup.check(stylus.px, stylus.py)) {
			while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
			button_lookup.check(stylus.px, stylus.py);

			bible(screens[SCREEN_TOP], screens[SCREEN_BOTTOM], ACTION_LOOKUP, selectbox.get_selected_option());
			
			clear_screen(29, 29, 28, screens[SCREEN_BOTTOM]);
			image_logo.draw(0, 0);
			selectbox.draw_button();
			button_bookselect.draw();
			button_lookup.draw();
			button_search.draw();
			button_bookmarks.draw();
			scanKeys();
			while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
		}
		
		if (button_bookmarks.check(stylus.px, stylus.py)) {
			while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
			button_bookmarks.check(stylus.px, stylus.py);

			bible(screens[SCREEN_TOP], screens[SCREEN_BOTTOM], ACTION_BOOKMARKS, selectbox.get_selected_option());
			
			clear_screen(29, 29, 28, screens[SCREEN_BOTTOM]);
			image_logo.draw(0, 0);
			selectbox.draw_button();
			button_bookselect.draw();
			button_lookup.draw();
			button_search.draw();
			button_bookmarks.draw();
			scanKeys();
			while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
		}
		
		if (button_search.check(stylus.px, stylus.py)) {
			while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
			button_search.check(stylus.px, stylus.py);

			bible(screens[SCREEN_TOP], screens[SCREEN_BOTTOM], ACTION_SEARCH, selectbox.get_selected_option());
			
			clear_screen(29, 29, 28, screens[SCREEN_BOTTOM]);
			image_logo.draw(0, 0);
			selectbox.draw_button();
			button_bookselect.draw();
			button_lookup.draw();
			button_search.draw();
			button_bookmarks.draw();
			scanKeys();
			while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
		}
		
		swiWaitForVBlank();
	}
	
	return 0;
}

