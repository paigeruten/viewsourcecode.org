#include <nds.h>
#include <fat.h>
#include <stdio.h>
#include <string.h>
#include "assoc_array.h"
#include "str.h"

AssocArray::AssocArray() {
	num_elements = 0;
	
	for (u8 i = 0; i < 128; i++) {
		keys[i] = NULL;
		values[i] = NULL;
	}
}

AssocArray::~AssocArray() {
	for (u8 i = 0; i < num_elements; i++) {
		delete [] keys[i];
		delete [] values[i];
	}
}

char *AssocArray::get(const char *key) {
	s16 index = index_of_key(key);
	
	if (index == -1) {
		return NULL;
	}
	
	return values[index];
}

void AssocArray::set(const char *key, const char *value) {
	s16 index = index_of_key(key);
	
	if (index == -1) {
		append(key, value);
	} else {
		delete [] values[index];
		values[index] = new char [strlen(value) + 1];
		strcpy(values[index], value);
	}
}

void AssocArray::append(const char *key, const char *value) {
	if (index_of_key(key) == -1) {
		u16 key_length = strlen(key);	
		keys[num_elements] = new char [key_length + 1];
		strcpy(keys[num_elements], key);
		
		u16 value_length = strlen(value);
		values[num_elements] = new char [value_length + 1];
		strcpy(values[num_elements], value);
		
		num_elements++;
	}
}

void AssocArray::remove(const char *key) {
	s16 index = index_of_key(key);
	
	if (index != -1) {	
		delete [] keys[index];
		delete [] values[index];
		
		for (u8 i = index; i < num_elements - 1; i++) {
			keys[i] = keys[i + 1];
			values[i] = values[i + 1];
		}
		
		num_elements--;
	}
}

void AssocArray::clear() {
	for (u8 i = 0; i < num_elements; i++) {
		delete [] keys[i];
		delete [] values[i];
	}
	
	num_elements = 0;
}

char *AssocArray::iterate_keys() {
	static u8 i = 0;
	
	if (i >= num_elements) {
		i = 0;
		return NULL;
	}
	
	i++;
	
	return keys[i - 1];
}

AssocArrayStatus AssocArray::load_from_file(const char *filename) {
	FILE *file = fopen(filename, "r");
	s16 equals_pos;
	
	if (!file) {
		return ASSOC_ARRAY_CANT_OPEN_FILE;
	}
	
	char *line = new char [4096];
	char key[256];
	char value[1024];
	
	clear();
	
	// Skip first line
	fgets(line, 4095, file);
	
	while (!feof(file)) {
		fgets(line, 4095, file);
		
		// Chop of the newline at the end
		if (line[strlen(line) - 1] == '\n') {
			line[strlen(line) - 1] = '\0';
		}
		
		equals_pos = strpos(line, "=", 1);
		
		if (equals_pos != -1) {
			strcpy(key, substr(line, 0, equals_pos - 1));
			strcpy(value, substr(line, equals_pos + 1, strlen(line) - 1));
			
			change_escaped_newlines_to_newlines(value);
			
			append(key, value);
		}
	}
	
	fclose(file);
	
	delete [] line;
	
	return ASSOC_ARRAY_OK;
}

AssocArrayStatus AssocArray::write_to_file(const char *filename, const char *title) {
	FILE *file = fopen(filename, "w");
	
	if (!file) {
		return ASSOC_ARRAY_CANT_OPEN_FILE;
	}
	
	char *key;
	
	fwrite(title, sizeof(char), strlen(title), file);
	fputc('\n', file);
	fputc('\n', file);
	
	while ((key = iterate_keys())) {
		fwrite(key, sizeof(char), strlen(key), file);
		fputc('=', file);
		fwrite(get(key), sizeof(char), strlen(get(key)), file);
		fputc('\n', file);
	}
	
	fclose(file);
	
	return ASSOC_ARRAY_OK;
}

s16 AssocArray::index_of_key(const char *key) const {
	for (u8 i = 0; i < num_elements; i++) {
		if (!strcmp(key, keys[i])) {
			return i;
		}
	}
	
	return -1;
}

void AssocArray::change_escaped_newlines_to_newlines(char *string) {
	u32 current_char = 0;
	
	while (string[current_char]) {
		if (string[current_char] == '\\' && string[current_char + 1] == 'n') {
			string[current_char] = '\n';
			
			for (u32 current_char2 = current_char + 1; string[current_char2]; current_char2++) {
				string[current_char2] = string[current_char2 + 1];
			}
		}
		
		current_char++;
	}
}


