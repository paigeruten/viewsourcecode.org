#include <nds.h>
#include <fat.h>
#include <stdio.h>
#include <sys/dir.h>
#include <sys/unistd.h>
#include <string.h>
#include "scroll.h"
#include "screen.h"
#include "font.h"
#include "fontdata.h"
#include "str.h"
#include "browse.h"
#include "buttons.h"
#include "keyboard.h"
#include "books.h"
#include "load.h"
#include "progressbar.h"
#include "str_array.h"
#include "screenshotter.h"
#include "image.h"
#include "assoc_array.h"
#include "button.h"
#include "selectbox.h"

extern u16 *screens[4];
extern u8 font_widths[256];
extern char *book;
extern char bookname_long[32];
extern char bookname_short[4];

extern AssocArray language;
extern AssocArray preferences;

char current_location[30] = "";
char translation[256];
char translations[1024];
char languages[1024];

char BOOK_SELECTION_LIST[1024];
char BOOK_AUTOTYPE_LIST[1024];
char BOOK_SHORT2LONG_LIST[1024];
char BOOK_LENGTHS[1024];

u32 book_positions[100];

u32 highlighted_text[256];
u32 highlighted_search_results[2048];

u8 num_chapters_in_book[128];
u8 num_verses_in_chapter[128][256];

extern char KEYBOARD_LAYOUT[];
extern char KEYBOARD_LAYOUT_SHIFT[];
extern char KEYBOARD_LAYOUT2[];
extern char KEYBOARD_LAYOUT2_SHIFT[];

void highlight_search_results(char *search_terms) {
	memset(highlighted_search_results, 0, 2048);
	
	s32 current_index;
	u16 current_highlight_index = 0;
	for (u8 i = 0; i < count(search_terms); i++) {
		char *term = array_index(search_terms, i);
		
		current_index = 0;
		while (current_index != -1) {
			current_index = stripos(book, term, current_index + 1);
			
			if (current_index != -1) {
				highlighted_search_results[current_highlight_index] = current_index;
				highlighted_search_results[current_highlight_index + 1] = current_index + strlen(term) - 1;
				
				current_highlight_index += 2;
				
				if (current_highlight_index == 2046) {
					return;
				}
			}
		}
	}
}

void translation2filename(bool edit_bottom_screen) {
	DIR_ITER *dp;
	FILE *bible_file;
	char filename[256], path[256] = "/bible/translations", translation_name[256], line[1024], current_short_book_name[4], last_short_book_name[4] = "";
	u16 book_lengths[100];
	u8 percent_done, last_percent_done;
	u8 chapter_num, verse_num;
	s8 colon_pos, first_space_pos, second_space_pos;
	
	static char current_translation[64] = "";
	
	if (!strcmp(current_translation, preferences.get("translation"))) {
		return;
	}
	
	strcpy(current_translation, preferences.get("translation"));
	
	clear_screen(31, 31, 31, screens[BUFFER_TOP]);
	
	draw_titlebar(language.get("startup_titlebar"), screens[BUFFER_TOP]);
	print_string(language.get("startup_text"), 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);

	draw_progressbar_box(screens[BUFFER_TOP]);
	
	scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
	
	if (edit_bottom_screen) {
		scrcpy(screens[SCREEN_BOTTOM], screens[BUFFER_BOTTOM]);
	}
	
	percent_done = 0;
	last_percent_done = 0;

	// Get all the files in the directory
	dp = diropen(path);
	if (dp != NULL) {
		while (dirnext(dp, filename, NULL) == 0) {
			if (filename[0] != '.') {
				strcpy(path, "/bible/translations/");
				strcat(path, filename);
				
				bible_file = fopen(path, "r");
				fgets(translation_name, 255, bible_file);
				
				if (translation_name[strlen(translation_name) - 1] == '\n') {
					translation_name[strlen(translation_name) - 1] = '\0';
				}
				
				if (!strcmp(translation_name, preferences.get("translation"))) {
					fgets(BOOK_SHORT2LONG_LIST, 1023, bible_file);
					fclose(bible_file);
					
					strcpy(translation, path);
										
					strcpy(BOOK_SELECTION_LIST, "");
					for (u8 i = 1; i < count(BOOK_SHORT2LONG_LIST) - 1; i += 2) {
						strcat(BOOK_SELECTION_LIST, array_index(BOOK_SHORT2LONG_LIST, i));
						strcat(BOOK_SELECTION_LIST, "/");
					}
					chop(BOOK_SELECTION_LIST);
					
					strcpy(BOOK_AUTOTYPE_LIST, "/");
					strcat(BOOK_AUTOTYPE_LIST, BOOK_SELECTION_LIST);
					strcat(BOOK_AUTOTYPE_LIST, "/");
					
					bible_file = fopen(translation, "r");
					fgets(line, 1023, bible_file);
					fgets(line, 1023, bible_file);
					book_positions[0] = ftell(bible_file);
					u32 i = 2;
					u8 book_num = 0;
					bool first = true;
					while (!feof(bible_file)) {
						fgets(line, 1023, bible_file);
						
						colon_pos = strpos(line, ":");
						first_space_pos = strrpos(line, " ", colon_pos);
						second_space_pos = strpos(line, " ", colon_pos);
						
						chapter_num = intval(substr(line, first_space_pos + 1, colon_pos - 1));
						verse_num = intval(substr(line, colon_pos + 1, second_space_pos - 1));
						
						strncpy(current_short_book_name, line, 3);
						current_short_book_name[3] = '\0';
						
						if (strcmp(current_short_book_name, last_short_book_name) && !first) {
							book_positions[book_num + 1] = ftell(bible_file) - 1024;
							book_lengths[book_num] = i;
							book_num++;
						} else {
							first = false;
						}
						
						num_chapters_in_book[book_num] = chapter_num;
						num_verses_in_chapter[book_num][chapter_num] = verse_num;
						
						i++;
						
						percent_done = (float)i/(float)31103 * 100;
						if (percent_done != last_percent_done) {
							last_percent_done = percent_done;

							swiWaitForVBlank();
							draw_box(27, 60, 250, 78, 0xFFFF, screens[SCREEN_TOP], true);
							print_string_xy(book_short2long(current_short_book_name), 27, 60, screens[SCREEN_TOP], RGB15(7, 7, 7) | BIT(15));
							update_progressbar(screens[1], percent_done);
						}
						
						strcpy(last_short_book_name, current_short_book_name);
					}
										
					book_lengths[book_num] = i;
					fclose(bible_file);
					
					strcpy(BOOK_LENGTHS, "/");
					for (i = 0; i < count(BOOK_SELECTION_LIST); i++) {
						strcat(BOOK_LENGTHS, book_long2short(array_index(BOOK_SELECTION_LIST, i)));
						strcat(BOOK_LENGTHS, "/");
						strcat(BOOK_LENGTHS, strval(book_lengths[i]));
						strcat(BOOK_LENGTHS, "/");
					}
					
					return;
				}
				
				fclose(bible_file);
			}
		}
		dirclose(dp);
	}
}

void load_language() {
	DIR_ITER *dp;
	FILE *lang_file;
	char filename[256], path[256] = "/bible/lang", language_name[256];

	// Get all the files in the directory into an array of strings
	dp = diropen(path);
	if (dp != NULL) {
		while (dirnext(dp, filename, NULL) == 0) {
			if (filename[0] != '.') {
				strcpy(path, "/bible/lang/");
				strcat(path, filename);
				
				lang_file = fopen(path, "r");
				fgets(language_name, 255, lang_file);
				fclose(lang_file);
				
				if (language_name[strlen(language_name) - 1] == '\n') {
					language_name[strlen(language_name) - 1] = '\0';
				}
				
				if (!strcmp(language_name, preferences.get("language"))) {
					language.load_from_file(path);
					break;
				}
			}
		}
		dirclose(dp);
	}
	
	// Add a space to the chapter string
	char chapter_text[20];
	strcpy(chapter_text, language.get("chapter"));
	strcat(chapter_text, " ");
	language.set("chapter", chapter_text);
}

u16 background_color(u32 index, bool highlight_stuff) {
	u16 current_index = 0;
	
	if (highlight_stuff) {	
		while (highlighted_search_results[current_index]) {
			if (index >= highlighted_search_results[current_index] && index <= highlighted_search_results[current_index + 1]) {
				return RGB15(31, 24, 17) | BIT(15);
			}
		
			current_index += 2;
		}
		
		current_index = 0;
		while (highlighted_text[current_index]) {
			if (index >= highlighted_text[current_index] && index <= highlighted_text[current_index + 1]) {
				return RGB15(31, 31, 21) | BIT(15);
			}
		
			current_index += 2;
		}
	}
	
	return RGB15(31, 31, 31) | BIT(15);
}

u32 print_string(char *string, u32 offset, u16 *screentop, u16 *screenbottom, bool highlight_stuff, u16 color, u16 bgcolor, u16 highlight_color) {
	u8 page_done;
	u16 put_x, put_y, x, y;
	u32 current_char, next_page_pos = offset;
	bool highlighting = false, superscript_highlight;
	
	// Look for the start of a footnote
	for (current_char = offset - 1; current_char > 0; current_char--) {
		if (string[current_char] == '{') {
			highlighting = true;
			break;
		} else if (string[current_char] == '}') {
			break;
		} else if (string[current_char] >= 168 && string[current_char] < 178) {
			break;
		}
	}
	
	// Top screen
	page_done = 0;
	put_x = MARGIN_SIDES;
	put_y = MARGIN_MAIN_TOP;
	current_char = offset;
	while (string[current_char] != '\0' && !page_done) {
		if (string[current_char] == '{') {
			highlighting = true;
		}
		
		superscript_highlight = (string[current_char] >= 168 && string[current_char] <= 177);
	
		if (string[current_char] == '\n') {
			u8 right_limit = SCREEN_WIDTH - MARGIN_SIDES;
			u8 bottom_limit = put_y + FONT_HEIGHT;
		
			// Fill in spots that aren't written to with white
			for (x = put_x; x <= right_limit; x++) {
				for (y = put_y; y <= bottom_limit; y++) {
					screentop[x + y * SCREEN_WIDTH] = RGB15(31, 31, 31) | BIT(15);
				}
			}
			
			for (x = MARGIN_SIDES; x <= right_limit; x++) {
				for (y = bottom_limit + 1; y <= bottom_limit + 1 + SPACE_BETWEEN_LINES; y++) {
					screentop[x + y * SCREEN_WIDTH] = RGB15(31, 31, 31) | BIT(15);
				}
			}
		
			put_y += FONT_HEIGHT + SPACE_BETWEEN_LINES;
			put_x = MARGIN_SIDES;
		} else {
			if (highlighting || superscript_highlight) {
				print_char(string[current_char], put_x, put_y, screentop, highlight_color, background_color(current_char, highlight_stuff));			
			} else {
				print_char(string[current_char], put_x, put_y, screentop, color, background_color(current_char, highlight_stuff));
			}
			
			put_x += SPACE_BETWEEN_CHARS + font_widths[(int)string[current_char]];
		}
		
		if (string[current_char] == '}') {
			highlighting = false;
		}

		if (put_y > 192 - MARGIN_MAIN_BOTTOM - FONT_HEIGHT) {
			page_done = 1;
			next_page_pos = current_char+1; // Where it will continue printing from on the bottom screen
		}
		
		current_char++;
	}

	// Bottom screen (make sure we're not at the end of the string, first)
	if (string[current_char] != '\0') {
		page_done = 0;
		put_x = MARGIN_SIDES;
		put_y = MARGIN_SUB_TOP;
		current_char = next_page_pos;
		while (string[current_char] != '\0' && !page_done) {
			if (string[current_char] == '{') {
				highlighting = true;
			}
			
			superscript_highlight = (string[current_char] >= 168 && string[current_char] <= 177);
		
			if (string[current_char] == '\n') {
				u8 right_limit = SCREEN_WIDTH - MARGIN_SIDES;
				u8 bottom_limit = put_y + FONT_HEIGHT;
			
				// Fill in spots that aren't written to with white
				for (x = put_x; x <= right_limit; x++) {
					for (y = put_y; y <= bottom_limit; y++) {
						screenbottom[x + y * SCREEN_WIDTH] = RGB15(31, 31, 31) | BIT(15);
					}
				}
				
				for (x = MARGIN_SIDES; x <= right_limit; x++) {
					for (y = bottom_limit + 1; y <= bottom_limit + 1 + SPACE_BETWEEN_LINES; y++) {
						screenbottom[x + y * SCREEN_WIDTH] = RGB15(31, 31, 31) | BIT(15);
					}
				}
			
				put_y += FONT_HEIGHT + SPACE_BETWEEN_LINES;
				put_x = MARGIN_SIDES;
			} else {
				if (highlighting || superscript_highlight) {
					print_char(string[current_char], put_x, put_y, screenbottom, highlight_color, background_color(current_char, highlight_stuff));			
				} else {
					print_char(string[current_char], put_x, put_y, screenbottom, color, background_color(current_char, highlight_stuff));
				}
				
				put_x += SPACE_BETWEEN_CHARS + font_widths[(int)string[current_char]];
			}
			
			if (string[current_char] == '}') {
				highlighting = false;
			}
			
			if (put_y > 192 - MARGIN_SUB_BOTTOM - FONT_HEIGHT) {
				page_done = 1;
			}
			
			current_char++;
		}
	}
	
	return current_char;
}

void wordwrap_string(char *string) {
	u32 current_char = 0, last_space_pos = 0;
	u16 width = MARGIN_SIDES;
	
	// Goes through each char keeping track of the width it would be when actually printing out the string, and replaces
	// spaces with newlines where text would go past the right margin.
	while (string[current_char] != '\0') {
		width += font_widths[(int)string[current_char]] + SPACE_BETWEEN_CHARS;
		
		if (string[current_char] == '\n') {
			width = MARGIN_SIDES;
		}
		
		if (string[current_char] == ' ') {
			last_space_pos = current_char; // Used when changing the space into a newline
		}
		
		if (width > 256 - MARGIN_SIDES) {
			if (last_space_pos) {
				string[last_space_pos] = '\n';
				current_char = last_space_pos;
			} else {
				for (u32 i = strlen(string); i >= current_char; i--) {
					string[i] = string[i - 1];
				}

				string[current_char - 1] = '\n';
			}

			width = MARGIN_SIDES;
			last_space_pos = 0;
		}
		
		current_char++;
	}
}

void remove_character(char *string, u32 char_index) {
	u32 current_char = char_index;
	
	while (1) {
		string[current_char] = string[current_char + 1];
		if (string[current_char] == '\0') { break; }
		current_char++;
	}
}

void add_character(char *string, u32 char_index, char ch) {
	u32 current_char;
	
	for (current_char = strlen(string); current_char > char_index; current_char--) {
		string[current_char] = string[current_char - 1];
	}
	
	string[char_index] = ch;
}

void draw_gui(s32 position, u8 scroll_pos, u16 scrollbar_colour) {
	u8 i;

	clear_screen(31, 31, 31, screens[BUFFER_TOP]);
	clear_screen(31, 31, 31, screens[BUFFER_BOTTOM]);
	
	print_string(book, position, screens[BUFFER_TOP], screens[BUFFER_BOTTOM], true);
	update_titlebar(position, screens[BUFFER_TOP]);
	draw_scrollbar(scroll_pos, screens[BUFFER_BOTTOM], scrollbar_colour);
	
	print_buttons(screens[BUFFER_BOTTOM]);
	
	// Draw scrollbar box
	for (i = 242; i <= 254; i++) {
		screens[BUFFER_BOTTOM][i + 1 * SCREEN_WIDTH] = RGB15(15, 15, 15) | BIT(15);
		screens[BUFFER_BOTTOM][i + 190 * SCREEN_WIDTH] = RGB15(15, 15, 15) | BIT(15);
	}
	for (i = 1; i <= 190; i++) {
		screens[BUFFER_BOTTOM][242 + i * SCREEN_WIDTH] = RGB15(15, 15, 15) | BIT(15);
		screens[BUFFER_BOTTOM][254 + i * SCREEN_WIDTH] = RGB15(15, 15, 15) | BIT(15);
	}
	
	scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
	scrcpy(screens[SCREEN_BOTTOM], screens[BUFFER_BOTTOM]);
}

void bible(u16 *screentop, u16 *screenbottom, u8 action, char *the_translation) {
	s32 position = 0;
	u32 last_pos, line_position = 0, num_of_lines, current_char;
	touchPosition stylus;
	u8 scroll_pos = 0, last_scroll_pos = 0, i, done, valid;
	s8 button, percent_done, last_percent_done;
	char *bookname;
	u16 space_pos, colon_pos, num_results = 0, line_num;
	FILE *txt_file;
	char the_book[4], the_chapter[4], the_verse[4], search_terms[256];
	bool from_main_menu = true;
	KeyboardStatus status;
	
	// I think these strings were too much for the stack so I'll use the heap
	char *msg = new char [1024];
	char *input = new char [1024];
	char *input2 = new char [1024];
	char *str = new char [256];
	char *search_results = new char [4096];
	char *line = new char [1024];
	char *jumpto = new char [128];
	char *bookmarks = new char [4096];
	
	Image img_scroll_icon(screenbottom, "/bible/images/scroll_icon.img");
	
	preferences.write_to_file("/bible/preferences", "Preferences");
	translation2filename(true);

	// I know, this is very bad... but it works!
	switch (action) {
		case ACTION_SELECTBOOK:
			goto bookselection;
			break;
		case ACTION_LOOKUP:
			strcpy(input, "");
			goto lookup;
			break;
		case ACTION_SEARCH:
			strcpy(input, "");
			goto search;
			break;
		case ACTION_BOOKMARKS:
			goto bookmarks;
			break;
		default:
			while(1);
	}
	
	while (1) {
		screenshotter();
	
		if (keysHeld() & KEY_UP) {
			position = strrpos(book, "\n", position-2)+1;
			if (position < 0) { position = 0; }
			
			line_position = pos2linenumber(position);
			scroll_pos = 155*line_position / (num_of_lines-20);
			
			swiWaitForVBlank();
			draw_gui(position, scroll_pos);
				
			for (i = 0; i < 10; i++) { swiWaitForVBlank(); }
		}
		
		if (keysHeld() & KEY_DOWN) {
			if (strpos(book, "\n", position) != -1) {
				position = strpos(book, "\n", position)+1;
			}
			
			line_position = pos2linenumber(position);
			if (line_position > num_of_lines - 20) {
				line_position = num_of_lines - 20;
				position = linenumber2pos(line_position);
			}
			scroll_pos = 155*line_position / (num_of_lines-20);

			swiWaitForVBlank();
			draw_gui(position, scroll_pos);
				
			for (i = 0; i < 10; i++) { swiWaitForVBlank(); }
		}
		
		if (keysHeld() & KEY_LEFT) {
			for (i = 0; i < 20; i++) {
				position = strrpos(book, "\n", position-2)+1;
			}
			if (position < 0) { position = 0; }
			
			line_position = pos2linenumber(position);
			scroll_pos = 155*line_position / (num_of_lines-20);
			
			swiWaitForVBlank();
			draw_gui(position, scroll_pos);
				
			for (i = 0; i < 10; i++) { swiWaitForVBlank(); }
		}
		
		if (keysHeld() & KEY_RIGHT) {
			for (i = 0; i < 20; i++) {
				if (strpos(book, "\n", position) != -1) {
					position = strpos(book, "\n", position)+1;
				}
			}

			line_position = pos2linenumber(position);
			if (line_position > num_of_lines - 20) {
				line_position = num_of_lines - 20;
				position = linenumber2pos(line_position);
			}
			scroll_pos = 155*line_position / (num_of_lines-20);

			swiWaitForVBlank();
			draw_gui(position, scroll_pos);
				
			for (i = 0; i < 10; i++) { swiWaitForVBlank(); }
		}

		
		if (keysHeld() & KEY_X && num_results > 0) {
			while (keysHeld() & KEY_X) { scanKeys(); swiWaitForVBlank(); }
			
			clear_screen(31, 31, 31, screens[BUFFER_TOP]);
			
			draw_titlebar(language.get("search_titlebar"), screens[BUFFER_TOP]);
			strcpy(msg, strval(num_results));
			strcat(msg, " ");
			strcat(msg, language.get("search_results_found"));
			
			if (num_results > 250) {
				strcat(msg, " ");
				strcat(msg, language.get("search_first250shown"));
			}
			
			strcat(msg, "\n\n");
			strcat(msg, language.get("search_instructions"));
			wordwrap_string(msg);
			print_string(msg, 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);
			
			scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
			
			strcpy(jumpto, select(search_results, screenbottom));
			
			if (strcmp(jumpto, language.get("cancel"))) {				
				colon_pos = strpos(jumpto, ":");
				space_pos = strrpos(jumpto, " ", colon_pos);
				
				load_book(book_long2short(substr(jumpto, 0, space_pos-1)));
				wordwrap_string(book);
				
				highlight_search_results(search_terms);
					
				strcpy(str, language.get("chapter"));
				strcat(str, substr(jumpto, space_pos+1, colon_pos-1));
				position = strpos(book, str);
				
				if (position != -1) {
					strcpy(str, substr(jumpto, colon_pos+1, strlen(jumpto)-1));
					current_char = 0;
					while (str[current_char] != '\0') {
						str[current_char] += 120;
						current_char++;
					}
					position = strpos(book, str, position);
					if (position != -1) {
						position = strrpos(book, "\n", position)+1;
					}
				}
				
				if (position == -1) { position = 0; }
				
				num_of_lines = str_count(book, '\n')+1;
				scroll_pos = 155*pos2linenumber(position) / (num_of_lines-20);
			}
			
			draw_gui(position, scroll_pos);
		}

no_button:
		
		if (keysHeld() & KEY_TOUCH) {
			button = button_pressed(stylus.px, stylus.py);
			from_main_menu = false;
			
			if (button != -1) {
				print_button(button, ((BUTTON_WIDTH+3)*button)+(127-((NUM_OF_BUTTONS*(BUTTON_WIDTH+3))/2)), SCREEN_HEIGHT - BUTTON_HEIGHT-3, ON, screenbottom);
				
				u16 vblank_count = 0;
				while (keysHeld() & KEY_TOUCH) {
					scanKeys();
					swiWaitForVBlank();
					
					if (vblank_count > 30) {
						scrcpy(screens[BUFFER_TOP], screens[SCREEN_TOP]);
						scrcpy(screens[BUFFER_BOTTOM], screens[SCREEN_BOTTOM]);
						
						darken_screen(screentop);
						darken_screen(screenbottom);
						
						switch (button) {
							case 0:
								strcpy(msg, language.get("help_button_left_arrow"));
								break;
							case 1:
								strcpy(msg, language.get("help_button_right_arrow"));
								break;
							case 2:
								strcpy(msg, language.get("help_button_book"));
								break;
							case 3:
								strcpy(msg, language.get("help_button_binoculars"));
								break;
							case 4:
								strcpy(msg, language.get("help_button_list"));
								break;
							case 5:
								strcpy(msg, language.get("help_button_star"));
								break;
							case 6:
								strcpy(msg, language.get("help_button_translations"));
								break;
							case 7:
								strcpy(msg, language.get("help_button_wrench"));
								break;
							default:
								strcpy(msg, "");
								break;
						}
						
						draw_alert_box(msg, screenbottom);
						
						while (keysHeld() & KEY_TOUCH) {
							scanKeys();
							swiWaitForVBlank();
						}
						
						scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
						scrcpy(screens[SCREEN_BOTTOM], screens[BUFFER_BOTTOM]);
						print_buttons(screenbottom);
						
						goto no_button;
					}
					
					vblank_count++;
				}
			}
			
			if (button == -1) {
				// Not touching any button
				
				// Scrollbar
				if (stylus.px >= 244 && stylus.px <= 252 && stylus.py >= scroll_pos+3 && stylus.py <= scroll_pos+3+30) {
					last_scroll_pos = 0;
					
					while (keysHeld() & KEY_TOUCH) {
						scanKeys();
						stylus = touchReadXY();
						
						if (keysHeld() & KEY_TOUCH) {
							scroll_pos = stylus.py-18;
						}
						
						if (keysHeld() & KEY_TOUCH && stylus.py <= 17) { scroll_pos = 0; }
						if (keysHeld() & KEY_TOUCH && stylus.py > 172) { scroll_pos = 155; }
						
						last_pos = line_position;
						line_position = (num_of_lines-20)*scroll_pos/155;
						position = linenumber2pos(line_position);
						
						if (line_position != last_pos) {
							draw_gui(position, scroll_pos, RGB15(31, 15, 0) | BIT(15));
						} else if (last_scroll_pos != scroll_pos) {
							draw_scrollbar(scroll_pos, screenbottom, RGB15(31, 15, 0) | BIT(15));
						}
						
						last_scroll_pos = scroll_pos;
						
						swiWaitForVBlank();
					}
					draw_scrollbar(scroll_pos, screenbottom, RGB15(0, 0, 0) | BIT(15));
				}
				
				// Scroll by dragging stylus on text
				if (stylus.px < 234 && stylus.py < 170 && stylus.px > 10 && stylus.py > 10) {
					s16 stylus_start = stylus.py;
					u8 icon_x = stylus.px - 3, icon_y = stylus.py - 10;
					
					img_scroll_icon.draw(icon_x, icon_y);
					
					line_position = pos2linenumber(position);
					u32 last_line_position = line_position;
					
					scanKeys();
					stylus = touchReadXY();
					while (keysHeld() & KEY_TOUCH) {						
						if (stylus_start - stylus.py >= 8 || stylus_start - stylus.py <= -8) {
							line_position += (stylus_start - stylus.py) / 8;
								
							// Makes sure it doesn't go below 0.
							if (line_position > (u16)0xFFF0) {
								line_position = 0;
							}
								
							if (line_position > num_of_lines - 20) {
								line_position = num_of_lines - 20;
							}
							
							position = linenumber2pos(line_position);
							scroll_pos = 155*pos2linenumber(position) / (num_of_lines-20);
							
							swiWaitForVBlank();
							if (line_position != last_line_position) {
								draw_gui(position, scroll_pos);
								img_scroll_icon.draw(icon_x, icon_y);
							}
							
							last_line_position = line_position;
							last_scroll_pos = scroll_pos;
							stylus_start = stylus.py;
						}
						
						scanKeys();
						stylus = touchReadXY();
					}
					
					img_scroll_icon.erase(icon_x, icon_y, RGB15(31, 31, 31) | BIT(15));
					print_string(book, position, screentop, screenbottom, true);
				}
			} else if (button == 0) {
				// Previous c
				if (position != 0) {
					position = strrpos(book, language.get("chapter"), position-1);
				}
				if (position == -1) { position++; }
				
				line_position = pos2linenumber(position);
				if (line_position > num_of_lines - 20) {
					line_position = num_of_lines - 20;
					position = linenumber2pos(line_position);
				}
				scroll_pos = 155*pos2linenumber(position) / (num_of_lines-20);
				
				swiWaitForVBlank();
				draw_gui(position, scroll_pos);
				print_button(button, ((BUTTON_WIDTH+3)*button)+(127-((NUM_OF_BUTTONS*(BUTTON_WIDTH+3))/2)), SCREEN_HEIGHT - BUTTON_HEIGHT-3, OFF, screenbottom);
			} else if (button == 1) {
				// Next c
				last_pos = position;
				position = strpos(book, language.get("chapter"), position+1);
				if (position == -1) { position = last_pos; }
				
				line_position = pos2linenumber(position);
				if (line_position > num_of_lines - 20) {
					line_position = num_of_lines - 20;
					position = linenumber2pos(line_position);
				}
				scroll_pos = 155*pos2linenumber(position) / (num_of_lines-20);
				
				swiWaitForVBlank();
				draw_gui(position, scroll_pos);
				print_button(button, ((BUTTON_WIDTH+3)*button)+(127-((NUM_OF_BUTTONS*(BUTTON_WIDTH+3))/2)), SCREEN_HEIGHT - BUTTON_HEIGHT-3, OFF, screenbottom);
			} else if (button == 2) {
				// Look up
				strcpy(input, "");
lookup:

				clear_screen(31, 31, 31, screens[BUFFER_TOP]);
				clear_screen(31, 31, 31, screens[BUFFER_BOTTOM]);
				draw_titlebar(language.get("lookup_titlebar"), screens[BUFFER_TOP]);
				strcpy(msg, language.get("lookup_text"));
				wordwrap_string(msg);
				print_string(msg, 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);

				scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
				scrcpy(screens[SCREEN_BOTTOM], screens[BUFFER_BOTTOM]);
				
				print_keyboard(KEYBOARD_LAYOUT2, screenbottom);
				status = keyboard_string(input, screenbottom, BOOK_AUTOTYPE_LIST, KEYBOARD_LAYOUT2, KEYBOARD_LAYOUT2_SHIFT);
				
				if (status == CANCEL) {
					goto lookup_back;
				}
				
				// Check if it's valid and seperate the string into book chapter and verse
				valid = check_location(input, the_book, the_chapter, the_verse);
				
				if (valid) {						
					load_book(the_book);
					wordwrap_string(book);
					
					strcpy(str, language.get("chapter"));
					strcat(str, the_chapter);
					position = strpos(book, str);
					
					if (position != -1) {
						strcpy(str, the_verse);
						current_char = 0;
						while (str[current_char] != '\0') {
							str[current_char] += 120;
							current_char++;
						}
						position = strpos(book, str, position);
						if (position != -1) {
							position = strrpos(book, "\n", position)+1;
						}
					}
					
					if (position == -1) { position = 0; }
					
					num_of_lines = str_count(book, '\n')+1;
					scroll_pos = 155*pos2linenumber(position) / (num_of_lines-20);
					
					draw_gui(position, scroll_pos);
				} else {
					clear_screen(31, 31, 31, screens[BUFFER_TOP]);
					clear_screen(31, 31, 31, screens[BUFFER_BOTTOM]);
					
					draw_titlebar(language.get("lookup_titlebar"), screens[BUFFER_TOP]);
					strcpy(msg, language.get("lookup_error"));
					wordwrap_string(msg);
					print_string(msg, 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);
					
					scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
					scrcpy(screens[SCREEN_BOTTOM], screens[BUFFER_BOTTOM]);
					
					while (!(keysHeld() & KEY_B)) {
						scanKeys();
						if (keysHeld() & KEY_A) {
							while (keysHeld() & KEY_A) { scanKeys(); swiWaitForVBlank(); }
							goto lookup;
						}
						swiWaitForVBlank();
					}
					
					while (keysHeld() & KEY_B) { scanKeys(); swiWaitForVBlank(); }
					
lookup_back:
					
					if (from_main_menu) {
						// Delete allocated memory
						delete [] msg;
						delete [] input;
						delete [] input2;
						delete [] str;
						delete [] search_results;
						delete [] line;
						delete [] jumpto;
						delete [] bookmarks;
						
						// Go back to main menu
						return;
					}
					
					draw_gui(position, scroll_pos);
				}
			} else if (button == 3) {
				// Search
				strcpy(input, "");
search:
				clear_screen(31, 31, 31, screens[BUFFER_TOP]);
				clear_screen(31, 31, 31, screens[BUFFER_BOTTOM]);
				draw_titlebar(language.get("search_titlebar"), screens[BUFFER_TOP]);
				strcpy(msg, language.get("search_text"));
				wordwrap_string(msg);
				print_string(msg, 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);
				
				scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
				scrcpy(screens[SCREEN_BOTTOM], screens[BUFFER_BOTTOM]);
				
				print_keyboard(KEYBOARD_LAYOUT, screenbottom);
				status = keyboard_string(input, screenbottom, "", KEYBOARD_LAYOUT, KEYBOARD_LAYOUT_SHIFT);
				
				if (status == CANCEL) {
					goto search_back;
				}
				
				// Go through search query and change spaces to slashes to make a str_array
				// I'm assuming you won't enter a slash into your search...
				for (i = 0; i < strlen(input); i++) {
					if (input[i] == ' ') {
						input[i] = '/';
					}
				}
				
				strcpy(search_terms, input);
				
				clear_screen(31, 31, 31, screens[BUFFER_TOP]);
				clear_screen(31, 31, 31, screens[BUFFER_BOTTOM]);
				
				draw_titlebar(language.get("search_titlebar"), screens[BUFFER_TOP]);
				strcpy(msg, language.get("searching"));
				wordwrap_string(msg);
				print_string(msg, 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);
				
				scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
				scrcpy(screens[SCREEN_BOTTOM], screens[BUFFER_BOTTOM]);
				
				strcpy(search_results, "");
				txt_file = fopen(translation, "r");
				num_results = 0;
				
				draw_progressbar_box(screentop);
				
				last_percent_done = -1;
				line_num = 0;
				
				// Skip over the first two lines
				fgets(line, 1024, txt_file);
				fgets(line, 1024, txt_file);
				
				done = 0;
				while (fgets(line, 1024, txt_file) && !done) {
					// Loop through search terms, check if they're in the current verse
					for (i = 0; i < count(input); i++) {
						if (stripos(line, array_index(input, i)) != -1) {
							if (num_results <= 250) {
								strcat(search_results, book_short2long(substr(line, 0, 2)));
								strcat(search_results, substr(line, 3, strpos(line, " ", 4)-1));
								strcat(search_results, "/");
							}
							num_results++;
							
							// Break out of loop to prevent this verse from being added to the results more than once
							break;
						}
					}
					
					if (!strcmp(line, "EOF")) {
						done = 1;
					}
					
					percent_done = (float)line_num/(float)31103*100;
					
					if (percent_done != last_percent_done) {
						last_percent_done = percent_done;
						
						strcpy(msg, strval(num_results));
						strcat(msg, " ");
						strcat(msg, language.get("search_results_found"));
						
						swiWaitForVBlank();
						draw_box(27, 60, 250, 78, 0xFFFF, screens[SCREEN_TOP], true);
						print_string_xy(msg, 27, 60, screens[SCREEN_TOP], RGB15(7, 7, 7) | BIT(15));
						update_progressbar(screentop, percent_done);
					}
					
					line_num++;
				}
				fclose(txt_file);
				if (num_results > 0) { search_results[strlen(search_results)-1] = '\0'; }
				
				clear_screen(31, 31, 31, screens[BUFFER_TOP]);
				
				draw_titlebar(language.get("search_titlebar"), screens[BUFFER_TOP]);
				strcpy(msg, strval(num_results));
				strcat(msg, " ");
				strcat(msg, language.get("search_results_found"));
				
				if (num_results > 250) {
					strcat(msg, " ");
					strcat(msg, language.get("search_first250shown"));
				}
				
				if (num_results == 0) {
					clear_screen(31, 31, 31, screens[BUFFER_BOTTOM]);
				
					strcat(msg, "\n\n");
					strcat(msg, language.get("search_back"));
					wordwrap_string(msg);
					print_string(msg, 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);
					
					scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
					scrcpy(screens[SCREEN_BOTTOM], screens[BUFFER_BOTTOM]);
					
					while (!(keysUp() & KEY_B)) {
						scanKeys();
						if (keysUp() & KEY_A) {
							goto search;
						}
						swiWaitForVBlank();
					}
					
search_back:
					
					if (from_main_menu) {
						// Delete allocated memory
						delete [] msg;
						delete [] input;
						delete [] input2;
						delete [] str;
						delete [] search_results;
						delete [] line;
						delete [] jumpto;
						delete [] bookmarks;
						
						// Go back to main menu
						return;
					}
					
					draw_gui(position, scroll_pos);
				} else {
					strcat(msg, "\n\n");
					strcat(msg, language.get("search_instructions"));
					wordwrap_string(msg);
					print_string(msg, 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);
					
					scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
					
					strcpy(jumpto, select(search_results, screenbottom));
					
					if (!strcmp(jumpto, language.get("cancel"))) {
						goto search_back;
					}
					
					colon_pos = strpos(jumpto, ":");
					space_pos = strrpos(jumpto, " ", colon_pos);
					
					load_book(book_long2short(substr(jumpto, 0, space_pos-1)));
					wordwrap_string(book);
					
					highlight_search_results(search_terms);
					
					strcpy(str, language.get("chapter"));
					strcat(str, substr(jumpto, space_pos+1, colon_pos-1));
					position = strpos(book, str);
					
					if (position != -1) {
						strcpy(str, substr(jumpto, colon_pos+1, strlen(jumpto)-1));
						current_char = 0;
						while (str[current_char] != '\0') {
							str[current_char] += 120;
							current_char++;
						}
						position = strpos(book, str, position);
						if (position != -1) {
							position = strrpos(book, "\n", position)+1;
						}
					}
					
					if (position == -1) { position = 0; }
					
					num_of_lines = str_count(book, '\n')+1;
					scroll_pos = 155*pos2linenumber(position) / (num_of_lines-20);
					
					draw_gui(position, scroll_pos);
				}
			} else if (button == 4) {
				// Book selection
bookselection:
				clear_screen(31, 31, 31, screens[BUFFER_TOP]);
				
				draw_titlebar(language.get("select_titlebar"), screens[BUFFER_TOP]);
				print_string(language.get("select_text"), 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);
				
				scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
				
				bookname = select(BOOK_SELECTION_LIST, screenbottom);
				
				if (strcmp(bookname, language.get("cancel"))) {
					load_book(book_long2short(bookname));
					wordwrap_string(book);
					
					position = 0;
					scroll_pos = 0;
					line_position = 0;
					num_of_lines = str_count(book, '\n')+1;
				} else {
					if (from_main_menu) {
						// Delete allocated memory
						delete [] msg;
						delete [] input;
						delete [] input2;
						delete [] str;
						delete [] search_results;
						delete [] line;
						delete [] jumpto;
						delete [] bookmarks;
						
						// Go back to main menu
						return;
					}
				}
								
				draw_gui(position, scroll_pos);
			} else if (button == 5) {
				// Bookmarks
bookmarks:

				bool reload_book = false;
				
				strcpy(input, "");
				while (strcmp(input, language.get("bookmarks_back"))) {
					clear_screen(31, 31, 31, screens[BUFFER_TOP]);
				
					draw_titlebar(language.get("bookmarks_titlebar"), screens[BUFFER_TOP]);
					print_string(language.get("bookmarks_text"), 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);
					
					scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
					
					// If there are no bookmarks don't show "Load bookmark" or "Delete bookmark"
					txt_file = fopen("/bible/bookmarks", "r");
					
					char menu_items[64] = "";
					
					if (fgets(bookmarks, 4096, txt_file)) {
						strcpy(menu_items, language.get("bookmarks_add"));
						strcat(menu_items, "/");
						strcat(menu_items, language.get("bookmarks_load"));
						strcat(menu_items, "/");
						strcat(menu_items, language.get("bookmarks_delete"));
						strcat(menu_items, "/");
						strcat(menu_items, language.get("bookmarks_back"));
						
						strcpy(input, select(menu_items, screenbottom, '/', false));
					} else {
						strcpy(menu_items, language.get("bookmarks_add"));
						strcat(menu_items, "/");
						strcat(menu_items, language.get("bookmarks_back"));
						
						strcpy(input, select(menu_items, screenbottom, '/', false));
						strcpy(bookmarks, "");
					}
					
					fclose(txt_file);						
					
					if (!strcmp(input, language.get("bookmarks_add"))) {
						strcpy(input2, current_location);
					
add_bookmark:
						clear_screen(31, 31, 31, screens[BUFFER_TOP]);
						clear_screen(31, 31, 31, screens[BUFFER_BOTTOM]);
						
						draw_titlebar(language.get("bookmarks_add_titlebar"), screens[BUFFER_TOP]);
						strcpy(msg, language.get("bookmarks_add_text"));
						wordwrap_string(msg);
						print_string(msg, 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);
						print_keyboard(KEYBOARD_LAYOUT2, screens[BUFFER_BOTTOM]);
						
						scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
						scrcpy(screens[SCREEN_BOTTOM], screens[BUFFER_BOTTOM]);
						
						status = keyboard_string(input2, screenbottom, BOOK_AUTOTYPE_LIST, KEYBOARD_LAYOUT2, KEYBOARD_LAYOUT2_SHIFT);
						
						if (status == OK) {
							if (check_location(input2, the_book, the_chapter, the_verse)) {
								if (strlen(bookmarks) > 0) {
									strcat(bookmarks, "/");
								}
								strcat(bookmarks, input2);
								
								txt_file = fopen("/bible/bookmarks", "w");
								fwrite(bookmarks, sizeof(char), strlen(bookmarks), txt_file);
								fclose(txt_file);
								
								reload_book = true;
							} else {
								clear_screen(31, 31, 31, screens[BUFFER_TOP]);
								clear_screen(31, 31, 31, screens[BUFFER_BOTTOM]);
								
								draw_titlebar(language.get("bookmarks_add_titlebar"), screens[BUFFER_TOP]);
								strcpy(msg, language.get("bookmarks_add_error"));
								wordwrap_string(msg);
								print_string(msg, 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);
								
								scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
								scrcpy(screens[SCREEN_BOTTOM], screens[BUFFER_BOTTOM]);
								
								while (!(keysHeld() & KEY_A)) { scanKeys(); swiWaitForVBlank(); }
								while (keysHeld() & KEY_A) { scanKeys(); swiWaitForVBlank(); }
								
								goto add_bookmark;
							}
						}
					} else if (!strcmp(input, language.get("bookmarks_load"))) {
						clear_screen(31, 31, 31, screens[BUFFER_TOP]);
						clear_screen(31, 31, 31, screens[BUFFER_BOTTOM]);
						
						draw_titlebar(language.get("bookmarks_load_titlebar"), screens[BUFFER_TOP]);
						strcpy(msg, language.get("bookmarks_load_text"));
						wordwrap_string(msg);
						print_string(msg, 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);
						
						scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
						
						strcpy(input2, select(bookmarks, screenbottom));
						
						if (strcmp(input2, language.get("cancel"))) {							
							clear_screen(31, 31, 31, screens[BUFFER_TOP]);
							clear_screen(31, 31, 31, screens[BUFFER_BOTTOM]);
							
							draw_titlebar(language.get("bookmarks_load_titlebar"), screens[BUFFER_TOP]);
							strcpy(msg, language.get("validating"));
							print_string(msg, 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);
							
							scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
							scrcpy(screens[SCREEN_BOTTOM], screens[BUFFER_BOTTOM]);
							
							if (check_location(input2, the_book, the_chapter, the_verse)) {									
								load_book(the_book);
								wordwrap_string(book);
								
								strcpy(str, language.get("chapter"));
								strcat(str, the_chapter);
								position = strpos(book, str);
								
								if (position != -1) {
									strcpy(str, the_verse);
									current_char = 0;
									while (str[current_char] != '\0') {
										str[current_char] += 120;
										current_char++;
									}
									position = strpos(book, str, position);
									if (position != -1) {
										position = strrpos(book, "\n", position)+1;
									}
								}
								
								if (position == -1) { position = 0; }
								
								from_main_menu = false;
								
								break;
							} else {
								clear_screen(31, 31, 31, screens[BUFFER_TOP]);
								clear_screen(31, 31, 31, screens[BUFFER_BOTTOM]);
								
								draw_titlebar(language.get("bookmarks_load_titlebar"), screens[BUFFER_TOP]);
								strcpy(msg, language.get("bookmarks_load_error"));
								wordwrap_string(msg);
								print_string(msg, 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);
								
								scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
								scrcpy(screens[SCREEN_BOTTOM], screens[BUFFER_BOTTOM]);
								
								while (!(keysHeld() & KEY_A)) { scanKeys(); swiWaitForVBlank(); }
								while (keysHeld() & KEY_A) { scanKeys(); swiWaitForVBlank(); }
							}
						}
					} else if (!strcmp(input, language.get("bookmarks_delete"))) {
						clear_screen(31, 31, 31, screens[BUFFER_TOP]);
						
						draw_titlebar(language.get("bookmarks_delete_titlebar"), screens[BUFFER_TOP]);
						strcpy(msg, language.get("bookmarks_delete_text"));
						wordwrap_string(msg);
						print_string(msg, 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);
						
						scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
							
						while (1) {
							strcpy(input2, select(bookmarks, screenbottom));
							
							if (strcmp(input2, language.get("cancel"))) {															
								array_remove(bookmarks, input2);
								
								txt_file = fopen("/bible/bookmarks", "w");
								fwrite(bookmarks, sizeof(char), strlen(bookmarks), txt_file);
								fclose(txt_file);
								
								scrcpy(screens[BUFFER_BOTTOM], screens[SCREEN_BOTTOM]);
								
								darken_screen(screens[BUFFER_BOTTOM]);
								draw_alert_box(language.get("bookmarks_delete_alert"), screens[BUFFER_BOTTOM]);
								
								scrcpy(screens[SCREEN_BOTTOM], screens[BUFFER_BOTTOM]);
								
								for (i = 0; i < 30; i++) {
									swiWaitForVBlank();
								}
								
								reload_book = true;
								
								if (strlen(bookmarks) == 0) {
									break;
								}
							} else {
								break;
							}
							
							clear_screen(31, 31, 31, screens[BUFFER_TOP]);
						}
					}
				}
				
				if (from_main_menu) {
					// Delete allocated memory
					delete [] msg;
					delete [] input;
					delete [] input2;
					delete [] str;
					delete [] search_results;
					delete [] line;
					delete [] jumpto;
					delete [] bookmarks;
					
					// Go back to main menu
					return;
				}
				
				if (reload_book) {
					load_book(bookname_short);
					wordwrap_string(book);
				}
				
				num_of_lines = str_count(book, '\n')+1;
				scroll_pos = 155*pos2linenumber(position) / (num_of_lines-20);
				
				draw_gui(position, scroll_pos);
			} else if (button == 6) {
				// Translations
				clear_screen(31, 31, 31, screens[BUFFER_TOP]);
				clear_screen(29, 29, 28, screens[BUFFER_BOTTOM]);

				draw_titlebar(language.get("translations_titlebar"), screens[BUFFER_TOP]);
				strcpy(msg, language.get("translations_text"));
				wordwrap_string(msg);
				print_string(msg, 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);
				
				scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
				scrcpy(screens[SCREEN_BOTTOM], screens[BUFFER_BOTTOM]);
				
				// Load images
				Image image_button(screens[SCREEN_BOTTOM], "/bible/images/button.img");
				Image image_button_pressed(screens[SCREEN_BOTTOM], "/bible/images/button_pressed.img");
				Image image_selectbox(screens[SCREEN_BOTTOM], "/bible/images/select.img");
				Image image_selectbox_pressed(screens[SCREEN_BOTTOM], "/bible/images/select_pressed.img");
				Image image_selector(screens[BUFFER_TOP], "/bible/images/select_box_selector.img");
				Image image_select_scroll(screens[BUFFER_TOP], "/bible/images/select_scroll.img");
				Image image_select_scroll_disabled(screens[BUFFER_TOP], "/bible/images/select_scroll_disabled.img");

				Selectbox translation_select(screens[SCREEN_BOTTOM], 5, 10, 246, 31, &image_selectbox, &image_selectbox_pressed, &image_selector, &image_select_scroll, &image_select_scroll_disabled, translations, preferences.get("translation"));
				Button button_ok(language.get("button_ok"), screens[SCREEN_BOTTOM], 5, 50, &image_button, &image_button_pressed);
				
				translation_select.draw_button();
				button_ok.draw();
				
				bool finished = false;
				while (!finished) {
					scanKeys();
					stylus = touchReadXY();
					
					if (translation_select.update(stylus.px, stylus.py)) {
						preferences.set("translation", translation_select.get_selected_option());
						translation_select.draw_button();
					}
					
					if (button_ok.check(stylus.px, stylus.py)) {
						while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
						button_ok.check(stylus.px, stylus.py);
						finished = true;
					}
				}
				
				preferences.write_to_file("/bible/preferences", "Preferences");
				
				translation2filename(false);
				
				if (!check_location(current_location, the_book, the_chapter, the_verse)) {
					strcpy(the_book, book_long2short(array_index(BOOK_SELECTION_LIST, 0)));
					strcpy(the_chapter, "1");
					strcpy(the_verse, "1");
				}
				
				strcpy(bookname_short, "");
				
				load_book(the_book);
				wordwrap_string(book);
				
				strcpy(str, language.get("chapter"));
				strcat(str, the_chapter);
				position = strpos(book, str);
				
				if (position != -1) {
					strcpy(str, the_verse);
					current_char = 0;
					while (str[current_char] != '\0') {
						str[current_char] += 120;
						current_char++;
					}
					position = strpos(book, str, position);
					if (position != -1) {
						position = strrpos(book, "\n", position)+1;
					}
				}
				
				if (position == -1) { position = 0; }
				
				num_of_lines = str_count(book, '\n')+1;
				scroll_pos = 155*pos2linenumber(position) / (num_of_lines-20);
				
				draw_gui(position, scroll_pos);
			} else if (button == 7) {
				// Preferences
				clear_screen(31, 31, 31, screens[BUFFER_TOP]);
				clear_screen(29, 29, 28, screens[BUFFER_BOTTOM]);

				draw_titlebar(language.get("preferences_titlebar"), screens[BUFFER_TOP]);
				strcpy(msg, language.get("preferences_text"));
				wordwrap_string(msg);
				print_string(msg, 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);
				
				scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
				scrcpy(screens[SCREEN_BOTTOM], screens[BUFFER_BOTTOM]);
				
				// Load images
				Image image_button(screens[SCREEN_BOTTOM], "/bible/images/button.img");
				Image image_button_pressed(screens[SCREEN_BOTTOM], "/bible/images/button_pressed.img");
				Image image_selectbox(screens[SCREEN_BOTTOM], "/bible/images/select.img");
				Image image_selectbox_pressed(screens[SCREEN_BOTTOM], "/bible/images/select_pressed.img");
				Image image_selector(screens[BUFFER_TOP], "/bible/images/select_box_selector.img");
				Image image_select_scroll(screens[BUFFER_TOP], "/bible/images/select_scroll.img");
				Image image_select_scroll_disabled(screens[BUFFER_TOP], "/bible/images/select_scroll_disabled.img");
				
				Selectbox language_select(screens[SCREEN_BOTTOM], 5, 10, 246, 31, &image_selectbox, &image_selectbox_pressed, &image_selector, &image_select_scroll, &image_select_scroll_disabled, languages, preferences.get("language"));
				Button button_save(language.get("button_save"), screens[SCREEN_BOTTOM], 5, 50, &image_button, &image_button_pressed);
				
				language_select.draw_button();
				button_save.draw();
				
				bool finished = false;
				while (!finished) {
					scanKeys();
					stylus = touchReadXY();
					
					if (language_select.update(stylus.px, stylus.py)) {
						preferences.set("language", language_select.get_selected_option());
						load_language();
						
						clear_screen(31, 31, 31, screens[BUFFER_TOP]);

						draw_titlebar(language.get("preferences_titlebar"), screens[BUFFER_TOP]);
						strcpy(msg, language.get("preferences_text"));
						wordwrap_string(msg);
						print_string(msg, 0, screens[BUFFER_TOP], screens[BUFFER_BOTTOM]);
						
						scrcpy(screens[SCREEN_TOP], screens[BUFFER_TOP]);
						
						language_select.draw_button();						
						button_save.set_text(language.get("button_save"));
						button_save.draw();
					}
					
					if (button_save.check(stylus.px, stylus.py)) {
						while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
						button_save.check(stylus.px, stylus.py);
						finished = true;
					}
				}
				
				preferences.write_to_file("/bible/preferences", "Preferences");
				
				load_language();
				
				check_location(current_location, the_book, the_chapter, the_verse);
				
				strcpy(bookname_short, "");
				
				load_book(the_book);
				wordwrap_string(book);
				
				strcpy(str, language.get("chapter"));
				strcat(str, the_chapter);
				position = strpos(book, str);
				
				if (position != -1) {
					strcpy(str, the_verse);
					current_char = 0;
					while (str[current_char] != '\0') {
						str[current_char] += 120;
						current_char++;
					}
					position = strpos(book, str, position);
					if (position != -1) {
						position = strrpos(book, "\n", position)+1;
					}
				}
				
				if (position == -1) { position = 0; }
				
				num_of_lines = str_count(book, '\n')+1;
				scroll_pos = 155*pos2linenumber(position) / (num_of_lines-20);
				
				draw_gui(position, scroll_pos);
			}			
		}
		
		swiWaitForVBlank();
		scanKeys();
		stylus = touchReadXY();
	}
	
	// Delete allocated memory (this should never happen though, as it is under an infinite loop.)
	delete [] msg;
	delete [] input;
	delete [] input2;
	delete [] str;
	delete [] search_results;
	delete [] line;
	delete [] jumpto;
	delete [] bookmarks;
}

void clear_text(u16 *screentop, u16 *screenbottom) {
	/*u8 put_x, put_y;
	
	for (put_x = MARGIN_SIDES; put_x < 255-MARGIN_SIDES; put_x++) {
		for (put_y = MARGIN_MAIN_TOP; put_y < 191-MARGIN_MAIN_BOTTOM; put_y++) {
			screentop[put_x + put_y * SCREEN_WIDTH] = RGB15(31, 31, 31) | BIT(15);
		}
		for (put_y = MARGIN_SUB_TOP; put_y < 191-MARGIN_SUB_BOTTOM; put_y++) {
			screenbottom[put_x + put_y * SCREEN_WIDTH] = RGB15(31, 31, 31) | BIT(15);
		}
	}*/
}

void update_titlebar(u32 pos, u16 *screen) {
	u8 found_superscript = 0, found_verse = 0;
	char titlebar_text[64], verse[4], chapter[4];
	u32 current_char, chapter_pos, new_line_pos, verse_superscript_start = 0, verse_superscript_end = 0;
	
	// If they're at the very last line of the book, there won't be a newline.
	if (strpos(book, "\n", pos) == -1) {
		pos -= 2;
	}
	
	// Find their chapter
	chapter_pos = strrpos(book, language.get("chapter"), strpos(book, "\n", pos));
	new_line_pos = strpos(book, "\n", chapter_pos);
	strcpy(chapter, substr(book, chapter_pos+strlen(language.get("chapter")), new_line_pos-1));
	
	// Find the verse they're on
	if (pos == chapter_pos) {
		strcpy(verse, "1");
	} else {
		current_char = strpos(book, "\n", pos);
		while (!found_verse) {
			if (book[current_char] > 167 && book[current_char] <= 177 && !found_superscript) {
				found_superscript = 1;
				verse_superscript_end = current_char;
			}
			if (found_superscript && (book[current_char] < 168 || book[current_char] > 177)) {
				found_verse = 1;
				verse_superscript_start = current_char+1;
			}
			
			current_char--;
		}
		
		// Extract superscript verse number, convert it to normal numbers
		strcpy(verse, substr(book, verse_superscript_start, verse_superscript_end));
		current_char = 0;
		while (verse[current_char] != '\0') {
			verse[current_char] -= 120;
			current_char++;
		}
	}
	
	// Now make the title bar text and print it
	strcpy(titlebar_text, bookname_long);
	strcat(titlebar_text, " ");
	strcat(titlebar_text, chapter);
	strcat(titlebar_text, ":");
	strcat(titlebar_text, verse);
	
	strcpy(current_location, titlebar_text);
	
	draw_titlebar(titlebar_text, screen);
}

void draw_titlebar(char *string, u16 *screen) {
	u16 put_x, put_y;
	
	const u16 titlebar_colours[] = {
		RGB15(17, 13, 9) | BIT(15),
		RGB15(31, 23, 17) | BIT(15),
		RGB15(29, 20, 12) | BIT(15),
		RGB15(27, 20, 12) | BIT(15),
		RGB15(27, 19, 10) | BIT(15),
		RGB15(26, 18, 9) | BIT(15),
		RGB15(26, 18, 9) | BIT(15),
		RGB15(26, 17, 8) | BIT(15),
		RGB15(26, 17, 8) | BIT(15),
		RGB15(25, 15, 7) | BIT(15),
		RGB15(25, 16, 7) | BIT(15),
		RGB15(25, 16, 7) | BIT(15),
		RGB15(25, 16, 7) | BIT(15),
		RGB15(25, 16, 7) | BIT(15),
		RGB15(25, 16, 8) | BIT(15),
		RGB15(25, 16, 8) | BIT(15),
		RGB15(26, 16, 8) | BIT(15),
		RGB15(26, 17, 8) | BIT(15),
		RGB15(26, 16, 8) | BIT(15),
		RGB15(18, 12, 5) | BIT(15)
	};
	
	// Draw divider line
	for (put_x = 0; put_x <= 255; put_x++) {
		screen[put_x + (sizeof(titlebar_colours) / 2) * SCREEN_WIDTH] = RGB15(0, 0, 0) | BIT(15);
	}
	
	// Draw background color
	for (put_y = 0; put_y < sizeof(titlebar_colours) / 2; put_y++) {		
		for (put_x = 0; put_x <= 255; put_x++) {
			screen[put_x + put_y * SCREEN_WIDTH] = titlebar_colours[put_y];
		}
	}
	
	print_string_center(string, 4, screen, RGB15(31, 31, 31) | BIT(15));
}

u32 linenumber2pos(u32 linenum) {
	u32 current_char = 0, current_line = 0;
	
	while (current_line != linenum) {
		if (book[current_char] == '\n') {
			current_line++;
		}
		current_char++;
	}
	
	return current_char;
}

u32 pos2linenumber(u32 pos) {
	u32 current_char = 0, current_line = 0;
	
	while (current_char != pos) {
		if (book[current_char] == '\n') {
			current_line++;
		}
		current_char++;
	}
	
	return current_line;
}

u8 check_location(char *string, char *the_book, char *the_chapter, char *the_verse) {
	char book_name[256], chapter[256], verse[256];
	char *short_book_name;
	u16 space_pos, colon_pos;

	// Seperate book, chapter, and verse into individual strings
	if (book_long2short(string)) {
		strcpy(book_name, string);
		strcpy(chapter, "1");
		strcpy(verse, "1");
	} else if (str_count(string, ':') == 0) {
		space_pos = strrpos(string, " ", strlen(string)-1);
		
		strcpy(book_name, substr(string, 0, space_pos-1));
		strcpy(chapter, substr(string, space_pos+1, strlen(string)-1));
		strcpy(verse, "1");
	} else {
		space_pos = strrpos(string, " ", strlen(string)-1);
		colon_pos = strpos(string, ":");
		
		strcpy(book_name, substr(string, 0, space_pos-1));
		strcpy(chapter, substr(string, space_pos+1, colon_pos-1));
		strcpy(verse, substr(string, colon_pos+1, strlen(string)-1));
	}
	
	// Check if the book exists
	short_book_name = book_long2short(book_name);
	
	if (!short_book_name) {
		return 0;
	}
	
	// Store short book name, chapter, and verse into arrays passed to the function
	strcpy(the_book, short_book_name);
	strcpy(the_chapter, chapter);
	strcpy(the_verse, verse);
	
	// Now check if the verse/chapter exists
	if (intval(the_chapter) <= num_chapters_in_book[get_array_index(BOOK_SELECTION_LIST, book_name)] && intval(the_verse) <= num_verses_in_chapter[get_array_index(BOOK_SELECTION_LIST, book_name)][intval(the_chapter)]) {
		return 1;
	}
	
	return 0;
}

