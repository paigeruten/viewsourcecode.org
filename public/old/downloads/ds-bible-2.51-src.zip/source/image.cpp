#include <nds.h>
#include <fat.h>
#include <stdio.h>
#include <string.h>
#include "image.h"
#include "font.h"

Image::Image(u16 *the_screen, char *filename) {
	u8 read_height, read_width;

	screen = the_screen;
	
	FILE *img = fopen(filename, "r");
	
	if (img) {			
		// Read width and height
		fread(&read_width, sizeof(u8), 1, img);
		fread(&read_height, sizeof(u8), 1, img);
		
		width = read_width;
		height = read_height;
		
		// Assume that if it's 0 pixels wide, it's supposed to be 256 pixels wide.
		if (width == 0) { width = 256; }
		
		data = new u16 [width * height];
		
		// Read image data
		fread(data, sizeof(u16), width * height, img);
		
		fclose(img);
	} else {		
		// If file can't be opened, set image to a red square
		width = 5;
		height = 5;
		data = new u16 [width * height];
		
		memset(data, RGB15(31, 0, 0) | BIT(15), width * height * 2);
	}
}

Image::~Image() {
	delete [] data;
	data = 0;
}

void Image::draw(u16 x, u16 y) const {
	u16 put_x, put_y, get_x, get_y, end_x, end_y;
	
	end_x = x + width;
	end_y = y + height;
	
	get_y = 0;
	for (put_y = y; put_y < end_y; put_y++) {
		get_x = 0;
		for (put_x = x; put_x < end_x; put_x++) {
			if (put_x < 256 && put_y < 256) {
				screen[put_x + put_y * SCREEN_WIDTH] = data[get_x + get_y * width];
			}
			get_x++;
		}
		get_y++;
	}
}

void Image::draw_flipped(u16 x, u16 y) const {
	u16 put_x, put_y, get_x, get_y, end_x, end_y;
	
	end_x = x + width;
	end_y = y + height;
	
	get_y = height - 1;
	for (put_y = y; put_y < end_y; put_y++) {
		get_x = 0;
		for (put_x = x; put_x < end_x; put_x++) {
			if (put_x < 256 && put_y < 256) {
				screen[put_x + put_y * SCREEN_WIDTH] = data[get_x + get_y * width];
			}
			get_x++;
		}
		get_y--;
	}
}

void Image::erase(u16 x, u16 y, u16 color) const {
	u16 put_x, put_y, end_x, end_y;
	
	end_x = x + width;
	end_y = y + height;
	
	for (put_y = y; put_y < end_y; put_y++) {
		for (put_x = x; put_x < end_x; put_x++) {
			if (put_x < 256 && put_y < 256) {
				screen[put_x + put_y * SCREEN_WIDTH] = color;
			}
		}
	}
}

