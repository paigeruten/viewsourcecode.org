#ifndef _scroll_h
#define _scroll_h

void load_language();

// Print string to screen starting at offset until no room left on screens. Returns position of the character after the last one it prints.
u32 print_string(char *string, u32 offset, u16 *screentop, u16 *screenbottom, bool highlight_stuff=false, u16 color = RGB15(0, 0, 0) | BIT(15), u16 bgcolor = RGB15(31, 31, 31) | BIT(15), u16 highlight_color = RGB15(31, 15, 0) | BIT(15));

// Insert newlines into string to prevent words from looking like th
// is.
void wordwrap_string(char *string);

// This is where the main loop is.
void bible(u16 *screentop, u16 *screenbottom, u8 action, char *the_translation);

// Clear all the text (everything inside the margins)
void clear_text(u16 *screentop, u16 *screenbottom);

// Redraw the titlebar
void update_titlebar(u32 pos, u16 *screen);

// Draw the titlebar
void draw_titlebar(char *string, u16 *screen);

// Returns position in book where the line linenum starts
u32 linenumber2pos(u32 linenum);

// Opposite of above function
u32 pos2linenumber(u32 pos);

// Check if a string is a valid location (Example: "Genesis" or "Genesis 1" or "Genesis 1:1")
u8 check_location(char *string, char *the_book, char *the_chapter, char *the_verse);

void translation2filename(bool edit_bottom_screen);

void remove_character(char *string, u32 char_index);
void add_character(char *string, u32 char_index, char ch);

void draw_gui(s32 position, u8 scroll_pos, u16 scrollbar_colour = RGB15(0, 0, 0) | BIT(15));

enum { NO_ACTION, ACTION_SELECTBOOK, ACTION_LOOKUP, ACTION_SEARCH, ACTION_BOOKMARKS };

#endif
