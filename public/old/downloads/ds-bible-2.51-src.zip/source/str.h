#ifndef _str_h
#define _str_h

// Returns first occurence of string *needle in string *haystack. Starts searching at offset.
s32 strpos(const char *haystack, const char *needle, u32 offset = 0);

// Same as above but case-insensitive
s32 stripos(const char *haystack, const char *needle, u32 offset = 0);

// Same as above but searches in reverse
s32 strrpos(const char *haystack, const char *needle, u32 offset);
s32 strripos(const char *haystack, const char *needle, u32 offset);

// Returns a substring of a string.
char *substr(const char *string, u32 start, u32 end);

// Returns a string with uppercase letters changed to lowercase.
void strtolower(char *string);

// Returns number of times a char appears in a string
u32 str_count(const char *string, char character);

// Converts string into a number. Hyphens (negative numbers) and decimal points won't work.
u32 intval(char *string);

// Converts a number to a string.
char *strval(u32 num);

// Converts a string (consisting of digits) into superscript.
char *superscript(char *string);

// Removes the last char of a string
void chop(char *string);

#endif
