#ifndef _progressbar_h
#define _progressbar_h

void draw_progressbar_box(u16 *screen);
void update_progressbar(u16 *screen, u8 progress);

#endif

