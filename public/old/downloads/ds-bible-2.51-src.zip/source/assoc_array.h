#ifndef _assoc_array_h
#define _assoc_array_h

enum AssocArrayStatus { ASSOC_ARRAY_OK, ASSOC_ARRAY_CANT_OPEN_FILE };

class AssocArray {
	public:
		// Constructors
		AssocArray();
		~AssocArray();
		
		// Accessors
		char *get(const char *key);
		void set(const char *key, const char *value);
		void append(const char *key, const char *value);
		void remove(const char *key);
		void clear();
		u8 count() const { return num_elements; }
		char *iterate_keys();
		
		// Methods
		AssocArrayStatus load_from_file(const char *filename);
		AssocArrayStatus write_to_file(const char *filename, const char *title);
	private:
		char *keys[128];
		char *values[128];
		u8 num_elements;
		
		s16 index_of_key(const char *key) const;
		void change_escaped_newlines_to_newlines(char *string);
};

#endif

