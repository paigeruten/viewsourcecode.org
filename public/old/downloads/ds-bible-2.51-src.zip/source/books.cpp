#include <nds.h>
#include <string.h>
#include "books.h"
#include "str.h"
#include "str_array.h"

extern char BOOK_LENGTHS[1024];
extern char BOOK_SHORT2LONG_LIST[1024];
extern char BOOK_SELECTION_LIST[1024];

u8 book_index(char *bookname) {
	u8 i = 0;
	
	while (i <= 255) {
		if (!strcmp(array_index(BOOK_SELECTION_LIST, i), bookname)) {
			return i;
		}
	
		i++;
	}
}

char *book_long2short(char *bookname) {
	char bookname_slashes[64] = "/";
	static char return_string[64];
	s16 slash_pos;
	
	strcat(bookname_slashes, bookname);
	strcat(bookname_slashes, "/");
	
	slash_pos = strpos(BOOK_SHORT2LONG_LIST, bookname_slashes);
	if (slash_pos == -1) { return NULL; }
	slash_pos = strpos(BOOK_SHORT2LONG_LIST, "/", slash_pos+1);
	
	strcpy(return_string, substr(BOOK_SHORT2LONG_LIST, slash_pos+1, slash_pos+3));
	
	return return_string;
}

char *book_short2long(char *bookname) {
	char bookname_slashes[64] = "/";
	static char return_string[64];
	s16 start_slash_pos, end_slash_pos;
	
	strcat(bookname_slashes, bookname);
	strcat(bookname_slashes, "/");
	
	end_slash_pos = strrpos(BOOK_SHORT2LONG_LIST, bookname_slashes, strlen(BOOK_SHORT2LONG_LIST) - strlen(bookname_slashes));
	if (end_slash_pos == -1) { return NULL; }
	start_slash_pos = strrpos(BOOK_SHORT2LONG_LIST, "/", end_slash_pos-1);

	strcpy(return_string, substr(BOOK_SHORT2LONG_LIST, start_slash_pos+1, end_slash_pos-1));
	
	return return_string;
}

u16 book_short2length(char *bookname) {
	char bookname_slashes[64] = "/", return_string[64];
	s16 slash_pos, slash2_pos;
	
	strcat(bookname_slashes, bookname);
	strcat(bookname_slashes, "/");
	
	slash_pos = strpos(BOOK_LENGTHS, bookname_slashes);
	if (slash_pos == -1) { return NULL; }
	slash_pos = strpos(BOOK_LENGTHS, "/", slash_pos+1);
	slash2_pos = strpos(BOOK_LENGTHS, "/", slash_pos+1);
	
	strcpy(return_string, substr(BOOK_LENGTHS, slash_pos+1, slash2_pos-1));
	
	return intval(return_string);
}

