#include <nds.h>
#include <string.h>
#include "font.h"
#include "fontdata.h"
#include "str.h"
#include "screenshotter.h"
#include "assoc_array.h"

char KEYBOARD_LAYOUT[]        = "1234567890-=\b\\qwertyuiop[]\\asdfghjkl;\n\\zxcvbnm,./\'\\    \t";
char KEYBOARD_LAYOUT_SHIFT[]  = { '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '\b', '\\', 224, 225, 226, 227, 228, 229, 232, 233, 234, 235, '{', '}', '\\', 236, 237, 238, 239, 242, 243, 244, 245, 246, ':', '\n', '\\', 249, 250, 251, 252, 231, 241, 253, '<', '>', '?', '"', '\\', ' ', ' ', ' ', ' ', '\t', '\0' };
char KEYBOARD_LAYOUT2[]       = "1234567890\b\\ qwertyuiop\\  asdfghjkl\n\\   zxcvbnm:\\    \t";
char KEYBOARD_LAYOUT2_SHIFT[] = { '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '\b', '\\', ' ', 224, 225, 226, 227, 228, 229, 232, 233, 234, 235, '\\', ' ', ' ', 236, 237, 238, 239, 242, 243, 244, 245, 246, '\n', '\\', ' ', ' ', ' ', 249, 250, 251, 252, 231, 241, 253, ':', '\\', ' ', ' ', ' ', ' ', '\t', '\0' };

#include "keyboard.h"

char clipboard[1024] = "";

extern u8 font_widths[256];
extern AssocArray language;

KeyboardStatus keyboard_string(char *string, u16 *screen, char *autofill, char *keyboard_layout, char *keyboard_layout_shift) {
	char key = '\0';
	char input[256] = "", autofill_test[256] = "";
	touchPosition stylus;
	u8 cursor_pos = 0, highlight_cursor = 0, highlight_cursor_last = 0, vblank_count = 0, cursor_x = 0, i = 0, update_cursor = 0, highlighted = OFF, shift = 0, dont_autofill = 0, length;
	u16 current_char;
	s32 autofill_start_slash, autofill_end_slash;

	if (strlen(string) > 0) {
		strcpy(input, string);
		cursor_pos = strlen(string);
		highlight_cursor = 0;
		highlight_cursor_last = strlen(string);
		highlighted = ON;
		update_textbox(input, screen);
		clear_textbox(screen);
		print_string_highlighted(input, TEXTBOX_LEFT_X+2, TEXTBOX_Y+6, screen, cursor_pos, highlight_cursor);
	}
	
	update_cancel_button(SCREEN_WIDTH - ((string_width(language.get("keyboard_cancel"), strlen(language.get("keyboard_cancel"))) + 10)) - 10, 167, (string_width(language.get("keyboard_cancel"), strlen(language.get("keyboard_cancel"))) + 10), screen);

	while (key != '\n') {
		scanKeys();
		
		screenshotter();
		
		if (keysHeld() & KEY_TOUCH) {
			stylus = touchReadXY();
		
			if (update_cancel_button(SCREEN_WIDTH - ((string_width(language.get("keyboard_cancel"), strlen(language.get("keyboard_cancel"))) + 10)) - 10, 167, (string_width(language.get("keyboard_cancel"), strlen(language.get("keyboard_cancel"))) + 10), screen)) {
				while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
			
				strcpy(string, "");
				return CANCEL;
			}
		
			// Check if they are touching inside the textbox
			if (stylus.px > TEXTBOX_LEFT_X && stylus.px < TEXTBOX_RIGHT_X && stylus.py > TEXTBOX_Y && stylus.py < TEXTBOX_Y+TEXTBOX_HEIGHT) {
				highlighted = OFF;
				cursor_pos = stylus2cursor(stylus.px, input);
				update_cursor = 1;
				update_textbox(input, screen);
				
				// Text highlighting
				while (keysHeld() & KEY_TOUCH) {
					scanKeys();
					stylus = touchReadXY();
					
					// Test if the stylus is still in the box
					if (stylus.px > TEXTBOX_LEFT_X && stylus.px < TEXTBOX_RIGHT_X && stylus.py > TEXTBOX_Y && stylus.py < TEXTBOX_Y+TEXTBOX_HEIGHT)
						highlight_cursor = stylus2cursor(stylus.px, input);
					if (highlight_cursor != highlight_cursor_last) {
						clear_textbox(screen);
						print_string_highlighted(input, TEXTBOX_LEFT_X+2, TEXTBOX_Y+6, screen, cursor_pos, highlight_cursor);
					}
					highlight_cursor_last = highlight_cursor;
					
					swiWaitForVBlank();
				}
				
				if (highlight_cursor != cursor_pos) {
					highlighted = ON;
					clear_textbox(screen);
					print_string_highlighted(input, TEXTBOX_LEFT_X+2, TEXTBOX_Y+6, screen, cursor_pos, highlight_cursor);
				} else {
					highlighted = OFF;
					clear_textbox(screen);
					print_string_xy(input, TEXTBOX_LEFT_X+2, TEXTBOX_Y+6, screen);
				}
				
				dont_autofill = 1;
			} else {
				if (shift)
					key = get_key(keyboard_layout_shift, stylus.px, stylus.py);
				else
					key = get_key(keyboard_layout, stylus.px, stylus.py);
				if (key == '\b') {
					switch (highlighted) {
						case ON:
							if (cursor_pos < highlight_cursor) {
								current_char = cursor_pos;
								while (current_char != highlight_cursor) {
									delete_char(input, cursor_pos+1);
									current_char++;
								}
							} else {
								current_char = highlight_cursor;
								while (current_char != cursor_pos) {
									delete_char(input, highlight_cursor+1);
									current_char++;
								}
								cursor_pos = highlight_cursor;
							}
							
							update_cursor = 1;
							update_textbox(input, screen);
							highlighted = OFF;
							break;
						case OFF:
							delete_char(input, cursor_pos);
							if (cursor_pos > 0) cursor_pos--;
							update_cursor = 1;
							update_textbox(input, screen);
							break;
					}
					
					dont_autofill = 1;
				} else if (key == '\t') {
					switch (highlighted) {
						case ON:
							if (cursor_pos < highlight_cursor) {
								current_char = cursor_pos;
								while (current_char != highlight_cursor) {
									delete_char(input, cursor_pos+1);
									current_char++;
								}
							} else {
								current_char = highlight_cursor;
								while (current_char != cursor_pos) {
									delete_char(input, highlight_cursor+1);
									current_char++;
								}
								cursor_pos = highlight_cursor;
							}
							
							insert_char(input, cursor_pos, ' ');
							cursor_pos++;							
							update_cursor = 1;
							update_textbox(input, screen);
							highlighted = OFF;
							break;
						case OFF:
							insert_char(input, cursor_pos, ' ');
							update_cursor = 1;
							cursor_pos++;
							update_textbox(input, screen);
							break;
					}
					
					dont_autofill = 1;
				} else if (key != '\0' && key != '\n') {
					switch (highlighted) {
						case ON:
							if (cursor_pos < highlight_cursor) {
								current_char = cursor_pos;
								while (current_char != highlight_cursor) {
									delete_char(input, cursor_pos+1);
									current_char++;
								}
							} else {
								current_char = highlight_cursor;
								while (current_char != cursor_pos) {
									delete_char(input, highlight_cursor+1);
									current_char++;
								}
								cursor_pos = highlight_cursor;
							}
							
							insert_char(input, cursor_pos, key);
							cursor_pos++;							
							update_cursor = 1;
							update_textbox(input, screen);
							highlighted = OFF;
							break;
						case OFF:
							insert_char(input, cursor_pos, key);
							update_cursor = 1;
							cursor_pos++;
							update_textbox(input, screen);
							break;
					}
					
					dont_autofill = 0;
				} else if (key == '\n' || key == '\0') {
					dont_autofill = 1;
				}
			
				if (key) {
					if (shift)
						highlight_key(keyboard_layout_shift, key, ON, screen);
					else
						highlight_key(keyboard_layout, key, ON, screen);
				}
				while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
				if (key) {
					if (shift)
						highlight_key(keyboard_layout_shift, key, OFF, screen);
					else
						highlight_key(keyboard_layout, key, OFF, screen);
				}
			}
		}

		// Shift key
		if (KEY_SHIFT && !shift) {
			clear_keyboard(screen);
			print_keyboard(keyboard_layout_shift, screen);
			update_cancel_button(SCREEN_WIDTH - ((string_width(language.get("keyboard_cancel"), strlen(language.get("keyboard_cancel"))) + 10)) - 10, 167, (string_width(language.get("keyboard_cancel"), strlen(language.get("keyboard_cancel"))) + 10), screen);
			shift = 1;
		}
		if (!KEY_SHIFT && shift) {
			clear_keyboard(screen);
			print_keyboard(keyboard_layout, screen);
			update_cancel_button(SCREEN_WIDTH - ((string_width(language.get("keyboard_cancel"), strlen(language.get("keyboard_cancel"))) + 10)) - 10, 167, (string_width(language.get("keyboard_cancel"), strlen(language.get("keyboard_cancel"))) + 10), screen);
			shift = 0;
		}

		// Cursor keys
		if (CURSOR_LEFT) {
			highlighted = OFF;
			if (cursor_pos > 0) cursor_pos--;
			update_cursor = 1;
			update_textbox(input, screen);
			while (CURSOR_LEFT) { scanKeys(); swiWaitForVBlank(); }
			dont_autofill = 1;
		}
		if (CURSOR_RIGHT) {
			highlighted = OFF;
			if (cursor_pos < strlen(input)) cursor_pos++;
			update_cursor = 1;
			update_textbox(input, screen);
			while (CURSOR_RIGHT) { scanKeys(); swiWaitForVBlank(); }
			dont_autofill = 1;
		}
		if (CURSOR_HOME) { // "home" key
			highlighted = OFF;
			cursor_pos = 0;
			update_cursor = 1;
			update_textbox(input, screen);
			while (CURSOR_HOME) { scanKeys(); swiWaitForVBlank(); }
			dont_autofill = 1;
		}
		if (CURSOR_END) { // "end" key
			highlighted = OFF;
			cursor_pos = strlen(input);
			update_cursor = 1;
			update_textbox(input, screen);
			while (CURSOR_END) { scanKeys(); swiWaitForVBlank(); }
			dont_autofill = 1;
		}
		
		// Clipboard functions
		if (KEY_COPY) {
			if (highlighted) {
				clipboard_copy(input, cursor_pos, highlight_cursor);
				while (KEY_COPY) { scanKeys(); swiWaitForVBlank(); }
			}
			dont_autofill = 1;
		}
		if (KEY_CUT) {
			if (highlighted) {
				clipboard_copy(input, cursor_pos, highlight_cursor);
				while (KEY_CUT) { scanKeys(); swiWaitForVBlank(); }
				
				// Erase highlighted text
				if (cursor_pos < highlight_cursor) {
					current_char = cursor_pos;
					while (current_char != highlight_cursor) {
						delete_char(input, cursor_pos+1);
						current_char++;
					}
				} else {
					current_char = highlight_cursor;
					while (current_char != cursor_pos) {
						delete_char(input, highlight_cursor+1);
						current_char++;
					}
					cursor_pos = highlight_cursor;
				}
				
				update_cursor = 1;
				update_textbox(input, screen);
				highlighted = OFF;
			}
			dont_autofill = 1;
		}
		if (KEY_PASTE) {
			if (highlighted) {
				// Erase highlighted text
				if (cursor_pos < highlight_cursor) {
					current_char = cursor_pos;
					while (current_char != highlight_cursor) {
						delete_char(input, cursor_pos+1);
						current_char++;
					}
				} else {
					current_char = highlight_cursor;
					while (current_char != cursor_pos) {
						delete_char(input, highlight_cursor+1);
						current_char++;
					}
					cursor_pos = highlight_cursor;
				}
			
				cursor_pos = clipboard_paste(input, cursor_pos);
				update_cursor = 1;
				update_textbox(input, screen);
				highlighted = OFF;
				while (KEY_PASTE) { scanKeys(); swiWaitForVBlank(); }
			} else {
				cursor_pos = clipboard_paste(input, cursor_pos);
				update_cursor = 1;
				update_textbox(input, screen);
				while (KEY_PASTE) { scanKeys(); swiWaitForVBlank(); }
			}
			dont_autofill = 1;
		}
		
		// Shortcut keys
		if (KEY_ENTER) {
			key = '\n';
			if (shift) {
				highlight_key(keyboard_layout_shift, key, ON, screen);
				while (KEY_ENTER) { scanKeys(); swiWaitForVBlank(); }
				highlight_key(keyboard_layout_shift, key, OFF, screen);
			} else {
				highlight_key(keyboard_layout, key, ON, screen);
				while (KEY_ENTER) { scanKeys(); swiWaitForVBlank(); }
				highlight_key(keyboard_layout, key, OFF, screen);
			}
			dont_autofill = 1;
		}
		if (KEY_BACKSPACE) {
			key = '\b';
			
			switch (highlighted) {
				case ON:
					if (cursor_pos < highlight_cursor) {
						current_char = cursor_pos;
						while (current_char != highlight_cursor) {
							delete_char(input, cursor_pos+1);
							current_char++;
						}
					} else {
						current_char = highlight_cursor;
						while (current_char != cursor_pos) {
							delete_char(input, highlight_cursor+1);
							current_char++;
						}
						cursor_pos = highlight_cursor;
					}
					
					update_cursor = 1;
					update_textbox(input, screen);
					highlighted = OFF;
					break;
				case OFF:
					delete_char(input, cursor_pos);
					if (cursor_pos > 0) cursor_pos--;
					update_cursor = 1;
					update_textbox(input, screen);
					break;
			}
			
			if (shift) {
				highlight_key(keyboard_layout_shift, key, ON, screen);
				while (KEY_BACKSPACE) { scanKeys(); swiWaitForVBlank(); }
				highlight_key(keyboard_layout_shift, key, OFF, screen);
			} else {
				highlight_key(keyboard_layout, key, ON, screen);
				while (KEY_BACKSPACE) { scanKeys(); swiWaitForVBlank(); }
				highlight_key(keyboard_layout, key, OFF, screen);
			}
			
			dont_autofill = 1;
		}

		// Auto-fill
		if (strlen(autofill) != 0) {
			length = strlen(input);
			if (length > 0 && !dont_autofill) {
				autofill_test[0] = '/';
				autofill_test[1] = '\0';
				strcat(autofill_test, input);
				autofill_start_slash = stripos(autofill, autofill_test);
				if (autofill_start_slash != -1) {
					autofill_end_slash = strpos(autofill, "/", autofill_start_slash+1);
					strcpy(input, substr(autofill, autofill_start_slash+1, autofill_end_slash-1));
					clear_textbox(screen);
					dont_autofill = 1;
					highlighted = ON;
					highlight_cursor = strlen(input);
					print_string_highlighted(input, TEXTBOX_LEFT_X+2, TEXTBOX_Y+6, screen, cursor_pos, highlight_cursor);
				}
			}
		}

		// Update the flashing cursor (unless something is highlighted)
		if (!highlighted) {
			i = 0;
			if (vblank_count == 1 || update_cursor == 1) {
				cursor_x = string_width(input, cursor_pos) + (TEXTBOX_LEFT_X+2);
				for (i = TEXTBOX_Y + 2; i < TEXTBOX_Y + TEXTBOX_HEIGHT - 2; i++)
					screen[cursor_x + i * 256] = RGB15(0,0,0) | BIT(15); // black
				update_cursor = 0;
			} else if (vblank_count == 30) {
				cursor_x = string_width(input, cursor_pos) + (TEXTBOX_LEFT_X+2);
				for (i = TEXTBOX_Y + 2; i < TEXTBOX_Y + TEXTBOX_HEIGHT - 2; i++)
					screen[cursor_x + i * 256] = RGB15(31,31,31) | BIT(15); // white
			}
		}
		
		if (vblank_count == 45) {
			vblank_count = 0;
		}

		swiWaitForVBlank();
		vblank_count++;
	}
	
	clear_textbox(screen);
	strcpy(string, input);
	
	return OK;
}

void update_textbox(char *string, u16 *screen) {
	clear_textbox(screen);
	print_string_xy(string, TEXTBOX_LEFT_X+2, TEXTBOX_Y+6, screen);
}

void delete_char(char *string, u8 cursor) {
	int i = 0, j = 0;
	while (string[i] != '\0')
		i++;
	i++;
	for (j = cursor-1; j < i; j++)
		string[j] = string[j+1];
	string[i] = '\0';
}

void insert_char(char *string, u8 cursor, char key) {
	int i = 0, j = 0;
	while (string[i] != '\0')
		i++;
	i++;
	for (j = i; j > cursor; j--)
		string[j] = string[j-1];
	string[cursor] = key;
}

void clear_textbox(u16 *screen) {
	u8 x, y;
	for (y = TEXTBOX_Y+1; y < TEXTBOX_Y+TEXTBOX_HEIGHT; y++)
		for (x = TEXTBOX_LEFT_X+1; x < TEXTBOX_RIGHT_X-1; x++)
			screen[x + y * 256] = RGB15(31,31,31) | BIT(15); // white
}

void print_keyboard(char *layout, u16 *screen) {
	u8 current_char = 0, i = 0;
	u16 put_x = KEYBOARD_X, put_y = KEYBOARD_Y;
	
	// Print all the keys in layout
	while (layout[current_char] != '\0') {
		if (layout[current_char] == '\\') {
			put_x = KEYBOARD_X;
			put_y += 19;
		} else if (layout[current_char] == '\n') {
			print_key(put_x, put_y, intval(language.get("enter_key_width")), layout[current_char], screen);
			put_x += intval(language.get("enter_key_width"));
		} else if (layout[current_char] == '\t') {
			print_key(put_x, put_y, SPACE_BAR_WIDTH, layout[current_char], screen);
			put_x += SPACE_BAR_WIDTH;
		} else if (layout[current_char] == ' ') {
			put_x += 10;
		} else {
			print_key(put_x, put_y, 20, layout[current_char], screen);
			put_x += 19;
		}
		
		current_char++;
	}
	
	// Print textbox where characters are echoed
	for (i = TEXTBOX_LEFT_X; i <= TEXTBOX_RIGHT_X; i++) {
		screen[i + TEXTBOX_Y * 256] = RGB15(0, 0, 0) | BIT(15);
		screen[i + (TEXTBOX_Y+TEXTBOX_HEIGHT) * 256] = RGB15(0, 0, 0) | BIT(15);
	}
	for (i = TEXTBOX_Y; i <= TEXTBOX_Y+TEXTBOX_HEIGHT; i++) {
		screen[TEXTBOX_LEFT_X + i * 256] = RGB15(0, 0, 0) | BIT(15);
		screen[TEXTBOX_RIGHT_X + i * 256] = RGB15(0, 0, 0) | BIT(15);
	}
}

void print_key(u8 x, u8 y, u8 width, char key, u16 *screen) {
	u8 i, put_x, put_y;
	
	// First make the border (just a box)
	for (i = x; i < x+width; i++) {
		screen[i + y * 256] = RGB15(0, 0, 0) | BIT(15); // grey
		screen[i + (y+19) * 256] = RGB15(0, 0, 0) | BIT(15); // grey
	}
	for (i = y; i < y+20; i++) {
		screen[x + i * 256] = RGB15(0, 0, 0) | BIT(15); // grey
		screen[(x+width-1) + i * 256] = RGB15(0, 0, 0) | BIT(15); // grey
	}
	
	for (put_x = x + 1; put_x < x + width - 1; put_x++) {
		for (put_y = y + 1; put_y < y + 19; put_y++) {
			screen[put_x + put_y * SCREEN_WIDTH] = RGB15(31, 30, 29) | BIT(15);
		}
	}
	
	// Now print the char
	switch (key) {
		case '\n':
			print_string_xy(language.get("keyboard_enter"), x+5, y+4, screen);
			break;
		case 1:
			print_string_xy(language.get("keyboard_cancel"), x+((width - string_width(language.get("keyboard_cancel"), strlen(language.get("keyboard_cancel")))) / 2), y + 4, screen);
			break;
		default:
			print_char(key, x+(width/2-font_widths[(int)key]/2), y+3, screen);
	}
}

bool update_cancel_button(u8 x, u8 y, u8 width, u16 *screen) {
	u8 i, put_x, put_y;
	touchPosition stylus;
	bool is_touched;
	u16 color;
	
	scanKeys();
	stylus = touchReadXY();
	
	if ((keysHeld() & KEY_TOUCH) && stylus.px >= x && stylus.px <= x + width && stylus.py >= y && stylus.py <= y + 20) {
		color = RGB15(31, 15, 0) | BIT(15);
		is_touched = true;
	} else {
		color = RGB15(31, 30, 29) | BIT(15);
		is_touched = false;
	}
	
	// First make the border (just a box)
	for (i = x; i < x+width; i++) {
		screen[i + y * 256] = RGB15(0, 0, 0) | BIT(15);
		screen[i + (y+19) * 256] = RGB15(0, 0, 0) | BIT(15);
	}
	for (i = y; i < y+20; i++) {
		screen[x + i * 256] = RGB15(0, 0, 0) | BIT(15);
		screen[(x+width-1) + i * 256] = RGB15(0, 0, 0) | BIT(15);
	}
	
	for (put_x = x + 1; put_x < x + width - 1; put_x++) {
		for (put_y = y + 1; put_y < y + 19; put_y++) {
			screen[put_x + put_y * SCREEN_WIDTH] = color;
		}
	}

	print_string_xy(language.get("keyboard_cancel"), x+((width - (string_width(language.get("keyboard_cancel"), strlen(language.get("keyboard_cancel"))) + 10)) / 2) + 5, y + 4, screen, RGB15(0, 0, 0) | BIT(15), 0);
	
	return is_touched;
}

void get_key_xy(char *layout, char key, u8 *x, u8 *y, u8 *width) {
	u32 current_char = 0;
	u16 current_width = KEYBOARD_X, current_height = KEYBOARD_Y;
	
	// First, store the width
	switch (key) {
		case '\n':
			*width = intval(language.get("enter_key_width"));
			break;
		case '\t':
			*width = SPACE_BAR_WIDTH;
			break;
		default:
			*width = 20;
			break;
	}
	
	while (layout[current_char] != key && layout[current_char] != '\0') {
		if (layout[current_char] == '\\') {
			current_width = KEYBOARD_X;
			current_height += 19;
		} else if (layout[current_char] == '\n') {
			current_width += intval(language.get("enter_key_width"));
		} else if (layout[current_char] == '\t') {
			current_width += SPACE_BAR_WIDTH;
		} else if (layout[current_char] == ' ') {
			current_width += 10;
		} else {
			current_width += 19;
		}

		current_char++;
	}
	
	*x = current_width;
	*y = current_height;
}

char get_key(char *layout, u16 stylus_x, u16 stylus_y) {
	u8 key_found = 0;
	u16 i;
	u8 x, y, width;
	char key = '\0';
	
	for (i = 8; i < 256 && !key_found; i++) {
		get_key_xy(layout, i, &x, &y, &width);
		
		if (stylus_x > x && stylus_x < x+width && stylus_y > y && stylus_y < y+20 && i != '\\' && i != ' ') {
			key_found = 1;
			key = i;
		}
	}
	
	if ((!key_found || font_widths[(int)key] == 0) && key != '\n') {
		return '\0';
	} else {
		return key;
	}
}

void highlight_key(char *layout, char key, u8 on_off, u16 *screen) {
	u8 x, y, width, put_x, put_y;
	u16 colour;

	get_key_xy(layout, key, &x, &y, &width);
	
	switch (on_off) {
		case ON:
			colour = RGB15(31, 15, 0) | BIT(15);
			break;
		case OFF:
			colour = RGB15(31, 30, 29) | BIT(15);
			break;
	}
	
	for (put_x = x + 1; put_x < x + width - 1; put_x++) {
		for (put_y = y + 1; put_y < y + 19; put_y++) {
			screen[put_x + put_y * SCREEN_WIDTH] = colour;
		}
	}
	
	// Now print the char
	switch (key) {
		case '\n':
			print_string_xy(language.get("keyboard_enter"), x+5, y+4, screen, RGB15(0, 0, 0) | BIT(15), 0);
			break;
		case 1:
			print_string_xy(language.get("keyboard_cancel"), x+((width - (string_width(language.get("keyboard_cancel"), strlen(language.get("keyboard_cancel"))) + 10)) / 2), y + 4, screen, RGB15(0, 0, 0) | BIT(15), 0);
			break;
		default:
			print_char(key, x+(width/2-font_widths[(int)key]/2), y+3, screen, RGB15(0, 0, 0) | BIT(15));
	}
}

u16 stylus2cursor(u8 stylus_x, char *string) {
	u8 width = TEXTBOX_LEFT_X;
	u16 current_char = 0;
	
	// Get the char that the stylus is touching
	while (width < stylus_x && string[current_char] != '\0') {
		width += font_widths[(int)string[current_char]];
		width += SPACE_BETWEEN_CHARS;
		current_char++;
	}
	width -= SPACE_BETWEEN_CHARS;
	current_char--;
	
	// Are they touching to the left or right of the center of the char?
	if (stylus_x < width - (font_widths[(int)string[current_char]]/2))
		return current_char;
	else
		return current_char+1;
}

void clear_keyboard(u16 *screen) {
	u16 put_x, put_y;
	
	for (put_y = KEYBOARD_Y; put_y < SCREEN_HEIGHT; put_y++)
		for (put_x = KEYBOARD_X; put_x < SCREEN_WIDTH; put_x++)
			screen[put_x + put_y * 256] = RGB15(31,31,31) | BIT(15); // white
}

void clipboard_copy(char *string, u16 start, u16 end) {
	u16 current_char, current_char2 = 0;
	
	if (start < end) {
		current_char = start;
		while (current_char != end) {
			clipboard[current_char2] = string[current_char];
			current_char++;
			current_char2++;
		}
	} else {
		current_char = end;
		while (current_char != start) {
			clipboard[current_char2] = string[current_char];
			current_char++;
			current_char2++;
		}
	}
	
	clipboard[current_char2] = '\0';
}

u16 clipboard_paste(char *string, u16 pos) {
	u16 current_char = 0, position = pos;
	
	while (current_char != strlen(clipboard)) {
		insert_char(string, position, clipboard[current_char]);
		current_char++;
		position++;
	}
	
	return position;
}
