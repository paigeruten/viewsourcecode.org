#include <nds.h>
#include "progressbar.h"

const u16 progress_bar_colours_orange[16] = {
	RGB15(31, 24, 19) | BIT(15),
	RGB15(31, 23, 18) | BIT(15),
	RGB15(31, 22, 17) | BIT(15),
	RGB15(31, 22, 16) | BIT(15),
	RGB15(31, 21, 15) | BIT(15),
	RGB15(31, 21, 14) | BIT(15),
	RGB15(31, 20, 13) | BIT(15),
	RGB15(31, 19, 12) | BIT(15),
	RGB15(31, 14, 3) | BIT(15),
	RGB15(31, 14, 3) | BIT(15),
	RGB15(31, 14, 3) | BIT(15),
	RGB15(31, 14, 3) | BIT(15),
	RGB15(31, 17, 7) | BIT(15),
	RGB15(31, 22, 16) | BIT(15),
	RGB15(31, 20, 12) | BIT(15),
	RGB15(31, 16, 6) | BIT(15)
};

const u16 progress_bar_colours_white[16] = {
	RGB15(30, 30, 30) | BIT(15),
	RGB15(30, 30, 29) | BIT(15),
	RGB15(30, 30, 29) | BIT(15),
	RGB15(30, 30, 29) | BIT(15),
	RGB15(30, 29, 29) | BIT(15),
	RGB15(30, 29, 29) | BIT(15),
	RGB15(30, 29, 29) | BIT(15),
	RGB15(29, 28, 27) | BIT(15),
	RGB15(29, 28, 28) | BIT(15),
	RGB15(29, 28, 28) | BIT(15),
	RGB15(29, 28, 28) | BIT(15),
	RGB15(29, 29, 28) | BIT(15),
	RGB15(30, 29, 29) | BIT(15),
	RGB15(29, 29, 29) | BIT(15),
	RGB15(29, 29, 28) | BIT(15),
	RGB15(30, 30, 30) | BIT(15)
};

void draw_progressbar_box(u16 *screen) {
	u8 i;

	// Draw percentage box
	for (i = 27; i <= 228; i++) {
		screen[i + 79 * SCREEN_WIDTH] = RGB15(14, 13, 12) | BIT(15);
		screen[i + 96 * SCREEN_WIDTH] = RGB15(14, 13, 12) | BIT(15);
	}
	for (i = 79; i <= 96; i++) {
		screen[27 + i * SCREEN_WIDTH] = RGB15(14, 13, 12) | BIT(15);
		screen[228 + i * SCREEN_WIDTH] = RGB15(14, 13, 12) | BIT(15);
	}
	
	// Make corners of percentage box look rounded
	screen[27 + 79 * SCREEN_WIDTH] = RGB15(25, 24, 24) | BIT(15);  // Top-left corner
	screen[27 + 96 * SCREEN_WIDTH] = RGB15(25, 24, 24) | BIT(15);  // Bottom-left corner
	screen[228 + 79 * SCREEN_WIDTH] = RGB15(25, 24, 24) | BIT(15); // Top-right corner
	screen[228 + 96 * SCREEN_WIDTH] = RGB15(25, 24, 24) | BIT(15); // Bottom-right corner
	
	// Top-left corner
	screen[28 + 79 * SCREEN_WIDTH] = RGB15(16, 15, 13) | BIT(15);
	screen[27 + 80 * SCREEN_WIDTH] = RGB15(16, 15, 13) | BIT(15);
	
	// Bottom-left corner
	screen[27 + 95 * SCREEN_WIDTH] = RGB15(16, 15, 13) | BIT(15);
	screen[28 + 96 * SCREEN_WIDTH] = RGB15(16, 15, 13) | BIT(15);
	
	// Top-right corner
	screen[227 + 79 * SCREEN_WIDTH] = RGB15(16, 15, 13) | BIT(15);
	screen[228 + 80 * SCREEN_WIDTH] = RGB15(16, 15, 13) | BIT(15);
	
	// Bottom-right corner
	screen[227 + 96 * SCREEN_WIDTH] = RGB15(16, 15, 13) | BIT(15);
	screen[228 + 95 * SCREEN_WIDTH] = RGB15(16, 15, 13) | BIT(15);
	
	update_progressbar(screen, 0);
}

void update_progressbar(u16 *screen, u8 progress) {
	u16 put_x, put_y, i;

	for (put_x = 28; put_x < (progress*2)+28; put_x++) {
		i = 0;
		for (put_y = 80; put_y < 96; put_y++) {
			screen[put_x + put_y * SCREEN_WIDTH] = progress_bar_colours_orange[i];
			i++;
		}
	}
	
	for (put_x = 227; put_x >= (progress*2)+28; put_x--) {
		i = 0;
		for (put_y = 80; put_y < 96; put_y++) {
			screen[put_x + put_y * SCREEN_WIDTH] = progress_bar_colours_white[i];
			i++;
		}
	}
}

