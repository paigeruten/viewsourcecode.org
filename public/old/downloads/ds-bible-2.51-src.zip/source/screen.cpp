#include <nds.h>
#include <string.h>
#include "screen.h"

u16 *screens[4] = {
	(u16*)BG_BMP_RAM_SUB(0), // screens[SCREEN_BOTTOM]
	(u16*)BG_BMP_RAM(0),     // screens[SCREEN_TOP]
	NULL,
	NULL
};

void init_screens(void) {
	// Main screen turn on
	videoSetMode(MODE_5_2D | DISPLAY_BG3_ACTIVE | DISPLAY_SPR_ACTIVE | DISPLAY_SPR_1D);
	vramSetBankA(VRAM_A_MAIN_BG_0x06000000);
	BACKGROUND.control[3] = BG_BMP16_256x256 | BG_BMP_BASE(0);
	BACKGROUND.bg3_rotation.xdy = 0;
	BACKGROUND.bg3_rotation.xdx = 1 << 8;
	BACKGROUND.bg3_rotation.ydx = 0;
	BACKGROUND.bg3_rotation.ydy = 1 << 8;
	
	// Sub screen
	videoSetModeSub(MODE_5_2D | DISPLAY_BG3_ACTIVE);
	vramSetBankC(VRAM_C_SUB_BG_0x06200000);
	BACKGROUND_SUB.control[3] = BG_BMP16_256x256 | BG_BMP_BASE(0);
	BACKGROUND_SUB.bg3_rotation.xdy = 0;
	BACKGROUND_SUB.bg3_rotation.xdx = 1 << 8;
	BACKGROUND_SUB.bg3_rotation.ydx = 0;
	BACKGROUND_SUB.bg3_rotation.ydy = 1 << 8;
	
	// Screen buffers
	screens[BUFFER_BOTTOM] = new u16 [SCREEN_WIDTH * SCREEN_HEIGHT];
	screens[BUFFER_TOP] = new u16 [SCREEN_WIDTH * SCREEN_HEIGHT];
}

void clear_screen(u8 r, u8 g, u8 b, u16 *screen) {
	u16 i;
	for (i = 0; i < SCREEN_WIDTH*SCREEN_HEIGHT; i++) {
		screen[i] = RGB15(r, g, b) | BIT(15);
	}
}

void clear_screens(u16 *screen1, u16 *screen2, u16 colour) {
	for (u16 i = 0; i < SCREEN_WIDTH * SCREEN_HEIGHT; i++) {
		screen1[i] = colour;
		screen2[i] = colour;
	}
}

void draw_box(u8 x, u8 y, u8 x2, u8 y2, u16 colour, u16 *screen, bool fill) {
	u8 put_x, put_y;

	if (fill) {
		for (put_x = x; put_x <= x2; put_x++) {
			for (put_y = y; put_y <= y2; put_y++) {
				screen[put_x + put_y * SCREEN_WIDTH] = colour;
			}
		}
	} else {
		for (put_x = x; put_x <= x2; put_x++) {
			screen[put_x + y * SCREEN_WIDTH] = colour;
			screen[put_x + y2 * SCREEN_WIDTH] = colour;
		}
		
		for (put_y = y; put_y <= y2; put_y++) {
			screen[x + put_y * SCREEN_WIDTH] = colour;
			screen[x2 + put_y * SCREEN_WIDTH] = colour;
		}
	}
}

void darken_screen(u16 *screen) {
	u16 i, pixel;
	
	swiWaitForVBlank();
	for (i = 0; i < SCREEN_WIDTH * SCREEN_HEIGHT; i++) {
		pixel = screen[i];
		screen[i] = ((pixel & 0x1F) >> 1) | ((((pixel >> 5) & 0x1F) >> 1) << 5) | ((((pixel >> 10) & 0x1F) >> 1) << 10) | (1 << 15);
	}
}

void lighten_screen(u16 *screen) {
	u16 i, pixel;
	
	for (i = 0; i < SCREEN_WIDTH * SCREEN_HEIGHT; i++) {
		pixel = screen[i];
		screen[i] = ((pixel & 0x1F) << 1) | ((((pixel >> 5) & 0x1F) << 1) << 5) | ((((pixel >> 10) & 0x1F) << 1) << 10);
	}
}

void shift_right_packed(u16 *number, u8 start_bit, u8 end_bit) {
	u8 i;
	
	for (i = start_bit; i < end_bit; i++) {
		if (*number & BIT(i + 1)) {
			*number |= BIT(i);
		} else {
			*number &= ~BIT(i);
		}
	}
	
	*number &= ~BIT(end_bit);
}

void scrcpy(u16 *dest, const u16 *source) {
	memcpy(dest, source, SCREEN_WIDTH * SCREEN_HEIGHT * 2);
}

