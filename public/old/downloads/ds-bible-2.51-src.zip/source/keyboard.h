#ifndef _keyboard_h
#define _keyboard_h

enum KeyboardStatus { OK, CANCEL };

// Colours
#define HIGHLIGHT_COLOUR RGB15(31,31,31)
#define HIGHLIGHT_BGCOLOUR RGB15(0,0,0)

// Buttons
#define CURSOR_LEFT (keysHeld() & KEY_LEFT)
#define CURSOR_RIGHT (keysHeld() & KEY_RIGHT)
#define CURSOR_HOME (keysHeld() & KEY_UP)
#define CURSOR_END (keysHeld() & KEY_DOWN)
#define KEY_SHIFT ((keysHeld() & KEY_L) || (keysHeld() & KEY_R))
#define KEY_ENTER (keysHeld() & KEY_A)
#define KEY_BACKSPACE (keysHeld() & KEY_B)
#define KEY_CUT (keysHeld() & KEY_X)
#define KEY_COPY (keysHeld() & KEY_SELECT)
#define KEY_PASTE (keysHeld() & KEY_START)

#define SPACE_BAR_WIDTH 120

// Coordinates of where to start printing keyboard (also, each row of keys starts printing at KEYBOARD_X
#define KEYBOARD_X 5
#define KEYBOARD_Y 60

// Size and position of textbox (where the string being entered on the keyboard is echoed.)
#define TEXTBOX_WIDTH 200
#define TEXTBOX_HEIGHT 24
#define TEXTBOX_Y 20

// Center the textbox
#define TEXTBOX_LEFT_X (127-(TEXTBOX_WIDTH/2))
#define TEXTBOX_RIGHT_X (127+(TEXTBOX_WIDTH/2))

// Wait for user to enter a string into the keyboard and press enter. String gets stored in string.
KeyboardStatus keyboard_string(char *string, u16 *screen, char *autofill = "", char *keyboard_layout = NULL, char *keyboard_layout_shift = NULL);

// Print keyboard to screen
void print_keyboard(char *layout, u16 *screen);

// Print a single key
void print_key(u8 x, u8 y, u8 width, char key, u16 *screen);

// Draws a cancel button and returns true if it's being touched by the stylus.
bool update_cancel_button(u8 x, u8 y, u8 width, u16 *screen);

// Store x, y coordinates and width of a key into *key_x and *key_y
void get_key_xy(char *layout, char key, u8 *x, u8 *y, u8 *width);

// Get char that is being pressed on keyboard
char get_key(char *layout, u16 stylus_x, u16 stylus_y);

// Draws a different-coloured border around a key (like to show that it's being pressed)
void highlight_key(char *layout, char key, u8 on_off, u16 *screen);

// Print string to textbox
void update_textbox(char *string, u16 *screen);

// Insert a char anywhere in a string
void insert_char(char *string, u8 cursor, char key);

// Clear the textbox
void clear_textbox(u16 *screen);

// Deletes a char anywhere in the string
void delete_char(char *string, u8 cursor);

// Returns the position in the string where the stylus is touching in the textbox
u16 stylus2cursor(u8 stylus_x, char *string);

// Erase the keyboard (not the whole screen or textbox)
void clear_keyboard(u16 *screen);

// Clipboard functions
void clipboard_copy(char *string, u16 start, u16 end);
u16 clipboard_paste(char *string, u16 pos);

#endif
