#include <nds.h>
#include <string.h>
#include "str.h"

s32 strpos(const char *haystack, const char *needle, u32 offset) {
	u32 current_char = offset;
	
	while (haystack[current_char] != '\0') {
		if (haystack[current_char] == needle[0]) {
			if (!strcmp(needle, substr(haystack, current_char, current_char+strlen(needle)-1))) {
				return current_char;
			}
		}
		current_char++;
	}
	
	return -1;
}

s32 stripos(const char *haystack, const char *needle, u32 offset) {
	u32 current_char = offset;
	char *haystack_lower;
	char *needle_lower;
	
	haystack_lower = new char [2048];
	needle_lower = new char [2048];
	
	strcpy(needle_lower, needle);
	strtolower(needle_lower);
	
	while (haystack[current_char] != '\0') {
		if (haystack[current_char] == needle[0] || haystack[current_char] + 32 == needle[0] || haystack[current_char] - 32 == needle[0]) {
			strcpy(haystack_lower, substr(haystack, current_char, current_char + strlen(needle) - 1));
			strtolower(haystack_lower);
			
			if (!strcmp(needle_lower, haystack_lower)) {
				delete [] haystack_lower;
				delete [] needle_lower;
				
				return current_char;
			}
		}
		current_char++;
	}
	
	delete [] haystack_lower;
	delete [] needle_lower;
	
	return -1;
}

s32 strrpos(const char *haystack, const char *needle, u32 offset) {
	u32 current_char = offset;
	
	while (current_char != 0) {
		if (!strcmp(needle, substr(haystack, current_char, current_char+strlen(needle)-1))) {
			return current_char;
		}
		current_char--;
	}
	
	if (!strcmp(needle, substr(haystack, current_char, current_char+strlen(needle)-1))) {
		return current_char;
	}
	
	return -1;
}

s32 strripos(const char *haystack, const char *needle, u32 offset) {
	u32 current_char = offset;
	char haystack_lower[2048], needle_lower[2048];
	
	strcpy(haystack_lower, haystack);
	strcpy(needle_lower, needle);
	strtolower(haystack_lower);
	strtolower(needle_lower);
	
	while (current_char != 0) {
		if (!strcmp(needle_lower, substr(haystack_lower, current_char, current_char+strlen(needle_lower)-1))) {
			return current_char;
		}
		current_char--;
	}
	
	if (!strcmp(needle_lower, substr(haystack_lower, current_char, current_char+strlen(needle_lower)-1))) {
		return current_char;
	}
	
	return -1;
}

char *substr(const char *string, u32 start, u32 end) {
	u32 current_char, current_char2 = 0;
	static char substring[2048];
	
	for (current_char = start; current_char <= end && string[current_char] != '\0'; current_char++) {
		substring[current_char2] = string[current_char];
		current_char2++;
	}
	
	substring[current_char2] = '\0';
	
	return substring;
}

void strtolower(char *string) {
	u32 current_char = 0;
		
	while (string[current_char] != '\0') {
		if ((string[current_char] >= 65 && string[current_char] <= 90) || (string[current_char] >= 192 && string[current_char] <= 220)) {
			string[current_char] += 32;
		}
		current_char++;
	}
}

u32 str_count(const char *string, char character) {
	u32 current_char = 0, count = 0;
	
	while (string[current_char] != '\0') {
		if (string[current_char] == character) {
			count++;
		}
		current_char++;
	}
	
	return count;
}

u32 intval(char *string) {
	u32 num = 0, current_char = 0;

	while (string[current_char] != '\0') {
		num *= 10;
		num += (int)string[current_char] - 48;
		current_char++;
	}
	
	return num;
}

char *strval(u32 num) {
	char numstring[10] = "";
	u32 number = num, quotient = 1, remainder = 0;
	char remainder_str[3] = "";
	u32 current_char = 0, current_char2 = 0;
	static char string[100];
	
	if (number == 0) {
		strcpy(string, "0");
	} else {
		while (quotient != 0) {
			remainder = number % 10;
			quotient = number / 10;
			remainder_str[0] = remainder+48;
			remainder_str[1] = '\0';
			strcat(numstring, remainder_str);
			number = quotient;
		}
		
		current_char = strlen(numstring)-1;
		while (current_char != 0) {
			string[current_char2] = numstring[current_char];
			current_char--;
			current_char2++;
		}
		string[current_char2] = numstring[current_char];
		string[current_char2 + 1] = '\0';
	}
	
	return string;
}

char *superscript(char *string) {
	u8 current_char = 0;
	static char return_string[10];
	
	strcpy(return_string, string);
	
	while (return_string[current_char] != '\0') {
		return_string[current_char] += 120;
		current_char++;
	}
	
	return return_string;
}

void chop(char *string) {
	string[strlen(string)-1] = '\0';
}

