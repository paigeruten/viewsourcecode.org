#ifndef _button_h
#define _button_h

class Button {
	public:
		// Constructors
		Button(char *the_text, u16 *the_screen, u8 x_pos, u8 y_pos, Image *button_img, Image *button_pressed_img);
		~Button();

		// Check if the button is pressed and highlight/unhighlight it (redraws the button)
		bool check(u8 stylus_x, u8 stylus_y);
		
		// Toggle is_highlighted if button was just pressed
		void toggle_check(u8 stylus_x, u8 stylus_y);

		// Draw button to screen
		void draw();

		// Accessors
		void set_text(char *new_text);
		char *get_text() { return text; }
		void set_xy(u8 new_x, u8 new_y) { x = new_x; y = new_y; }
		u8 get_x() const { return x; }
		u8 get_y() const { return y; }
		void set_dimensions(u8 new_width, u8 new_height) { width = new_width; height = new_height; }
		u8 get_width() const { return width; }
		u8 get_height() const { return height; }
		bool highlighted() const { return is_highlighted; }
	private:
		u16 *screen;
		char text[255];
		Image *button_image;
		Image *button_pressed_image;
		u8 x;
		u8 y;
		u8 width;
		u8 height;
		bool is_highlighted;
};

#endif
