#ifndef _browse_h
#define _browse_h

// Takes a list of strings (one string with many substrings seperated by a single character delimiter) and returns one string that the user selected.
char *select(char *the_options, u16 *screen, char delimiter = '/', bool show_cancel=true);

// Returns the <pos>th substring.
char *option2string(char *options, u16 pos, char delimiter);

// Prints an option
void print_option(u16 color, char *text, u8 pos, u16 *screen, u8 margin_right);

// Updates the option list
void update_option_list(char *options, u16 pos, s16 highlighted, u16 *screen, char delimiter, u8 margin_right);

// Erases everything inside the scrollbar and redraws the rectangle at y=pos
void draw_scrollbar(u8 pos, u16 *screen, u16 color);

#endif
