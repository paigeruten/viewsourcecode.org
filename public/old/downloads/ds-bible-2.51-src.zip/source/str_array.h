#ifndef _str_array_h
#define _str_array_h

// Return number of strings in array
u16 count(const char *array);

// Remove element from array
void array_remove(char *array, char *element);

// Returns the string at a certain index: a[i] == array_index(a, i)
char *array_index(const char *array, u8 index);

// Returns the index of the element in the array
u8 get_array_index(const char *array, const char *element);

// Check if a string is inside a str_array
bool in_array(const char *needle, const char *haystack);

#endif
