#ifndef _selectbox_h
#define _selectbox_h

class Selectbox {
	public:
		// Constructors
		Selectbox(u16 *the_screen, u8 the_x, u8 the_y, u8 the_width, u8 the_height, Image *the_selectbox_img, Image *the_selectbox_pressed_img, Image *the_selector_img, Image *the_select_scroll_img, Image *the_select_scroll_disabled_img, char *the_options, char *the_selected_option);
		~Selectbox();
		
		// Accessors
		void set_options(char *new_options) { strcpy(options, new_options); }
		void set_selected_option(char *new_selected_option) { strcpy(selected_option, new_selected_option); }
		char *get_selected_option() { return selected_option; }
		void set_xy(u8 new_x, u8 new_y) { x = new_x; y = new_y; }
		u8 get_x() const { return x; }
		u8 get_y() const { return y; }
		void set_dimensions(u8 new_width, u8 new_height) { width = new_width; height = new_height; }
		u8 get_width() const { return width; }
		u8 get_height() const { return height; }
		
		// Methods
		void draw_button();
		void draw_button_pressed();
		void draw_select_box();
		u8 update(u8 stylus_x, u8 stylus_y);
	private:
		u16 *screen;
		Image *selectbox_img;
		Image *selectbox_pressed_img;
		Image *selector_img;
		Image *select_scroll_img;
		Image *select_scroll_disabled_img;
		char options[512];
		char selected_option[64];
		u8 scroll_pos;
		u8 x;
		u8 y;
		u8 width;
		u8 height;
		bool select_box_opened;
};

#endif

