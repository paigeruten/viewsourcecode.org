#include <nds.h>
#include <string.h>
#include "font.h"
#include "fontdata.h"
#include "str.h"

extern u8 font_widths[256];
extern u8 font[256][FONT_HEIGHT][FONT_WIDTH];

void print_char(char character, u8 x, u8 y, u16 *screen, u16 color, u16 bgcolor) {
	u16 put_y, put_x;
	u16 right_edge = x + font_widths[(int)character];
	u16 bottom_edge = y + FONT_HEIGHT;
	
	for (put_y = y; put_y < bottom_edge; put_y++) {
		for (put_x = x; put_x < right_edge; put_x++) {
			switch (font[character][put_y - y][put_x - x]) {
				case 1:
					screen[put_x + put_y * SCREEN_WIDTH] = color;
					break;
				case 0:
					if (bgcolor != 0) { screen[put_x + put_y * SCREEN_WIDTH] = bgcolor; }
					break;
			}
		}
	}
	
	// Fill in space to the right of the char if there's a solid background colour.
	if (bgcolor != 0) {
		for (put_y = y; put_y <= bottom_edge - 1; put_y++) {
			for (put_x = x + font_widths[(int)character]; put_x < right_edge + SPACE_BETWEEN_CHARS; put_x++) {
				screen[put_x + put_y * SCREEN_WIDTH] = bgcolor;
			}
		}
	}
}

void print_string_xy(const char *string, u8 x, u8 y, u16 *screen, u16 color, u16 bgcolor) {
	u16 put_x = x, put_y = y;
	u32 current_char = 0;
	
	while (string[current_char] != '\0') {
		print_char(string[current_char], put_x, put_y, screen, color, bgcolor);
		put_x += SPACE_BETWEEN_CHARS + font_widths[(int)string[current_char]];		
		current_char++;
		
		if (put_x > 250) {
			break;
		}
	}
}

void print_string_highlighted(char *string, u8 x, u8 y, u16 *screen, u16 highlight_start, u16 highlight_end, u16 color, u16 bgcolor, u16 highlight_color, u16 highlight_bgcolor) {
	u16 put_x = x, put_y = y, line_y, line_x;
	u32 current_char = 0;
	
	while (string[current_char] != '\0') {
		if ((highlight_start < highlight_end && current_char >= highlight_start && current_char < highlight_end) || (highlight_start > highlight_end && current_char < highlight_start && current_char >= highlight_end))
			print_char(string[current_char], put_x, put_y, screen, highlight_color, highlight_bgcolor);
		else
			print_char(string[current_char], put_x, put_y, screen, color, bgcolor);
		
		put_x += font_widths[(int)string[current_char]];
		
		// Fill in space between chars
		if ((highlight_start < highlight_end && current_char >= highlight_start && current_char < highlight_end) || (highlight_start > highlight_end && current_char < highlight_start && current_char >= highlight_end)) {
			for (line_y = put_y; line_y <= put_y+FONT_HEIGHT-1; line_y++) {
				for (line_x = put_x; line_x < put_x+SPACE_BETWEEN_CHARS; line_x++) {
					screen[line_x + line_y * SCREEN_WIDTH] = highlight_bgcolor;
				}
			}
		}
		
		put_x += SPACE_BETWEEN_CHARS;		
		current_char++;
	}
}

void print_string_center(char *string, u8 y, u16 *screen, u16 color, u16 bgcolor) {
	u16 put_x = 127 - string_width(string, strlen(string)-1)/2, put_y = y;
	u32 current_char = 0;
	
	while (string[current_char] != '\0') {
		print_char(string[current_char], put_x, put_y, screen, color, bgcolor);
		put_x += SPACE_BETWEEN_CHARS + font_widths[(int)string[current_char]];		
		current_char++;
	}
}

void print_number(u32 num, u8 x, u8 y, u16 *screen, u16 color, u16 bgcolor) {
	print_string_xy(strval(num), x, y, screen, color, bgcolor);
}

u32 string_width(char *string, u8 length) {
	u32 i = 0, c = 0;
	
	while (c != length) {
		i += font_widths[(int)string[c]];
		i += SPACE_BETWEEN_CHARS;
		c++;
	}
	i--;
	
	return i;
}

void draw_alert_box(char *string, u16 *screen) {
	u16 width_string = string_width(string, strlen(string));
	u16 x = (SCREEN_WIDTH - width_string) / 2, y = 74;
	u16 put_x, put_y;
	
	for (put_x = x - 11; put_x <= x + width_string + 11; put_x++) {
		for (put_y = y - 1; put_y <= y + 31; put_y++) {
			screen[put_x + put_y * SCREEN_WIDTH] = RGB15(31, 31, 31) | BIT(15);
		}
	}
	
	for (put_x = x - 10; put_x <= x + width_string + 10; put_x++) {
		screen[put_x + y * SCREEN_WIDTH] = RGB15(31, 15, 0) | BIT(15);
		screen[put_x + (y + 30) * SCREEN_WIDTH] = RGB15(31, 15, 0) | BIT(15);
	}
	
	for (put_y = y; put_y <= y + 30; put_y++) {
		screen[(x - 10) + put_y * SCREEN_WIDTH] = RGB15(31, 15, 0) | BIT(15);
		screen[(x + width_string + 10) + put_y * SCREEN_WIDTH] = RGB15(31, 15, 0) | BIT(15);
	}
	
	print_string_xy(string, x, y + 8, screen);
}

