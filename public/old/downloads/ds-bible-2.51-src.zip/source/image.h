#ifndef _image_h
#define _image_h

class Image {
	public:
		// Constructors
		Image(u16 *the_screen, char *filename);
		~Image();
		
		// Accessors
		u16 get_width() const { return width; }
		u16 get_height() const { return height; }
		
		// Methods
		void draw(u16 x, u16 y) const;
		void draw_flipped(u16 x, u16 y) const;
		void erase(u16 x, u16 y, u16 color) const;
	private:
		u16 *screen;
		u16 width;
		u16 height;
		u16 *data;
};

#endif

