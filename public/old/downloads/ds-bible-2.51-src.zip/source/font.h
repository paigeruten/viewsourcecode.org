#ifndef _font_h
#define _font_h

// Print character to screen
void print_char(char character, u8 x, u8 y, u16 *screen, u16 color = RGB15(0, 0, 0) | BIT(15), u16 bgcolor = 0);

// Print string on single line starting at (x, y)
void print_string_xy(const char *string, u8 x, u8 y, u16 *screen, u16 color = RGB15(0, 0, 0) | BIT(15), u16 bgcolor = 0);

// Print string and highlight part of it (from highlight_start to highlight_end)
void print_string_highlighted(char *string, u8 x, u8 y, u16 *screen, u16 highlight_start, u16 highlight_end, u16 color = RGB15(0, 0, 0) | BIT(15), u16 bgcolor = RGB15(31, 31, 31) | BIT(15), u16 highlight_color = RGB15(31, 31, 31) | BIT(15), u16 highlight_bgcolor = RGB15(0, 0, 0) | BIT(15));

// Print string in center of screen
void print_string_center(char *string, u8 y, u16 *screen, u16 color = RGB15(0, 0, 0) | BIT(15), u16 bgcolor = 0);

// Prints num to the screen (converts it to a string first)
void print_number(u32 num, u8 x, u8 y, u16 *screen, u16 color = RGB15(0, 0, 0) | BIT(15), u16 bgcolor = 0);

// Returns the width of string if it were printed on the screen (length is where it stops counting the width (it doesn't check for '\0'))
u32 string_width(char *string, u8 length);

// Draws a box in the center of the screen and puts text into it.
void draw_alert_box(char *string, u16 *screen);

// Whitespace
#define SPACE_BETWEEN_CHARS 2
#define SPACE_BETWEEN_LINES 1
#define MARGIN_SIDES 15
#define MARGIN_MAIN_TOP 26
#define MARGIN_MAIN_BOTTOM 3
#define MARGIN_SUB_TOP 6
#define MARGIN_SUB_BOTTOM 17

// For switches
#define ON 1
#define OFF 0

#endif
