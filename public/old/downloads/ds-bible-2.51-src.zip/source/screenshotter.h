#ifndef _screenshotter_h
#define _screenshotter_h

void screenshotter();

#endif

