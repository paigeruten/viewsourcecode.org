#include <nds.h>
#include <fat.h>
#include <stdio.h>
#include <string.h>
#include "browse.h"
#include "str.h"
#include "font.h"
#include "screen.h"
#include "screenshotter.h"
#include "str_array.h"
#include "assoc_array.h"

extern u16 *screens[4];
extern AssocArray language;

char *select(char *the_options, u16 *screen, char delimiter, bool show_cancel) {
	s16 selected = 0, clicked = -1, touched;
	u16 position = 0, last_pos, num_of_options, vblank_count;
	static char selected_option[128];
	char options[4096];
	touchPosition stylus;
	u8 i, scroll_pos = 0, margin_right;
	
	if (show_cancel) {
		strcpy(options, language.get("cancel"));
		
		if (strlen(the_options)) {
			strcat(options, "/");
		}
		
		strcat(options, the_options);
	} else {
		strcpy(options, the_options);
	}
	
	num_of_options = str_count(options, delimiter)+1;
	
	if (num_of_options > 7) {
		margin_right = 240;
	} else {
		margin_right = 255;
	}
	
	update_option_list(options, position, selected, screen, delimiter, margin_right);
	
	if (num_of_options > 7) {
		// Draw scrollbar box
		for (i = 242; i <= 254; i++) {
			screen[i + 1 * SCREEN_WIDTH] = RGB15(15, 15, 15) | BIT(15);
			screen[i + 190 * SCREEN_WIDTH] = RGB15(15, 15, 15) | BIT(15);
		}
		for (i = 1; i <= 190; i++) {
			screen[242 + i * SCREEN_WIDTH] = RGB15(15, 15, 15) | BIT(15);
			screen[254 + i * SCREEN_WIDTH] = RGB15(15, 15, 15) | BIT(15);
		}
		
		draw_scrollbar(scroll_pos, screen, RGB15(0, 0, 0) | BIT(15));
	}
	
	while (clicked == -1) {
		scanKeys();
		stylus = touchReadXY();
		
		screenshotter();
		
		if (keysHeld() & KEY_DOWN && selected < num_of_options-1) {
			for (vblank_count = 0; vblank_count < 7; vblank_count++) { swiWaitForVBlank(); }
			selected++;
			if (selected == position+7) {
				position++;
				scroll_pos = 155*position / (num_of_options-7);
			}
			update_option_list(options, position, selected, screen, delimiter, margin_right);
			if (num_of_options > 7) { draw_scrollbar(scroll_pos, screen, RGB15(0, 0, 0) | BIT(15)); }
		}
		
		if (keysHeld() & KEY_UP && selected > 0) {
			for (vblank_count = 0; vblank_count < 7; vblank_count++) { swiWaitForVBlank(); }
			selected--;
			if (selected == position-1) {
				position--;
				scroll_pos = 155*position / (num_of_options-7);
			}
			update_option_list(options, position, selected, screen, delimiter, margin_right);
			if (num_of_options > 7) { draw_scrollbar(scroll_pos, screen, RGB15(0, 0, 0) | BIT(15)); }		
		}
		
		if (keysHeld() & KEY_A) {
			while (keysHeld() & KEY_A) { scanKeys(); swiWaitForVBlank(); }
			clicked = selected;
		}
		
		if (keysHeld() & KEY_TOUCH) {
			if (stylus.px <= 240) {
				touched = stylus.py/27 + position;
				if (touched < num_of_options) {
					if (touched == selected) {
						clicked = selected;
						while (keysHeld() & KEY_TOUCH) { scanKeys(); swiWaitForVBlank(); }
					} else {
						while (keysHeld() & KEY_TOUCH) {
							scanKeys();
							stylus = touchReadXY();
							
							touched = stylus.py/27 + position;
							
							if (keysHeld() & KEY_TOUCH && touched != selected && touched < num_of_options && stylus.px <= 240) {
								selected = touched;
								update_option_list(options, position, selected, screen, delimiter, margin_right);
								
								if (num_of_options > 7) {
									draw_scrollbar(scroll_pos, screen, RGB15(0, 0, 0) | BIT(15));
								}
							}
							
							swiWaitForVBlank();
						}
					}
				}
			} else if (stylus.px >= 244 && stylus.px <= 252 && stylus.py >= scroll_pos+3 && stylus.py <= scroll_pos+3+30 && num_of_options > 7) {
				while (keysHeld() & KEY_TOUCH) {
					scanKeys();
					stylus = touchReadXY();
					
					if (keysHeld() & KEY_TOUCH) {
						scroll_pos = stylus.py-18;
					}
					
					if (keysHeld() & KEY_TOUCH && stylus.py <= 17) { scroll_pos = 0; }
					if (keysHeld() & KEY_TOUCH && stylus.py > 172) { scroll_pos = 155; }
					
					last_pos = position;
					position = (num_of_options-7)*scroll_pos/155;
					
					if (position != last_pos) {
						update_option_list(options, position, selected, screen, delimiter, margin_right);
					}
					
					draw_scrollbar(scroll_pos, screen, RGB15(31, 15, 0) | BIT(15));
					
					swiWaitForVBlank();
				}
				draw_scrollbar(scroll_pos, screen, RGB15(0, 0, 0) | BIT(15));
			}
		}
		
		swiWaitForVBlank();
	}
	
	strcpy(selected_option, option2string(options, clicked, delimiter));
	return selected_option;
}

void print_option(u16 color, char *text, u8 pos, u16 *screen, u8 margin_right) {
	u8 y = pos*27;
	u16 put_x, put_y, current_color = 0, y_rel;
	
	if (color != 0) {
		for (put_x = 0; put_x <= margin_right; put_x++) {
			for (put_y = y; put_y <= y+27; put_y++) {
				screen[put_x + put_y * SCREEN_WIDTH] = color | BIT(15);
			}
		}
	} else {
		for (put_y = y; put_y <= y+27; put_y++) {
			y_rel = put_y-y;
			
			if (y_rel >= 1 && y_rel <= 20) {
				current_color = RGB15(31, 25, 16);
			} else if (y_rel >= 21 && y_rel <= 26) {
				current_color = RGB15(31, 25, 15);
			} else if (y_rel == 0) {
				current_color = RGB15(31, 26, 19);
			} else if (y_rel == 27) {
				current_color = RGB15(31, 24, 14);
			}
			
			for (put_x = 0; put_x <= margin_right; put_x++) {
				screen[put_x + put_y * SCREEN_WIDTH] = current_color | BIT(15);
			}
		}
		
	}
	
	print_string_xy(text, 10, y+6, screen, RGB15(9, 9, 9) | BIT(15));
}

void update_option_list(char *options, u16 pos, s16 highlighted, u16 *screen, char delimiter, u8 margin_right) {
	u16 i;
	s32 starting_slash = -1, ending_slash;
	u8 row = 0;
	char delimiter_str[2];
	
	clear_screen(31, 31, 31, screens[BUFFER_BOTTOM]);
	
	if (count(options) > 7) {
		// Draw scrollbar box
		for (i = 242; i <= 254; i++) {
			screens[BUFFER_BOTTOM][i + 1 * SCREEN_WIDTH] = RGB15(15, 15, 15) | BIT(15);
			screens[BUFFER_BOTTOM][i + 190 * SCREEN_WIDTH] = RGB15(15, 15, 15) | BIT(15);
		}
		for (i = 1; i <= 190; i++) {
			screens[BUFFER_BOTTOM][242 + i * SCREEN_WIDTH] = RGB15(15, 15, 15) | BIT(15);
			screens[BUFFER_BOTTOM][254 + i * SCREEN_WIDTH] = RGB15(15, 15, 15) | BIT(15);
		}
	}
	
	delimiter_str[0] = delimiter;
	delimiter_str[1] = '\0';
	
	// Get first slash's position
	for (i = 0; i < pos; i++) {
		starting_slash = strpos(options, delimiter_str, starting_slash+1);
	}
	
	for (i = 0; i < 7; i++) {
		ending_slash = strpos(options, delimiter_str, starting_slash+1);
		
		if (starting_slash != -1 || i == 0) {
			if (highlighted == pos+i) {
				print_option(0, substr(options, starting_slash+1, ending_slash-1), i, screens[BUFFER_BOTTOM], margin_right);
			} else if (!row) {
				print_option(RGB15(29, 29, 28), substr(options, starting_slash+1, ending_slash-1), i, screens[BUFFER_BOTTOM], margin_right);
			} else {
				print_option(RGB15(29, 28, 27), substr(options, starting_slash+1, ending_slash-1), i, screens[BUFFER_BOTTOM], margin_right);
			}
		
			row = ~row;
			starting_slash = ending_slash;
		}
	}
	
	scrcpy(screen, screens[BUFFER_BOTTOM]);
}

char *option2string(char *options, u16 pos, char delimiter) {
	static char return_string[128];
	u16 i;
	s32 starting_slash = -1, ending_slash;
	char delimiter_str[2];
	
	delimiter_str[0] = delimiter;
	delimiter_str[1] = '\0';
	
	// Get first slash's position
	for (i = 0; i < pos; i++) {
		starting_slash = strpos(options, delimiter_str, starting_slash+1);
	}
	
	ending_slash = strpos(options, delimiter_str, starting_slash+1);
	
	strcpy(return_string, substr(options, starting_slash+1, ending_slash-1));
	
	return return_string;
}

void draw_scrollbar(u8 pos, u16 *screen, u16 color) {
	u8 put_x, put_y;
	
	// Erase old rectangle
	for (put_x = 244; put_x <= 252; put_x++) {
		for (put_y = 3; put_y <= 189; put_y++) {
			screen[put_x + put_y * SCREEN_WIDTH] = RGB15(31, 31, 31) | BIT(15);
		}
	}
	
	for (put_x = 244; put_x <= 252; put_x++) {
		for (put_y = pos+3; put_y <= pos+3+30; put_y++) {
			screen[put_x + put_y * SCREEN_WIDTH] = color;
		}
	}
}

