#include <nds.h>
#include <string.h>
#include "screen.h"
#include "font.h"
#include "image.h"
#include "selectbox.h"
#include "str.h"
#include "str_array.h"
#include "screenshotter.h"

extern u16 *screens[4];

Selectbox::Selectbox(u16 *the_screen, u8 the_x, u8 the_y, u8 the_width, u8 the_height, Image *the_selectbox_img, Image *the_selectbox_pressed_img, Image *the_selector_img, Image *the_select_scroll_img, Image *the_select_scroll_disabled_img, char *the_options, char *the_selected_option) {
	screen = the_screen;
	x = the_x;
	y = the_y;
	width = the_width;
	height = the_height;
	selectbox_img = the_selectbox_img;
	selectbox_pressed_img = the_selectbox_pressed_img;
	selector_img = the_selector_img;
	select_scroll_img = the_select_scroll_img;
	select_scroll_disabled_img = the_select_scroll_disabled_img;
	strcpy(options, the_options);
	strcpy(selected_option, the_selected_option);
	scroll_pos = 0;
}

Selectbox::~Selectbox() {
}

void Selectbox::draw_button() {
	selectbox_img->draw(x, y);
	print_string_xy(selected_option, x + 10, y + 9, screen);
}

void Selectbox::draw_button_pressed() {
	selectbox_pressed_img->draw(x, y);
	print_string_xy(selected_option, x + 10, y + 9, screen);
}

void Selectbox::draw_select_box() {
	u8 box_x = x, box_y = y + height, box_x2 = x + width, box_y2;
	u8 num_options, current_option, number_of_options;
	char current_option_str[256];

	scrcpy(screens[BUFFER_TOP], screen);

	number_of_options = count(options);
	if (number_of_options > 3) { number_of_options = 3; }

	box_y2 = y + height + height*number_of_options + select_scroll_img->get_height() * 2 + 4;

	draw_box(box_x, box_y, box_x2, box_y2, RGB15(21, 20, 18) | BIT(15), screens[BUFFER_TOP], false);
	draw_box(box_x+1, box_y+1, box_x2-1, box_y2-1, RGB15(30, 30, 30) | BIT(15), screens[BUFFER_TOP], true);
	
	if (scroll_pos == 0) {
		select_scroll_disabled_img->draw(box_x + 2, box_y + 2);
	} else {
		select_scroll_img->draw(box_x + 2, box_y + 2);
	}
	
	if (count(options) > scroll_pos + 3) {
		select_scroll_img->draw_flipped(box_x + 2, box_y2 - select_scroll_img->get_height() - 2);
	} else {
		select_scroll_disabled_img->draw_flipped(box_x + 2, box_y2 - select_scroll_disabled_img->get_height() - 2);
	}
	
	// Loop through options, printing them
	num_options = count(options);
	
	for (current_option = scroll_pos; current_option < num_options && current_option - scroll_pos < 3; current_option++) {
		strcpy(current_option_str, array_index(options, current_option));
		
		if (!strcmp(current_option_str, selected_option)) {
			selector_img->draw(box_x + 2, box_y + (current_option - scroll_pos)*height + 3 + select_scroll_img->get_height());
		}
		
		print_string_xy(current_option_str, box_x + 10, box_y + (current_option - scroll_pos)*height + 9 + select_scroll_img->get_height(), screens[BUFFER_TOP]);
	}
	
	scrcpy(screen, screens[BUFFER_TOP]);
}

u8 Selectbox::update(u8 stylus_x, u8 stylus_y) {
	touchPosition stylus;
	u8 num_options = count(options), current_option, num_of_options;
	char current_option_str[256];
	u8 vblank_count;
	
	num_of_options = count(options);
	if (num_of_options > 3) { num_of_options = 3; }
	
	scanKeys();
	
	// Check if stylus is touching the select box.
	if (stylus_x >= x && stylus_x <= x+width && stylus_y >= y && stylus_y <= y+height && keysHeld() & KEY_TOUCH) {
		scrcpy(screens[BUFFER_BOTTOM], screen);
	
		draw_button_pressed();
		draw_select_box();
		
		while (keysHeld() & KEY_TOUCH) {
			swiWaitForVBlank();
			scanKeys();
			stylus = touchReadXY();
			
			screenshotter();
			
			// Loop through options, check if stylus is touching them			
			for (current_option = scroll_pos; current_option < num_options && current_option < scroll_pos + 3; current_option++) {
				strcpy(current_option_str, array_index(options, current_option));
				
				if (stylus.px >= 5 && stylus.px <= 251 && stylus.py > y + height + (current_option - scroll_pos)*height + 3 + select_scroll_img->get_height() && stylus.py < y + height*2 + (current_option - scroll_pos)*height + 3 + select_scroll_img->get_height() && strcmp(current_option_str, selected_option)) {
					strcpy(selected_option, current_option_str);
					draw_select_box();
				}
			}
			
			vblank_count = 0;
			while ((keysHeld() & KEY_TOUCH) && stylus.px >= 5 && stylus.px <= 251 && stylus.py > y + height && stylus.py < y + height + select_scroll_img->get_height()) {
				scanKeys();
				stylus = touchReadXY();
				
				if (vblank_count == 0 && scroll_pos > 0) {
					scroll_pos--;
					draw_select_box();
				}
				
				swiWaitForVBlank();
				vblank_count++;
				if (vblank_count == 5) { vblank_count = 0; }
			}
			
			vblank_count = 0;
			while ((keysHeld() & KEY_TOUCH) && stylus.px >= 5 && stylus.px <= 251 && stylus.py > y + height + num_of_options*height + select_scroll_img->get_height() + 4 && stylus.py < y + height + num_of_options*height + 3 + select_scroll_img->get_height()*2) {
				scanKeys();
				stylus = touchReadXY();
				
				if (vblank_count == 0 && scroll_pos + 3 < count(options)) {
					scroll_pos++;
					draw_select_box();
				}
				
				swiWaitForVBlank();
				vblank_count++;
				if (vblank_count == 5) { vblank_count = 0; }
			}
		}
		
		scrcpy(screen, screens[BUFFER_BOTTOM]);
		
		return 1;
	}
	
	return 0;
}

