#include <nds.h>
#include <math.h>
#include "distance.h"

float distance(s32 x1, s32 y1, s32 x2, s32 y2) {
	s32 dx = x2 - x1;
	s32 dy = y2 - y1;

	return sqrt(dx*dx + dy*dy);
}
