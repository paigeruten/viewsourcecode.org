#include <nds.h>
#include "font.h"

u8 font_N[FONT_WIDTH * FONT_HEIGHT] = {
	1,0,0,0,0,0,0,1,
	1,1,0,0,0,0,0,1,
	1,0,1,0,0,0,0,1,
	1,0,0,1,0,0,0,1,
	1,0,0,0,1,0,0,1,
	1,0,0,0,0,1,0,1,
	1,0,0,0,0,0,1,1,
	1,0,0,0,0,0,0,1
};

u8 font_E[FONT_WIDTH * FONT_HEIGHT] = {
	1,1,1,1,1,1,1,1,
	1,0,0,0,0,0,0,0,
	1,0,0,0,0,0,0,0,
	1,1,1,1,1,1,1,1,
	1,0,0,0,0,0,0,0,
	1,0,0,0,0,0,0,0,
	1,0,0,0,0,0,0,0,
	1,1,1,1,1,1,1,1
};

u8 font_S[FONT_WIDTH * FONT_HEIGHT] = {
	0,1,1,1,1,1,1,1,
	1,0,0,0,0,0,0,0,
	1,0,0,0,0,0,0,0,
	0,1,1,1,1,1,1,0,
	0,0,0,0,0,0,0,1,
	0,0,0,0,0,0,0,1,
	0,0,0,0,0,0,0,1,
	1,1,1,1,1,1,1,0
};

u8 font_W[FONT_WIDTH * FONT_HEIGHT] = {
	1,0,0,0,0,0,0,1,
	1,0,0,0,0,0,0,1,
	1,0,0,0,0,0,0,1,
	1,0,0,0,0,0,0,1,
	1,0,0,0,0,0,0,1,
	1,0,0,1,1,0,0,1,
	1,0,0,1,1,0,0,1,
	0,1,1,0,0,1,1,0
};

void print_string(const char *string, u32 x, u32 y) {
	u32 put_x = x;

	for (u8 current_char = 0; string[current_char]; current_char++) {
		print_char(string[current_char], put_x, y);
		put_x += 9;
	}
}

void print_char(char ch, u32 x, u32 y) {
	u8 *char_data = 0;

	switch (ch) {
		case 'N':
			char_data = font_N;
			break;

		case 'E':
			char_data = font_E;
			break;

		case 'S':
			char_data = font_S;
			break;

		case 'W':
			char_data = font_W;
			break;

		default:
			char_data = font_N;
	}

	u32 put_x = x;
	for (u8 get_x = 0; get_x < FONT_WIDTH; get_x++) {
		u32 put_y = y;
		for (u8 get_y = 0; get_y < FONT_HEIGHT; get_y++) {
			if (char_data[get_x + get_y * FONT_WIDTH]) {
				screen_top.plot(put_x, put_y, RGB(0, 0, 0));
			}
			put_y++;
		}
		put_x++;
	}
}

