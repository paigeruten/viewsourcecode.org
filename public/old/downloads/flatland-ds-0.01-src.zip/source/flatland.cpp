#include <nds.h>
#include <math.h>
#include "flatland.h"

Flatland::Flatland() {
	world = new u8 [WORLD_WIDTH * WORLD_HEIGHT];

	for (u32 i = 0; i < WORLD_WIDTH * WORLD_HEIGHT; i++) {
		world[i] = 0;
	}

	x.set_int(WORLD_WIDTH / 2);
	y.set_int(WORLD_HEIGHT / 2);
	direction = 0;
}

Flatland::~Flatland() {
	delete [] world;
	world = 0;
}

void Flatland::go() {
	screen_top.rect((SCREEN_WIDTH - (VISION_WIDTH * 2)) / 2 - 1, 89, (SCREEN_WIDTH - (VISION_WIDTH * 2)) / 2 + (VISION_WIDTH * 2) + 1, 101, RGB(31, 0, 0), RECT_OUTLINE);

	screen_top.rect((SCREEN_WIDTH - (VISION_WIDTH * 2)) / 2 - 1, 80, (SCREEN_WIDTH - (VISION_WIDTH * 2)) / 2 - 1, 85, RGB(0, 31, 0), RECT_FILLED);
	screen_top.rect((SCREEN_WIDTH - (VISION_WIDTH * 2)) / 2 + (VISION_WIDTH / 2), 80, (SCREEN_WIDTH - (VISION_WIDTH * 2)) / 2  + (VISION_WIDTH / 2), 85, RGB(0, 31, 0), RECT_FILLED);
	screen_top.rect(127, 80, 127, 85, RGB(0, 0, 31), RECT_FILLED);
	screen_top.rect((SCREEN_WIDTH - (VISION_WIDTH * 2)) / 2 + VISION_WIDTH + (VISION_WIDTH / 2), 80, (SCREEN_WIDTH - (VISION_WIDTH * 2)) / 2 + VISION_WIDTH + (VISION_WIDTH / 2), 85, RGB(0, 31, 0), RECT_FILLED);
	screen_top.rect((SCREEN_WIDTH - (VISION_WIDTH * 2)) / 2 + (VISION_WIDTH * 2), 80, (SCREEN_WIDTH - (VISION_WIDTH * 2)) / 2 + (VISION_WIDTH * 2), 85, RGB(0, 31, 0), RECT_FILLED);

	touchPosition stylus, last_stylus;
	bool touched_last = false;
	while (true) {
		scanKeys();
		last_stylus = stylus;
		stylus = touchReadXY();

		if (keysHeld() & KEY_TOUCH) {
			if (touched_last) {
				draw_line(stylus, last_stylus);
			} else {
				world[stylus.px + stylus.py * WORLD_WIDTH] = 1;
				world[(stylus.px + 1) + stylus.py * WORLD_WIDTH] = 1;
				world[(stylus.px + 1) + (stylus.py + 1) * WORLD_WIDTH] = 1;
				world[stylus.px + (stylus.py + 1) * WORLD_WIDTH] = 1;

				screen_bottom.plot(stylus.px, stylus.py, RGB(0, 0, 0));
				screen_bottom.plot(stylus.px + 1, stylus.py, RGB(0, 0, 0));
				screen_bottom.plot(stylus.px, stylus.py + 1, RGB(0, 0, 0));
				screen_bottom.plot(stylus.px + 1, stylus.py + 1, RGB(0, 0, 0));
			}

			cast();

			touched_last = true;
		} else {
			touched_last = false;
		}

		if (keysHeld() & (KEY_UP | KEY_DOWN | KEY_LEFT | KEY_RIGHT)) {
			screen_bottom.plot(x.get_int(), y.get_int(), world[x.get_int() + y.get_int() * WORLD_WIDTH] ? RGB(0, 0, 0) : RGB(31, 31, 31));

			s32 old_x = x.get_fixed();
			s32 old_y = y.get_fixed();

			if (keysHeld() & KEY_UP) {
				x.set_float(x.get_float() + cos(direction * (PI / 180)));
				y.set_float(y.get_float() + sin(direction * (PI / 180)));
			}

			if (keysHeld() & KEY_DOWN) {
				x.set_float(x.get_float() - cos(direction * (PI / 180)));
				y.set_float(y.get_float() - sin(direction * (PI / 180)));
			}

			if (world[x.get_int() + y.get_int() * WORLD_WIDTH]) {
				x.set_fixed(old_x);
				y.set_fixed(old_y);
			}

			if (keysHeld() & KEY_LEFT) {
				direction -= 4;
			}

			if (keysHeld() & KEY_RIGHT) {
				direction += 4;
			}

			screen_bottom.plot(x.get_int(), y.get_int(), RGB(31, 0, 0));

			cast();
		}

		swiWaitForVBlank();
	}
}

void Flatland::cast() {
	s16 low_angle = direction - VISION_WIDTH;
	s16 high_angle = direction + VISION_WIDTH;

	u16 put_x = (SCREEN_WIDTH - (VISION_WIDTH * 2)) / 2;

	screen_top.rect(put_x - 8, 105, SCREEN_WIDTH - put_x + 9, 114, RGB(31, 31, 31), RECT_FILLED);

	for (s16 current_angle = low_angle; current_angle <= high_angle; current_angle++) {
		FixedPoint8 current_x;
		FixedPoint8 current_y;
		FixedPoint8 delta_x;
		FixedPoint8 delta_y;

		current_x.set_fixed(x.get_fixed());
		current_y.set_fixed(y.get_fixed());

		delta_x.set_float(cos(current_angle * (PI / 180.0)));
		delta_y.set_float(sin(current_angle * (PI / 180.0)));

		bool ray_went_off_world = false;
		while (true) {
			if (world[current_x.get_int() + current_y.get_int() * WORLD_WIDTH]) {
				break;
			}

			if (current_x.get_int() < 0 || current_x.get_int() >= WORLD_WIDTH || current_y.get_int() < 0 || current_y.get_int() >= WORLD_HEIGHT) {
				ray_went_off_world = true;
				break;
			}

			current_x.set_fixed(current_x.get_fixed() + delta_x.get_fixed());
			current_y.set_fixed(current_y.get_fixed() + delta_y.get_fixed());
		}

		Color color;

		if (ray_went_off_world) {
			color = RGB(31, 31, 31);
		} else {
			FixedPoint8 dist;
			dist.set_float(distance(x.get_int(), y.get_int(), current_x.get_int(), current_y.get_int()));

			if (dist.get_int() > 63) {
				color = RGB(28, 28, 28);
			} else {
				color = RGB(dist.get_int() / 2, dist.get_int() / 2, dist.get_int() / 2);
			}
		}

		screen_top.rect(put_x, 90, put_x, 100, color, RECT_FILLED);

		s16 positive_angle = current_angle;

		if (positive_angle >= 360) {
			positive_angle -= 360;
		}

		if (positive_angle < 0) {
			positive_angle += 360;
		}

		switch (positive_angle) {
			case 0:
				print_string("E", put_x - 4, 105);
				break;

			case 45:
				print_string("SE", put_x - 8, 105);
				break;

			case 90:
				print_string("S", put_x - 4, 105);
				break;

			case 135:
				print_string("SW", put_x - 8, 105);
				break;

			case 180:
				print_string("W", put_x - 4, 105);
				break;

			case 225:
				print_string("NW", put_x - 8, 105);
				break;

			case 270:
				print_string("N", put_x - 4, 105);
				break;

			case 315:
				print_string("NE", put_x - 8, 105);
				break;
		}

		put_x++;
	}
}

void Flatland::draw_line(touchPosition stylus, touchPosition last_stylus) {	
	s32 dx = stylus.px - last_stylus.px;
	s32 dy = stylus.py - last_stylus.py;
	s32 dxabs = dx;
	s32 sdx = 1;
	
	if (dx < 0) {
		dxabs = -dx;
		sdx = -1;
	}

	s32 dyabs = dy;
	s32 sdy = 1;
	
	if (dy < 0) {
		dyabs = -dy;
		sdy = -1;
	}

	s32 x = dyabs / 2;
	s32 y = dxabs / 2;
	s32 px = last_stylus.px;
	s32 py = last_stylus.py;

	screen_bottom.plot(px, py, RGB(0, 0, 0));
	screen_bottom.plot(px + 1, py, RGB(0, 0, 0));
	screen_bottom.plot(px, py + 1, RGB(0, 0, 0));
	screen_bottom.plot(px + 1, py + 1, RGB(0, 0, 0));

	world[px + py * WORLD_WIDTH] = 1;
	world[(px + 1) + py * WORLD_WIDTH] = 1;
	world[px + (py + 1) * WORLD_WIDTH] = 1;
	world[(px + 1) + (py + 1) * WORLD_WIDTH] = 1;

	if (dxabs >= dyabs) {
		for (s32 i = 0; i < dxabs; i++) {
			y += dyabs;
			
			if (y >= dxabs) {
				y -= dxabs;
				py += sdy;
			}
			
			px += sdx;

			screen_bottom.plot(px, py, RGB(0, 0, 0));
			screen_bottom.plot(px + 1, py, RGB(0, 0, 0));
			screen_bottom.plot(px, py + 1, RGB(0, 0, 0));
			screen_bottom.plot(px + 1, py + 1, RGB(0, 0, 0));

			world[px + py * WORLD_WIDTH] = 1;
			world[(px + 1) + py * WORLD_WIDTH] = 1;
			world[px + (py + 1) * WORLD_WIDTH] = 1;
			world[(px + 1) + (py + 1) * WORLD_WIDTH] = 1;
		}
	} else {
		for (s32 i = 0; i < dyabs; i++) {
			x += dxabs;
			
			if (x >= dyabs) {
				x -= dyabs;
				px += sdx;
			}

			py += sdy;

			screen_bottom.plot(px, py, RGB(0, 0, 0));
			screen_bottom.plot(px + 1, py, RGB(0, 0, 0));
			screen_bottom.plot(px, py + 1, RGB(0, 0, 0));
			screen_bottom.plot(px + 1, py + 1, RGB(0, 0, 0));

			world[px + py * WORLD_WIDTH] = 1;
			world[(px + 1) + py * WORLD_WIDTH] = 1;
			world[px + (py + 1) * WORLD_WIDTH] = 1;
			world[(px + 1) + (py + 1) * WORLD_WIDTH] = 1;
		}
	}
}

