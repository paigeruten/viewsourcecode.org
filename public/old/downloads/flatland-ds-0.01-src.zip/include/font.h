#ifndef _font_h
#define _font_h

#include "canvas.h"

const u8 FONT_WIDTH = 8;
const u8 FONT_HEIGHT = 8;

void print_string(const char *string, u32 x, u32 y);
void print_char(char ch, u32 x, u32 y);

#endif

