#ifndef _distance_h
#define _distance_h

float distance(s32 x1, s32 y1, s32 x2, s32 y2);

#endif

