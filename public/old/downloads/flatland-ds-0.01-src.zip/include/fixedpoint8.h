#ifndef _fixedpoint8_h
#define _fixedpoint8_h

class FixedPoint8 {
	public:
		// Constructors
		FixedPoint8() { value = 0; }
		FixedPoint8(u32 int_value) { set_int(int_value); }
		FixedPoint8(float float_value) { set_float(float_value); }

		// Accessors
		u32 get_fixed() const { return value; }
		void set_fixed(u32 new_value) { value = new_value; }
		u32 get_int() const { return value >> 8; }
		void set_int(u32 new_value) { value = new_value << 8; }
		float get_float() const { return value / 256.0; }
		void set_float(float new_value) { value = new_value * 256; }

	private:
		s32 value;
};

#endif
