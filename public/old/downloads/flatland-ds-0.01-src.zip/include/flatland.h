#ifndef _flatland_h
#define _flatland_h

#include "canvas.h"
#include "fixedpoint8.h"
#include "distance.h"
#include "font.h"

const u16 WORLD_HEIGHT = SCREEN_HEIGHT;
const u16 WORLD_WIDTH = SCREEN_WIDTH;

const u16 VISION_WIDTH = 80;

const float PI = 3.14159;

class Flatland {
	public:
		// Constructors
		Flatland();
		~Flatland();

		// Methods
		void go();
		void cast();
		void draw_line(touchPosition stylus, touchPosition last_stylus);

	private:
		u8 *world;
		FixedPoint8 x;
		FixedPoint8 y;
		s16 direction;
};

#endif
