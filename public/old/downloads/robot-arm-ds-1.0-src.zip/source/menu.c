#include "main.h"

void mainMenu() {
	int i;
	
	preMainMenu();

	while (1) {
		scanKeys();
		if (keysHeld() & KEY_A) {
			while (keysHeld() & KEY_A) { scanKeys(); swiWaitForVBlank(); }
			preGame();
			preMainMenu();
		}
		if (keysHeld() & KEY_B) {
			while (keysHeld() & KEY_B) { scanKeys(); swiWaitForVBlank(); }
			credits();
			preMainMenu();
		}
		if (keysHeld() & KEY_X) {
			while (keysHeld() & KEY_X) { scanKeys(); swiWaitForVBlank(); }
			help();
			preMainMenu();
		}
		if (keysHeld() & KEY_Y) {
			while (keysHeld() & KEY_Y) { scanKeys(); swiWaitForVBlank(); }
			load_curr_level = 1;
			levelEditor();
			load_curr_level = 0;
			preMainMenu();
		}
		swiWaitForVBlank();
	}
}

void showHelp(int page) {
	clearScreens(SCREEN_BOTTOM);
	
	switch (page) {
		case 1:
			printString("Robot Arm is a puzzle game", 5, 5, SCREEN_BOTTOM);
			printString("where you \"write\" a program", 5, 15, SCREEN_BOTTOM);
			printString("which controls a robot arm on", 5, 25, SCREEN_BOTTOM);
			printString("the top screen. The object of", 5, 35, SCREEN_BOTTOM);
			printString("the game is to take the flag", 5, 45, SCREEN_BOTTOM);
			printString("and deliver it to the end tile.", 5, 55, SCREEN_BOTTOM);
			printString("A program is very simple: it", 5, 65, SCREEN_BOTTOM);
			printString("uses 6 commands:", 5, 75, SCREEN_BOTTOM);
			printString("- Move up/down/left/right", 5, 95, SCREEN_BOTTOM);
			printString("- Take item", 5, 105, SCREEN_BOTTOM);
			printString("- Use or drop item", 5, 115, SCREEN_BOTTOM);
			printString("The controls to write a program", 5, 135, SCREEN_BOTTOM);
			printString("are displayed in the game.", 5, 145, SCREEN_BOTTOM);
		break;
		
		case 2:
			printString("Items", 100, 15, SCREEN_BOTTOM);
			putTile(19, 30, 40, SCREEN_BOTTOM);
			putTile(20, 30, 60, SCREEN_BOTTOM);
			putTile(21, 30, 80, SCREEN_BOTTOM);
			putTile(22, 30, 100, SCREEN_BOTTOM);
			printString("Use keys on the", 60, 65, SCREEN_BOTTOM);
			printString("coloured doors", 60, 75, SCREEN_BOTTOM);
			printString("to open them.", 60, 85, SCREEN_BOTTOM);
			putTile(13, 30, 140, SCREEN_BOTTOM);
			printString("Deliver the flag", 60, 135, SCREEN_BOTTOM);
			printString("to the end tile", 60, 145, SCREEN_BOTTOM);
			printString("to win.", 60, 155, SCREEN_BOTTOM);
		break;
		
		case 3:
			printString("Obstacles", 85, 15, SCREEN_BOTTOM);
			putTile(15, 30, 40, SCREEN_BOTTOM);
			putTile(16, 30, 60, SCREEN_BOTTOM);
			putTile(17, 30, 80, SCREEN_BOTTOM);
			putTile(18, 30, 100, SCREEN_BOTTOM);
			printString("Coloured doors", 60, 65, SCREEN_BOTTOM);
			printString("that can be", 60, 75, SCREEN_BOTTOM);
			printString("opened by keys.", 60, 85, SCREEN_BOTTOM);
			putTile(14, 30, 140, SCREEN_BOTTOM);
			printString("The end tile", 60, 135, SCREEN_BOTTOM);
			printString("where you drop", 60, 145, SCREEN_BOTTOM);
			printString("the flag.", 60, 155, SCREEN_BOTTOM);
		break;
		
		case 4:
			printString("Obstacles 2", 80, 15, SCREEN_BOTTOM);
			putTile(1, 30, 40, SCREEN_BOTTOM);
			printString("Indestructible wall", 60, 45, SCREEN_BOTTOM);
			putTile(23, 30, 80, SCREEN_BOTTOM);
			printString("Mine, don't touch it!", 60, 85, SCREEN_BOTTOM);
			putTile(24, 30, 120, SCREEN_BOTTOM);
			printString("Pushable box", 60, 125, SCREEN_BOTTOM);
		break;
	}
}

void credits() {
	clearScreens(SCREEN_BOTH);
	printString("Credits", 100, 10, SCREEN_TOP);
	
	printString("Robot Arm DS was programmed", 5, 30, SCREEN_TOP);
	printString("by Jeremy Ruten, but the idea", 5, 40, SCREEN_TOP);
	printString("was from Robin Ohm who created", 5, 50, SCREEN_TOP);
	printString("Robot Arm a long time ago using", 5, 60, SCREEN_TOP);
	printString("QBasic. His levels are also", 5, 70, SCREEN_TOP);
	printString("included in this game because", 5, 80, SCREEN_TOP);
	printString("Jeremy is very bad at making", 5, 90, SCREEN_TOP);
	printString("levels. :)", 5, 100, SCREEN_TOP);
	
	printChar(130, 5, 182, SCREEN_TOP);
	printString("Back", 20, 182, SCREEN_TOP);
	
	while (!(keysHeld() & KEY_B)) { scanKeys(); swiWaitForVBlank(); }
	while (keysHeld() & KEY_B) { scanKeys(); swiWaitForVBlank(); }
}

void help() {
	int page = 1, quit_help = 0;
	char clear_str[] = { 31,31,31,31,31,31,31,31,31,'\0' };
	char page_str[10];
	clearScreens(SCREEN_BOTH);
	printStringCenter("Page 1/4");
	printChar(133, 10, 180, SCREEN_TOP);
	printString("Next/Previous Page", 25, 180, SCREEN_TOP);
	printChar(130, 200, 180, SCREEN_TOP);
	printString("Back to menu", 215, 180, SCREEN_TOP);
	showHelp(page);
	while (!quit_help) {
		scanKeys();
		if (keysHeld() & KEY_LEFT) {
			while (keysHeld() & KEY_LEFT) { scanKeys(); swiWaitForVBlank(); }
			page--;
			if (page == 0) { page = 1; }
			printStringCenter(clear_str);
			sprintf(page_str, "Page %d/4", page);
			printStringCenter(page_str);
			showHelp(page);
		}
		if (keysHeld() & KEY_RIGHT) {
			while (keysHeld() & KEY_RIGHT) { scanKeys(); swiWaitForVBlank(); }
			page++;
			if (page == 5) { page = 4; }
			printStringCenter(clear_str);
			sprintf(page_str, "Page %d/4", page);
			printStringCenter(page_str);
			showHelp(page);
		}
		if (keysHeld() & KEY_B) {
			while (keysHeld() & KEY_B) { scanKeys(); swiWaitForVBlank(); }
			quit_help = 1;
		}
		swiWaitForVBlank();
	}
}

void preMainMenu() {
	clearScreens(SCREEN_BOTH);

	printStringCenter("Robot Arm DS");
	
	// A: start game
	printChar(129, 50, 65, SCREEN_BOTTOM);
	printString("Start game", 65, 65, SCREEN_BOTTOM);
	
	// B: credits
	printChar(130, 50, 80, SCREEN_BOTTOM);
	printString("Credits", 65, 80, SCREEN_BOTTOM);
	
	// X: help
	printChar(127, 50, 95, SCREEN_BOTTOM);
	printString("Help", 65, 95, SCREEN_BOTTOM);
	
	// Y: level editor
	printChar(128, 50, 110, SCREEN_BOTTOM);
	printString("Level editor", 65, 110, SCREEN_BOTTOM);
}

void preGame() {
	int i;
	int selected = 0;

	clearScreens(SCREEN_BOTH);
	
	printChar(133, 5, 180, SCREEN_BOTTOM);
	printString("Pick level group", 20, 180, SCREEN_BOTTOM);
	printChar(129, 190, 180, SCREEN_BOTTOM);
	printString("Start", 205, 180, SCREEN_BOTTOM);
	
	for (i = 0; i < NUM_OF_LEVEL_GROUPS; i++) {
		printString(level_group_name[i], 20, i * 9 + 20, SCREEN_BOTTOM);
	}
	printChar('>', 10, 20, SCREEN_BOTTOM);
	
	while (!(keysHeld() & KEY_A)) {
		scanKeys();
		if (keysHeld() & KEY_UP) {
			selected--;
			if (selected < 0) { selected = 0; }
			printChar(31, 10, (selected+1) * 9 + 20, SCREEN_BOTTOM);
			printChar('>', 10, selected * 9 + 20, SCREEN_BOTTOM);
			for (i = 0; i < 5; i++)
				swiWaitForVBlank();
		}
		if (keysHeld() & KEY_DOWN) {
			selected++;
			if (selected >= NUM_OF_LEVEL_GROUPS) { selected = NUM_OF_LEVEL_GROUPS - 1; }
			printChar(31, 10, (selected-1) * 9 + 20, SCREEN_BOTTOM);
			printChar('>', 10, selected * 9 + 20, SCREEN_BOTTOM);
			for (i = 0; i < 5; i++)
				swiWaitForVBlank();
		}
		swiWaitForVBlank();
	}
	
	while (keysHeld() & KEY_A) { scanKeys(); swiWaitForVBlank(); }

	Robot_level_group = selected;

	clearScreens(SCREEN_BOTH);
	game();
}

void clearScreens(int screen) {
	int i;
	
	if (screen == SCREEN_BOTTOM || screen == SCREEN_BOTH)
		for (i = 0; i < 256*256; i++)
			BG_GFX_SUB[i] = RGB15(0, 0, 0) | BIT(15);

	if (screen == SCREEN_TOP || screen == SCREEN_BOTH)
		for (i = 0; i < 256*192; i++)
			VRAM_A[i] = RGB15(0, 0, 0);
}

void waitForAnyKey() {
	while (!keysHeld()) { scanKeys(); swiWaitForVBlank(); }
	while (keysHeld()) { scanKeys(); swiWaitForVBlank(); }
}
