#include "main.h"
#include "tiledata.h"

void putTile(int tid, int x, int y, int screen) {
	int put_y, put_x;
	for (put_y = y; put_y < y + TILE_SIZE; put_y++) {
		for (put_x = x; put_x < x + TILE_SIZE; put_x++) {
			putPixel2(tiles[tid][put_y - y][put_x - x], put_x, put_y, screen);
		}
	}
}

void putPixel2(int colour, int x, int y, int screen) {
	if (screen == SCREEN_TOP) {
		switch (colour) {
			case 0:
				VRAM_A[x + y * SCREEN_WIDTH] = RGB15(0,0,0); // black
				break;
			case 1:
				VRAM_A[x + y * SCREEN_WIDTH] = RGB15(7,7,7); // dark grey
				break;
			case 2:
				VRAM_A[x + y * SCREEN_WIDTH] = RGB15(15,15,15); // grey
				break;
			case 3:
				VRAM_A[x + y * SCREEN_WIDTH] = RGB15(23,23,23); // light grey
				break;
			case 4:
				VRAM_A[x + y * SCREEN_WIDTH] = RGB15(7, 17, 17); // teal
				break;
			case 5:
				VRAM_A[x + y * SCREEN_WIDTH] = RGB15(6, 10, 10); // dark teal
				break;
			case 6:
				VRAM_A[x + y * SCREEN_WIDTH] = RGB15(14, 22, 22); // light teal
				break;
			case 7:
				VRAM_A[x + y * SCREEN_WIDTH] = RGB15(9, 4, 0); // dark brown
				break;
			case 8:
				VRAM_A[x + y * SCREEN_WIDTH] = RGB15(31, 0, 0); // red
				break;
			case 9:
				VRAM_A[x + y * SCREEN_WIDTH] = RGB15(0, 0, 31); // blue
				break;
			case 10:
				VRAM_A[x + y * SCREEN_WIDTH] = RGB15(0, 31, 0); // green
				break;
			case 11:
				VRAM_A[x + y * SCREEN_WIDTH] = RGB15(31, 31, 0); // yellow
				break;
			case 12:
				VRAM_A[x + y * SCREEN_WIDTH] = RGB15(31, 31, 31); // white
				break;
			case 13:
				VRAM_A[x + y * SCREEN_WIDTH] = RGB15(20, 10, 0); // brown
				break;
			default:
				VRAM_A[x + y * SCREEN_WIDTH] = RGB15(0, 0, 0); // black
		}
	} else {
		switch (colour) {
			case 0:
				BG_GFX_SUB[x + y * 256] = RGB15(0,0,0) | BIT(15); // black
				break;
			case 1:
				BG_GFX_SUB[x + y * 256] = RGB15(7,7,7) | BIT(15); // dark grey
				break;
			case 2:
				BG_GFX_SUB[x + y * 256] = RGB15(15,15,15) | BIT(15); // grey
				break;
			case 3:
				BG_GFX_SUB[x + y * 256] = RGB15(23,23,23) | BIT(15); // light grey
				break;
			case 4:
				BG_GFX_SUB[x + y * 256] = RGB15(7, 17, 17) | BIT(15); // teal
				break;
			case 5:
				BG_GFX_SUB[x + y * 256] = RGB15(6, 10, 10) | BIT(15); // dark teal
				break;
			case 6:
				BG_GFX_SUB[x + y * 256] = RGB15(14, 22, 22) | BIT(15); // light teal
				break;
			case 7:
				BG_GFX_SUB[x + y * 256] = RGB15(9, 4, 0) | BIT(15); // dark brown
				break;
			case 8:
				BG_GFX_SUB[x + y * 256] = RGB15(31, 0, 0) | BIT(15); // red
				break;
			case 9:
				BG_GFX_SUB[x + y * 256] = RGB15(0, 0, 31) | BIT(15); // blue
				break;
			case 10:
				BG_GFX_SUB[x + y * 256] = RGB15(0, 31, 0) | BIT(15); // green
				break;
			case 11:
				BG_GFX_SUB[x + y * 256] = RGB15(31, 31, 0) | BIT(15); // yellow
				break;
			case 12:
				BG_GFX_SUB[x + y * 256] = RGB15(31, 31, 31) | BIT(15); // white
				break;
			case 13:
				BG_GFX_SUB[x + y * 256] = RGB15(20, 10, 0) | BIT(15); // brown
				break;
			default:
				BG_GFX_SUB[x + y * 256] = RGB15(0, 0, 0) | BIT(15); // black
		}
	}
}
