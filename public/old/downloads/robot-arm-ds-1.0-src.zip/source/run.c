#include "main.h"
#include "levels.h"

int run(int *commands) {
	int PC = 0;
	int cmd_code;
	int errors = 0;
	int backing_up = 0;
	int move_history_x[500];
	int move_history_y[500];
	int move_history_direction[500];
	int move_history_index = 0;
	int new_tile;
	int wait;
	int item_x, item_y;
	int win = 0;
	int testtile = 0;
	while (*(commands+PC) != 0 && !errors) {
		cmd_code = *(commands+PC);
		
		if (cmd_code >= 1 && cmd_code <= 4) { // Move
			move_history_x[move_history_index] = Robot_x;
			move_history_y[move_history_index] = Robot_y;
			move_history_direction[move_history_index] = Robot_direction;
		
			if (cmd_code == 1) { Robot_y--; }
			else if (cmd_code == 2) { Robot_x++; }
			else if (cmd_code == 3) { Robot_y++; }
			else if (cmd_code == 4) { Robot_x--; }
			
			if (Robot_y > 11 || Robot_y < 0 || Robot_x > 15 || Robot_x < 0) {
				errors = 1;
				showError("Ran into the edge of the screen.");			
			} else if (curr_level[Robot_y][Robot_x] > 6 && curr_level[Robot_y][Robot_x] < 13) {
				// Check whether it's running into itself, or just backing up
				Robot_direction = cmd_code;
				if (move_history_direction[move_history_index] == 1 && Robot_direction == 3) { backing_up = 1; }
				if (move_history_direction[move_history_index] == 3 && Robot_direction == 1) { backing_up = 1; }
				if (move_history_direction[move_history_index] == 2 && Robot_direction == 4) { backing_up = 1; }
				if (move_history_direction[move_history_index] == 4 && Robot_direction == 2) { backing_up = 1; }
				
				if (backing_up) {
					curr_level[move_history_y[move_history_index]][move_history_x[move_history_index]] = 2;
					putTile(2, move_history_x[move_history_index] * TILE_SIZE, move_history_y[move_history_index] * TILE_SIZE, SCREEN_TOP);
					Robot_x = move_history_x[move_history_index-1];
					Robot_y = move_history_y[move_history_index-1];
					Robot_direction = move_history_direction[move_history_index-1];
					curr_level[Robot_y][Robot_x] = Robot_direction + 2;
					putTile(Robot_direction + 2, Robot_x * TILE_SIZE, Robot_y * TILE_SIZE, SCREEN_TOP);
					
					move_history_x[move_history_index] = 0;
					move_history_y[move_history_index] = 0;
					move_history_direction[move_history_index] = 0;
					move_history_index -= 2;
				} else {
					errors = 1;
					showError("Ran into yourself.");
				}
			} else if (curr_level[Robot_y][Robot_x] != 2 && curr_level[Robot_y][Robot_x] != 24) {
				errors = 1;
				showError("Ran into something impassable.");
			} else {
				if (curr_level[Robot_y][Robot_x] == 24) {
					// Check if the block is movable, then move it
					item_x = Robot_x;
					item_y = Robot_y;
					if (cmd_code == 1) { item_y--; }
					if (cmd_code == 2) { item_x++; }
					if (cmd_code == 3) { item_y++; }
					if (cmd_code == 4) { item_x--; }
					
					if (curr_level[item_y][item_x] == 2 && !(item_y > 11 || item_y < 0 || item_x > 15 || item_x < 0)) {
						curr_level[item_y][item_x] = 24;
						putTile(24, item_x * TILE_SIZE, item_y * TILE_SIZE, SCREEN_TOP);
					} else {
						errors = 1;
						showError("Block is immovable.");
					}
				}
				
				if (!errors) {
					putTile(cmd_code + 2, Robot_x * TILE_SIZE, Robot_y * TILE_SIZE, SCREEN_TOP);
					curr_level[Robot_y][Robot_x] = cmd_code + 2;
					
					// Figure out which tile to put in place of where the robot just was (what I call "pipes")
					Robot_direction = cmd_code;
					if ((move_history_direction[move_history_index] == 2 && Robot_direction == 4) || (move_history_direction[move_history_index] == 4 && Robot_direction == 2) || (move_history_direction[move_history_index] == 2 && Robot_direction == 2) || (move_history_direction[move_history_index] == 4 && Robot_direction == 4)) { new_tile = 7; }
					if ((move_history_direction[move_history_index] == 1 && Robot_direction == 3) || (move_history_direction[move_history_index] == 3 && Robot_direction == 1) || (move_history_direction[move_history_index] == 1 && Robot_direction == 1) || (move_history_direction[move_history_index] == 3 && Robot_direction == 3)) { new_tile = 8; }
					if ((move_history_direction[move_history_index] == 4 && Robot_direction == 1) || (move_history_direction[move_history_index] == 3 && Robot_direction == 2)) { new_tile = 9; }
					if ((move_history_direction[move_history_index] == 1 && Robot_direction == 2) || (move_history_direction[move_history_index] == 4 && Robot_direction == 3)) { new_tile = 10; }
					if ((move_history_direction[move_history_index] == 2 && Robot_direction == 1) || (move_history_direction[move_history_index] == 3 && Robot_direction == 4)) { new_tile = 11; }
					if ((move_history_direction[move_history_index] == 2 && Robot_direction == 3) || (move_history_direction[move_history_index] == 1 && Robot_direction == 4)) { new_tile = 12; }
					
					putTile(new_tile, move_history_x[move_history_index] * TILE_SIZE, move_history_y[move_history_index] * TILE_SIZE, SCREEN_TOP);
					curr_level[move_history_y[move_history_index]][move_history_x[move_history_index]] = new_tile;
				}
			}
		} else if (cmd_code == 5) { // Take
			item_x = Robot_x;
			item_y = Robot_y;
			if (Robot_item == 2) {
				if (Robot_direction == 1) { item_y--; }
				if (Robot_direction == 2) { item_x++; }
				if (Robot_direction == 3) { item_y++; }
				if (Robot_direction == 4) { item_x--; }
				
				if (curr_level[item_y][item_x] == 13 || (curr_level[item_y][item_x] >= 19 && curr_level[item_y][item_x] <= 22)) {
					Robot_item = curr_level[item_y][item_x];
					curr_level[item_y][item_x] = 2;
					putTile(2, item_x * TILE_SIZE, item_y * TILE_SIZE, SCREEN_TOP);
					move_history_index--;
					putTile(Robot_item, 211, 16, SCREEN_BOTTOM);
				} else {
					errors = 1;
					showError("There's no item here to take.");
				}
			} else {
				errors = 1;
				showError("Can't hold more than 1 item.");
			}
		} else if (cmd_code == 6) { // Use
			if (Robot_item != 2) {
				item_x = Robot_x;
				item_y = Robot_y;
				if (Robot_direction == 1) { item_y--; }
				if (Robot_direction == 2) { item_x++; }
				if (Robot_direction == 3) { item_y++; }
				if (Robot_direction == 4) { item_x--; }
				
				if (curr_level[item_y][item_x] == 14 || (curr_level[item_y][item_x] >= 15 && curr_level[item_y][item_x] <= 18) || curr_level[item_y][item_x] == 2) {
					if (curr_level[item_y][item_x] == 14 && Robot_item == 13) {
						win = 1;
						putTile(13, item_x * TILE_SIZE, item_y * TILE_SIZE, SCREEN_TOP);
						move_history_index--;
						Robot_item = 2;
						putTile(Robot_item, 211, 16, SCREEN_BOTTOM);
					} else if ((curr_level[item_y][item_x] >= 15 && curr_level[item_y][item_x] <= 18) && curr_level[item_y][item_x] == Robot_item - 4) {
						curr_level[item_y][item_x] = 2;
						putTile(2, item_x * TILE_SIZE, item_y * TILE_SIZE, SCREEN_TOP);
						move_history_index--;
						Robot_item = 2;
						putTile(Robot_item, 211, 16, SCREEN_BOTTOM);
					} else if (curr_level[item_y][item_x] == 2) {
						curr_level[item_y][item_x] = Robot_item;
						putTile(Robot_item, item_x * TILE_SIZE, item_y * TILE_SIZE, SCREEN_TOP);
						move_history_index--;
						Robot_item = 2;
						putTile(Robot_item, 211, 16, SCREEN_BOTTOM);
					} else {
						errors = 1;
						showError("This item can't be used here.");
					}
				}
			} else {
				errors = 1;
				showError("There is no item to use.");
			}
		}
		
		for (wait = 0; wait < 15; wait++) {
			scanKeys();
			if (keysHeld() & KEY_START) {
				errors = 1;
				showError("Program stopped.");
			}
			swiWaitForVBlank();
		}
		
		PC++;
		move_history_index++;
	}
	
	if (errors || (!win && *(commands+PC) == 0)) { return 0; }
	else { return 1; }
}
