#include "main.h"
#include "fontdata.h"

void printString(char *str, int x, int y, int screen) {
	int curr_x = x;
	int put_y, put_x;
	int curr_char = 0;
	int pixel_colour;
	while (*(str+curr_char) != '\0' && curr_x < SCREEN_WIDTH - 7) {
		for (put_y = y; put_y < y + 8; put_y++) {
			for (put_x = curr_x; put_x < curr_x + 8; put_x++) {
				pixel_colour = font[(int)*(str+curr_char)][put_y - y][put_x - curr_x];
				if (screen == SCREEN_TOP) {
					switch (pixel_colour) {
						case 1:
							VRAM_A[put_x + put_y * SCREEN_WIDTH] = RGB15(0,0,0); // black
							break;
						case 2:
							VRAM_A[put_x + put_y * SCREEN_WIDTH] = RGB15(31,31,31); // white
							break;
						default:
							// transparent (don't do anything)
							break;
					}
				} else {
					switch (pixel_colour) {
						case 1:
							BG_GFX_SUB[put_x + put_y * 256] = RGB15(0,0,0) | BIT(15); // black
							break;
						case 2:
							BG_GFX_SUB[put_x + put_y * 256] = RGB15(31,31,31) | BIT(15); // white
							break;
						default:
							// transparent (don't do anything)
							break;
					}
				}
			}
		}
		
		curr_x += 8;
		curr_char++;
	}
}

void printChar(char char_, int x, int y, int screen) {
	int put_y, put_x;
	int pixel_colour;
	for (put_y = y; put_y < y + 8; put_y++) {
		for (put_x = x; put_x < x + 8; put_x++) {
			pixel_colour = font[(int)char_][put_y - y][put_x - x];
			if (screen == SCREEN_TOP) {
				switch (pixel_colour) {
					case 1:
						VRAM_A[put_x + put_y * SCREEN_WIDTH] = RGB15(0,0,0); // black
						break;
					case 2:
						VRAM_A[put_x + put_y * SCREEN_WIDTH] = RGB15(31,31,31); // white
						break;
					default:
						// transparent (don't do anything)
						break;
				}
			} else {
				switch (pixel_colour) {
					case 1:
						BG_GFX_SUB[put_x + put_y * 256] = RGB15(0,0,0) | BIT(15); // black
						break;
					case 2:
						BG_GFX_SUB[put_x + put_y * 256] = RGB15(31,31,31) | BIT(15); // white
						break;
					default:
						// transparent (don't do anything)
						break;
				}
			}
		}
	}
}

void showError(char *str) {
	printString(str, 5, 5, SCREEN_TOP);
}

void printStringCenter(char *str) {
	int i = 0;
	int num_x = 0;
	while (*(str+i) != '\0') {
		num_x += 8;
		i++;
	}
	printString(str, 127 - (num_x / 2), 88, SCREEN_TOP);
}

void printNumber(int num, int x, int y, int screen) {
	char num_str[20];
	sprintf(num_str, "%d", num);
	printString(num_str, x, y, screen);
}

void printInstructions(void) {
	// X
	printChar(127, 15, 85, SCREEN_BOTTOM);
	printString("Scroll up", 45, 85, SCREEN_BOTTOM);
	// Y
	printChar(128, 15, 94, SCREEN_BOTTOM);
	printString("Scroll down", 45, 94, SCREEN_BOTTOM);
	// A
	printChar(129, 15, 103, SCREEN_BOTTOM);
	printString("Take item", 45, 103, SCREEN_BOTTOM);
	// B
	printChar(130, 15, 112, SCREEN_BOTTOM);
	printString("Use/Drop item", 45, 112, SCREEN_BOTTOM);
	// L
	printChar(131, 15, 121, SCREEN_BOTTOM);
	printString("Delete command", 45, 121, SCREEN_BOTTOM);
	// R
	printChar(132, 15, 130, SCREEN_BOTTOM);
	printString("Game menu", 45, 130, SCREEN_BOTTOM);
	// D-Pad
	printChar(133, 15, 139, SCREEN_BOTTOM);
	printString("Move arm", 45, 139, SCREEN_BOTTOM);
	// Start
	printChar(134, 15, 148, SCREEN_BOTTOM);
	printChar(135, 23, 148, SCREEN_BOTTOM);
	printChar(136, 31, 148, SCREEN_BOTTOM);
	printString("Run/Stop program", 45, 148, SCREEN_BOTTOM);
	// Select
	printChar(137, 15, 157, SCREEN_BOTTOM);
	printChar(138, 23, 157, SCREEN_BOTTOM);
	printChar(139, 31, 157, SCREEN_BOTTOM);
	printChar(140, 39, 157, SCREEN_BOTTOM);
	printString("Clear program", 45, 157, SCREEN_BOTTOM);
}
