#include "main.h"

void putTile(int (*tid)[TILE_SIZE], int x, int y, int screen);
void putPixel2(int colour, int x, int y, int screen);
