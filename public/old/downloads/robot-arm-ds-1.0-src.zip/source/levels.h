#include "main.h"

void loadLevel(int lid);
int level[NUM_OF_LEVELS][12][16];
int curr_level[12][16];
void updateLevel(int lid);
