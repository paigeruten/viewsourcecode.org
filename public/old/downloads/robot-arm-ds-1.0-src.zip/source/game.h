#include "main.h"

void game();
void updateProgram(int *program, int start, int selected);
int pushProgram(int *program, int cmd);
void popProgram(int *program);
void eraseProgram(int *program);
void deleteProgram(int *program, int index);
void insertProgram(int *program, int cmd, int index);
int lengthProgram(int *program);

int prog[10000];
