#include "main.h"

void mainMenu();
void showHelp(int page);
void credits();
void help();
void preMainMenu();
void preGame();
void clearScreens(int screen);
void waitForAnyKey();
