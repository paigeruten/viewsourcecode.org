#include "main.h"

int prog[10000];
char dec[3];

void game() {
	int programPos = 0, selected = 0, i = 0, won = 0, attempts = 0, j = 0, quit = 0;
	char Robot_level_str[4], attempts_str[3], clear_str[15] = {31,31,31,31,31,31,31,31,31,31,31,31,31,31,'\0'}, level_str2[10];

	Robot_level = level_group_start[Robot_level_group];

	loadLevel(Robot_level);
	updateProgram(prog, programPos, selected);
	printInstructions();

	printString("Attempts: 0", 7, 175, SCREEN_BOTTOM);
	printString("Level: ", 128, 175, SCREEN_BOTTOM);
	printNumber(Robot_level-level_group_start[Robot_level_group]+1, 182, 175, SCREEN_BOTTOM);

	while (!quit) {
		scanKeys();
		
		if (keysHeld() & KEY_X && selected != 0) {
			selected--;
			if (selected < programPos) { programPos--; }
			updateProgram(prog, programPos, selected);
			for (i = 0; i < 5; i++)
				swiWaitForVBlank();			
		}
		if (keysHeld() & KEY_Y && selected != lengthProgram(prog)) {
			selected++;
			if (selected > programPos+5) { programPos++; }
			updateProgram(prog, programPos, selected);
			for (i = 0; i < 5; i++)
				swiWaitForVBlank();
		}
		if (keysHeld() & KEY_UP) {
			if (selected == lengthProgram(prog)) {
				selected = pushProgram(prog, 1) + 1;
				programPos = selected - 5;
				if (programPos < 0) { programPos = 0; }
				updateProgram(prog, programPos, selected);
			} else {
				insertProgram(prog, 1, selected);
				selected++;
				if (selected > programPos + 5) { programPos = selected - 5; }
				if (programPos < 0) { programPos = 0; }
				updateProgram(prog, programPos, selected);
			}
			while (keysHeld() & KEY_UP) { scanKeys(); swiWaitForVBlank(); }
		}
		if (keysHeld() & KEY_RIGHT) {
			if (selected == lengthProgram(prog)) {
				selected = pushProgram(prog, 2) + 1;
				programPos = selected - 5;
				if (programPos < 0) { programPos = 0; }
				updateProgram(prog, programPos, selected);
			} else {
				insertProgram(prog, 2, selected);
				selected++;
				if (selected > programPos + 5) { programPos = selected - 5; }
				if (programPos < 0) { programPos = 0; }
				updateProgram(prog, programPos, selected);
			}
			while (keysHeld() & KEY_RIGHT) { scanKeys(); swiWaitForVBlank(); }
		}
		if (keysHeld() & KEY_DOWN) {
			if (selected == lengthProgram(prog)) {
				selected = pushProgram(prog, 3) + 1;
				programPos = selected - 5;
				if (programPos < 0) { programPos = 0; }
				updateProgram(prog, programPos, selected);
			} else {
				insertProgram(prog, 3, selected);
				selected++;
				if (selected > programPos + 5) { programPos = selected - 5; }
				if (programPos < 0) { programPos = 0; }
				updateProgram(prog, programPos, selected);
			}
			while (keysHeld() & KEY_DOWN) { scanKeys(); swiWaitForVBlank(); }
		}
		if (keysHeld() & KEY_LEFT) {
			if (selected == lengthProgram(prog)) {
				selected = pushProgram(prog, 4) + 1;
				programPos = selected - 5;
				if (programPos < 0) { programPos = 0; }
				updateProgram(prog, programPos, selected);
			} else {
				insertProgram(prog, 4, selected);
				selected++;
				if (selected > programPos + 5) { programPos = selected - 5; }
				if (programPos < 0) { programPos = 0; }
				updateProgram(prog, programPos, selected);
			}
			while (keysHeld() & KEY_LEFT) { scanKeys(); swiWaitForVBlank(); }
		}
		if (keysHeld() & KEY_A) {
			if (selected == lengthProgram(prog)) {
				selected = pushProgram(prog, 5) + 1;
				programPos = selected - 5;
				if (programPos < 0) { programPos = 0; }
				updateProgram(prog, programPos, selected);
			} else {
				insertProgram(prog, 5, selected);
				selected++;
				if (selected > programPos + 5) { programPos = selected - 5; }
				if (programPos < 0) { programPos = 0; }
				updateProgram(prog, programPos, selected);
			}
			while (keysHeld() & KEY_A) { scanKeys(); swiWaitForVBlank(); }
		}
		if (keysHeld() & KEY_B) {
			if (selected == lengthProgram(prog)) {
				selected = pushProgram(prog, 6) + 1;
				programPos = selected - 5;
				if (programPos < 0) { programPos = 0; }
				updateProgram(prog, programPos, selected);
			} else {
				insertProgram(prog, 6, selected);
				selected++;
				if (selected > programPos + 5) { programPos = selected - 5; }
				if (programPos < 0) { programPos = 0; }
				updateProgram(prog, programPos, selected);
			}
			while (keysHeld() & KEY_B) { scanKeys(); swiWaitForVBlank(); }
		}
		if (keysHeld() & KEY_L && prog[0] != 0) {
			if (prog[selected] == 0) {
				popProgram(prog);
				selected--;
				if (programPos > 0) { programPos--; }
			} else {
				deleteProgram(prog, selected);
			}
			updateProgram(prog, programPos, selected);
			while (keysHeld() & KEY_L) { scanKeys(); swiWaitForVBlank(); }
		}
		if (keysHeld() & KEY_R) {
			clearScreens(SCREEN_TOP);
			printStringCenter("Game Menu");
			
			// A: Next level
			printChar(129, 50, 110, SCREEN_TOP);
			printString("Next level", 65, 110, SCREEN_TOP);
			
			// B: Previous level
			printChar(130, 50, 125, SCREEN_TOP);
			printString("Previous level", 65, 125, SCREEN_TOP);
			
			// X: Quit game
			printChar(127, 50, 140, SCREEN_TOP);
			printString("Quit game", 65, 140, SCREEN_TOP);
			
			// Y: Cancel
			printChar(128, 50, 155, SCREEN_TOP);
			printString("Cancel", 65, 155, SCREEN_TOP);
			
			// Level information
			printString(level_group_name[Robot_level_group], 5, 5, SCREEN_TOP);
			sprintf(level_str2, "Level %d/%d", Robot_level-level_group_start[Robot_level_group]+1, level_group_end[Robot_level_group]-level_group_start[Robot_level_group]+1);
			printString(level_str2, 5, 15, SCREEN_TOP);
			
			j = 0;
			while (!j) {
				scanKeys();
				if ((keysHeld() & KEY_A) && Robot_level < level_group_end[Robot_level_group]) {
					while (keysHeld() & KEY_A) { scanKeys(); swiWaitForVBlank(); }
					Robot_level++;
					
					eraseProgram(prog);
					selected = 0;
					programPos = 0;
					attempts = 0;
					updateProgram(prog, programPos, selected);
					
					loadLevel(Robot_level);
										
					printString(clear_str, 7, 175, SCREEN_BOTTOM);
					printString(clear_str, 128, 175, SCREEN_BOTTOM);
					printString("Attempts: ", 7, 175, SCREEN_BOTTOM);
					printString("Level: ", 128, 175, SCREEN_BOTTOM);
					printNumber(attempts, 85, 175, SCREEN_BOTTOM);
					printNumber(Robot_level-level_group_start[Robot_level_group]+1, 182, 175, SCREEN_BOTTOM);
					
					j = 1;
				}
				if ((keysHeld() & KEY_B) && Robot_level > level_group_start[Robot_level_group]) {
					while (keysHeld() & KEY_B) { scanKeys(); swiWaitForVBlank(); }
					Robot_level--;
					
					eraseProgram(prog);
					selected = 0;
					programPos = 0;
					attempts = 0;
					updateProgram(prog, programPos, selected);
					
					loadLevel(Robot_level);
										
					printString(clear_str, 7, 175, SCREEN_BOTTOM);
					printString(clear_str, 128, 175, SCREEN_BOTTOM);
					printString("Attempts: ", 7, 175, SCREEN_BOTTOM);
					printString("Level: ", 128, 175, SCREEN_BOTTOM);
					printNumber(attempts, 85, 175, SCREEN_BOTTOM);
					printNumber(Robot_level-level_group_start[Robot_level_group]+1, 182, 175, SCREEN_BOTTOM);
					
					j = 1;
				}
				if (keysHeld() & KEY_X) {
					while (keysHeld() & KEY_X) { scanKeys(); swiWaitForVBlank(); }
					quit = 1;
					j = 1;
				}
				if (keysHeld() & KEY_Y) {
					while (keysHeld() & KEY_Y) { scanKeys(); swiWaitForVBlank(); }
					loadLevel(Robot_level);
					j = 1;
				}
				swiWaitForVBlank();
			}
		}
		if (keysHeld() & KEY_SELECT) {
			eraseProgram(prog);
			selected = 0;
			programPos = 0;
			updateProgram(prog, programPos, selected);
		}
		if (keysHeld() & KEY_START) {
			while (keysHeld() & KEY_START) { scanKeys(); swiWaitForVBlank(); }
			won = run(prog);
			if (won) {
				printStringCenter("You won! Press A.", SCREEN_TOP);
				Robot_level++;
				eraseProgram(prog);
				selected = 0;
				programPos = 0;
				attempts = 0;
				updateProgram(prog, programPos, selected);
				if (Robot_level == 4) {
					quit = 1;
				}
			} else {
				printStringCenter("You're dead! Press A.", SCREEN_TOP);
				attempts++;
			}
			while (!(keysHeld() & KEY_A)) { scanKeys(); swiWaitForVBlank(); }
			while (keysHeld() & KEY_A) { scanKeys(); swiWaitForVBlank(); }
			loadLevel(Robot_level);
						
			printString(clear_str, 7, 175, SCREEN_BOTTOM);
			printString(clear_str, 128, 175, SCREEN_BOTTOM);
			printString("Attempts: ", 7, 175, SCREEN_BOTTOM);
			printString("Level: ", 128, 175, SCREEN_BOTTOM);
			printNumber(attempts, 85, 175, SCREEN_BOTTOM);
			printNumber(Robot_level-level_group_start[Robot_level_group]+1, 182, 175, SCREEN_BOTTOM);
		}
		
		swiWaitForVBlank();
	}
}

void updateProgram(int *program, int start, int selected) {
	int count = 0, y = 0, x = 0;
	u8 i = 0;
	char num_str[5];
	char prog_char[2];
	char clear_str[6] = {31,31,31,31,31,'\0'};
	
	for (i = 0; i <= 6; i++) {
		printChar(31, 5, i * 9 + 10, SCREEN_BOTTOM);
	}
	
	for (i = start; i < start+6; i++) {
		count++;
		printString(clear_str, 20, count * 9 + 10, SCREEN_BOTTOM);
		if (i == selected) {
			printChar('>', 5, count * 9 + 10, SCREEN_BOTTOM);
		}
		printNumber(i, 20, count * 9 + 10, SCREEN_BOTTOM);
		prog_char[0] = program[i];
		prog_char[1] = '\0';
		if (prog_char[0] == '\0') { prog_char[0] = 31; }
		printString(prog_char, 80, count * 9 + 10, SCREEN_BOTTOM);
	}
}

int pushProgram(int *program, int cmd) {
	int i = 0;
	while (*(program+i) != 0)
		i++;
	program[i] = cmd;
	return i;	
}

void popProgram(int *program) {
	int i = 0;
	while (*(program+i) != 0)
		i++;
	program[i-1] = 0;
}

void eraseProgram(int *program) {
	int i = 0;
	while (*(program+i) != 0) {
		program[i] = 0;
		i++;
	}
}

void deleteProgram(int *program, int index) {
	int i = 0, j = 0;
	while (*(program+i) != 0)
		i++;
	i++;
	for (j = index; j < i; j++)
		program[j] = program[j+1];
	program[i] = 0;
}

void insertProgram(int *program, int cmd, int index) {
	int i = 0, j = 0;
	while (*(program+i) != 0)
		i++;
	i++;
	for (j = i; j > index; j--)
		program[j] = program[j-1];
	program[index] = cmd;
}

int lengthProgram(int *program) {
	int i = 0;
	while (*(program+i) != '\0')
		i++;
	return i;
}
