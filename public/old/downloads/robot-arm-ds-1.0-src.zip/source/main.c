#include "tiledata.h"
#include "fontdata.h"
#include "tile.h"
#include "font.h"
#include "levels.h"
#include "run.h"
#include "game.h"
#include "menu.h"
#include "levedit.h"

int main(void) {
	irqInit();
	irqEnable(IRQ_VBLANK);
	
	// Main screen turn on
	videoSetMode(MODE_FB0);
	vramSetBankA(VRAM_A_LCD);

	// Sub screen turn on
	videoSetModeSub(MODE_5_2D | DISPLAY_BG2_ACTIVE);
	vramSetBankC(VRAM_C_SUB_BG);
	SUB_BG2_CR = BG_BMP16_256x256;
	SUB_BG2_XDX = 1 << 8;
	SUB_BG2_XDY = 0 << 8;
	SUB_BG2_YDX = 0 << 8;
	SUB_BG2_YDY = 1 << 8;
	
	mainMenu();
}
