#include "main.h"

int tiles[NUM_OF_TILES][TILE_SIZE][TILE_SIZE];
