#include "main.h"

int current_tile = 1, i = 0, tile_x = 0, tile_y = 0, show_numbers = 0;

void levelEditor() {
	touchPosition touch;
	
	clearScreens(SCREEN_BOTH);
	
	preLevelEditor();
	
	for (tile_y = 0; tile_y < 12; tile_y++) {
		for (tile_x = 0; tile_x < 16; tile_x++) {
			curr_custom_level[tile_y][tile_x] = 0;
			putTile(0, tile_x * TILE_SIZE, tile_y * TILE_SIZE, SCREEN_BOTTOM);
		}
	}
	
	while (!(keysHeld() & KEY_B)) {
		scanKeys();
		if (keysHeld() & KEY_LEFT) {
			current_tile--;
			if (current_tile < 0) { current_tile = 0; }
			updateTileBox();
			for (i = 0; i < 5; i++)
				swiWaitForVBlank();
		}
		if (keysHeld() & KEY_RIGHT) {
			current_tile++;
			if (current_tile > NUM_OF_TILES-1) { current_tile = NUM_OF_TILES-1; }
			updateTileBox();
			for (i = 0; i < 5; i++)
				swiWaitForVBlank();
		}
		if (keysHeld() & KEY_TOUCH) {
			touch = touchReadXY();
			tile_x = floor(touch.px / TILE_SIZE);
			tile_y = floor(touch.py / TILE_SIZE);
			if (curr_custom_level[tile_y][tile_x] != current_tile) {
				curr_custom_level[tile_y][tile_x] = current_tile;
				putTile(curr_custom_level[tile_y][tile_x], tile_x * TILE_SIZE, tile_y * TILE_SIZE, SCREEN_BOTTOM);
			}
		}
		if (keysHeld() & KEY_Y) {
			while (keysHeld() & KEY_Y) { scanKeys(); swiWaitForVBlank(); }
			switch (show_numbers) {
				case 0:
					for (tile_y = 0; tile_y < 12; tile_y++) {
						for (tile_x = 0; tile_x < 16; tile_x++) {
							putTile(curr_custom_level[tile_y][tile_x], tile_x * TILE_SIZE, tile_y * TILE_SIZE, SCREEN_BOTTOM);
							printNumber(curr_custom_level[tile_y][tile_x], tile_x * TILE_SIZE, tile_y * TILE_SIZE, SCREEN_BOTTOM);
						}
					}
					show_numbers = 1;
					break;
				case 1:
					for (tile_y = 0; tile_y < 12; tile_y++) {
						for (tile_x = 0; tile_x < 16; tile_x++) {
							putTile(curr_custom_level[tile_y][tile_x], tile_x * TILE_SIZE, tile_y * TILE_SIZE, SCREEN_BOTTOM);
						}
					}
					show_numbers = 0;
					break;
			}
		}
		if (keysHeld() & KEY_X) {
			while (keysHeld() & KEY_X) { scanKeys(); swiWaitForVBlank(); }
			clearScreens(SCREEN_BOTH);
			game();
			preLevelEditor();
		}
		swiWaitForVBlank();
	}
	while (keysHeld() & KEY_B) { scanKeys(); swiWaitForVBlank(); }
}

void preLevelEditor() {
	clearScreens(SCREEN_BOTH);
	
	updateTileBox();
	
	for (tile_y = 0; tile_y < 12; tile_y++) {
		for (tile_x = 0; tile_x < 16; tile_x++) {
			putTile(curr_custom_level[tile_y][tile_x], tile_x * TILE_SIZE, tile_y * TILE_SIZE, SCREEN_BOTTOM);
		}
	}
	
	// Print instructions
	printChar(130, 5, 70, SCREEN_TOP);
	printString("Back to main menu", 15, 70, SCREEN_TOP);
	printChar(133, 5, 85, SCREEN_TOP);
	printString("Change current tile", 15, 85, SCREEN_TOP);
	printChar(141, 5, 100, SCREEN_TOP);
	printString("Paint current tile to screen", 15, 100, SCREEN_TOP);
	printChar(127, 5, 115, SCREEN_TOP);
	printString("Play level", 15, 115, SCREEN_TOP);
	printChar(128, 5, 130, SCREEN_TOP);
	printString("Show tile id's", 15, 130, SCREEN_TOP);
}

void updateTileBox() {
	int x = 0, y = 0;
	for (x = 29; x < 46; x++) {
		putPixel2(8, x, 29, SCREEN_TOP);
		putPixel2(8, x, 46, SCREEN_TOP);
	}
	for (y = 29; y < 46; y++) {
		putPixel2(8, 29, y, SCREEN_TOP);
		putPixel2(8, 46, y, SCREEN_TOP);
	}
	putTile(current_tile, 30, 30, SCREEN_TOP);
	printString("Current", 11, 19, SCREEN_TOP);
	printString("Tile", 22, 51, SCREEN_TOP);
}
