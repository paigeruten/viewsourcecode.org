#include "main.h"

void printString(char *str, int x, int y, int screen);
void printChar(char char_, int x, int y, int screen);
void showError(char *str);
void printStringCenter(char *str);
void printNumber(int num, int x, int y, int screen);
void printInstructions();
