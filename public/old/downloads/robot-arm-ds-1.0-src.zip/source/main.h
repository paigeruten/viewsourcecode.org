#include <nds.h>
#include <stdlib.h>
#include <string.h>

#define TILE_SIZE 16
#define NUM_OF_TILES 25
#define NUM_OF_LEVELS 23
#define NUM_OF_LEVEL_GROUPS 3
#define SCREEN_TOP 1
#define SCREEN_BOTTOM 0
#define SCREEN_BOTH 2

int Robot_x, Robot_y;
int Robot_item;
int Robot_direction;
int Robot_level;
int Robot_level_group;
int curr_level[12][16];
int curr_custom_level[12][16];
int load_curr_level;
char level_group_name[3][30];
int level_group_start[3];
int level_group_end[3];
