#include "main.h"

int run(int *commands);
