'FreeBible 2004' Bible translation for DSbible
----------------------------------------------

Formatted by Michael Mustun

To install this Bible translation, copy fb2004.txt to the
'/bible/translations' directory of your storage device. DSbible should then
recognize it the next time you run DSbible.
