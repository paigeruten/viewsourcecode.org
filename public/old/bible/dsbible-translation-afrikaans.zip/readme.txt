'Afrikaans 1953 Vertaling' Bible translation for DSbible
--------------------------------------------------------

Formatted by Johan Kok

To install this Bible translation, copy afrikaans.txt to the
'/bible/translations' directory of your storage device. DSbible should then
recognize it the next time you run DSbible.
