Español language file for DSbible 2.5
-------------------------------------

Translated by Brian Franco

To install this language file, copy es.lang to the '/bible/lang' directory of
your storage device. To change the language of DSbible: Run DSbible, go into the
text viewer, tap the Preferences button (the wrench), select your language, and
tap OK.
