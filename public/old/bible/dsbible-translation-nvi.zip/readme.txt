'Bíblia NVI' Bible translation for DSbible
------------------------------------------

Formatted by Miguel Carlos dos Santos Junior

To install this Bible translation, copy nvi_pt.txt to the
'/bible/translations' directory of your storage device. DSbible should then
recognize it the next time you run DSbible.
