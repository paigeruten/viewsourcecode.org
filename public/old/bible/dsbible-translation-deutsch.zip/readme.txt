'Deutsch Schlachter' Bible translation for DSbible
--------------------------------------------------

Formatted by Dominikus Koch

To install this Bible translation, copy deutsch.txt to the
'/bible/translations' directory of your storage device. DSbible should then
recognize it the next time you run DSbible.
