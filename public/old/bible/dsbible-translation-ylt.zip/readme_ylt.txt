                                                                     
                                                                     
                                                                     
                                             
'Young's Literal Translation 1862' Bible translation for DSbible

Formatted by Emmanuel Ernel Sapinoso, Philippines

http://nth-faceted.blogspot.com



To install, copy ylt.txt to the
'/bible/translations' directory of your flash cart.