Nederlands language file for DSbible 2.5
----------------------------------------

Translated by Bram Ruttens

To install this language file, copy nl.lang to the '/bible/lang' directory of
your storage device. To change the language of DSbible: Run DSbible, go into the
text viewer, tap the Preferences button (the wrench), select your language, and
tap OK.
