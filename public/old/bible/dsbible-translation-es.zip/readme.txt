Reina Valera (1909) Bible translation for DSbible
-------------------------------------------------

Formatted by Brian Franco

To install this Bible translation, copy srv.txt to the
'/bible/translations' directory of your storage device. DSbible should then
recognize it the next time you run DSbible.
