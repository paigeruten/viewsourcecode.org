'New King James Version' Bible translation for DSbible
------------------------------------------------------

Formatted by Adam Humphreys

To install this Bible translation, copy nkjv.txt to the
'/bible/translations' directory of your storage device. DSbible should then
recognize it the next time you run DSbible.

