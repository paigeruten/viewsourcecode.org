'Ang Biblia Tagalog 1905' Bible translation for DSbible

Formatted by Emmanuel Ernel Sapinoso, Philippines

http://nth-faceted.blogspot.com



To install, copy tagalog.txt to the
'/bible/translations' directory of your flash cart.