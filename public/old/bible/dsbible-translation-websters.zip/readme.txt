"Webster's Bible" Bible translation for DSbible
-----------------------------------------------

Formatted by David Kienitz

To install this Bible translation, copy websters.txt to the
'/bible/translations' directory of your storage device. DSbible should then
recognize it the next time you run DSbible.
