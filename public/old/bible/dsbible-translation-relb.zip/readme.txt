'Rev.Elberfelder' Bible translation for DSbible
-----------------------------------------------

Formatted by Jens Willms

To install this Bible translation, copy relb.txt to the
'/bible/translations' directory of your storage device. DSbible should then
recognize it the next time you run DSbible.
